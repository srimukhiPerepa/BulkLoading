(function () {
'use strict';

// use by requirejs to combine service worker modules into a single file
(function () {

  const config = {
    map: {
      '*': {
        main: 'vbsw/main',
      },
    },
  };

  requirejs.config(config);
}());

define("vbsw/main", function(){});



define('vbc/private/constants',[], () => {
  const Constants = {};

  /**
   * The default log levels
   */
  Constants.Severity = {
    ERROR: 'error',
    INFO: 'info',
    FINE: 'fine',
    FINER: 'finer',
    WARNING: 'warn',
  };

  // from highest precedence to lowest
  Constants.SeverityOrder = [
    Constants.Severity.ERROR,
    Constants.Severity.WARNING,
    Constants.Severity.INFO,
    Constants.Severity.FINE,
    Constants.Severity.FINER,
  ];

  Constants.PATH_SEPARATOR = '/';

  Constants.VbProtocols = {
    CATALOG: 'vb-catalog',
  };

  // these headers used in both the fetch handler plugins and service layer
  Constants.Headers = {
    CONTENT_TYPE: 'content-type',

    // used internally to communicate extensions to plugins; should be stripped before the actual request.
    VB_INFO_EXTENSION: 'vb-info-extension',

    // header for indicating if anonymous access is allowed for the request
    ALLOW_ANONYMOUS_ACCESS_HEADER: 'vb-allow-anonymous-access',

    // used when service uses HTTP protocol; we must use the proxy, and in order for the service worker to get the
    // request, we have to switch the protocol (http is blocked), and save the original in this header.
    // note; we don't really use the SW any more for requests, but we haven't officially dropped SW support.
    PROTOCOL_OVERRIDE_HEADER: 'vb-protocol',

    // sent by DT during in-page preview, needed to disable certain types of auth that won't work in that context
    VB_DT_AUTHENTICATION: 'dt-serviceAuthentication',

    INHERIT: 'inherit-authentication',
  };


  // predefined vbInitParam values (or "initParams")
  Constants.InitParams = {
    // an array of authentication 'type' values that the authPreprocessor plugin should not process.
    // useful when using non-standard VB plugins, that may process the same auth type.
    PLUGIN_PASSTHROUGHS: 'services.security.handlers.passthroughs',
  };

  return Constants;
});



// This file was originally located in src/vb/private/. For full history: git log -- src/vb/private/logConfig.js
define('vbc/private/logConfig',['vbc/private/constants'], (Constants) => {
  /**
   * These are the loggers used in VBRT, which is based on a path. Each logger can be configured for
   * that path, and will affect all path elements underneath it. If a logger is requested but not
   * found, the default settings will be used based on the system logger.
   *
   * Each path can specify what levels are logged.
   *
   * To use a log, see utils/logger.js.
   */
  const Loggers = {
    '/': { error: true, info: true, fine: false, finer: false, warn: true },
    '/vb/stateManagement/variable': { finer: true },
    '/vb/stateManagement/instanceFactoryVariable': { finer: true },
    '/vb/stateManagement/container': { finer: true },
    '/vb/action': { fine: true },
    '/vb/types/ServiceDataProvider': { finer: true },
    '/vb/types/ServiceDataProvider.AsyncIterator': { finer: true },
    '/vb/helpers/rest': { fine: true },
  };

  const SpecialLogConstants = {
    CODE: 'code',
  };

  /**
   * Allows a configuration of styles if the default styles are not visually pleasing. Please only
   * make changes to styles in your private copy in loggers-config.js.
   */
  const Styles = {};
  Styles[Constants.Severity.ERROR] = {
    display: 'ERROR',
    style: 'background-color: #EB2A64; color: white',
  };
  Styles[Constants.Severity.INFO] = {
    display: 'INFO',
    style: 'font-weight:normal;background-color: #CED6F0; color: #0C40ED',
  };
  Styles[Constants.Severity.FINE] = {
    display: 'FINE',
    style: 'font-weight:normal;background-color: #C4C6CC; color: #4A4A4A',
  };
  Styles[Constants.Severity.FINER] = {
    display: 'FINER',
    style: 'font-weight:normal;background-color: #E9EAF0; color: #616060',
  };
  Styles[Constants.Severity.WARNING] = {
    display: 'WARN',
    style: 'background-color: #F2F2A7; color: black',
  };
  Styles[SpecialLogConstants.CODE] = {
    display: 'FINER',
    style: 'font-weight:bold;background-color: #E9EAF0; color: #616060',
  };

  const FancyStyleByFeature = {
    containerStart: 'orange',
    containerEnd: 'orange-end',
    actionChainStart: 'purple',
    actionChainEnd: 'purple-end',
    restHelperStart: 'yellow',
    restHelperEnd: 'yellow-end',
    serviceDataProviderStart: 'bluegreen',
    serviceDataProviderEnd: 'bluegreen-end',
  };

  const FancyStyles = {
    'fancy-yellow': 'font-weight:normal;background-color: #ffed00; color:#020200;padding:2px;font-size:11px;',
    'fancy-yellow-end': 'font-weight:normal;color:#FFCC00;padding:2px;font-weight:bolder;font-size:11px;',
    'fancy-orange': 'font-weight:normal;background-color: #EC9A29; color: #143642;padding:2px;font-size:11px;',
    'fancy-orange-end': 'font-weight:normal;color:#A56B1C;padding:2px;font-weight:bolder;font-size:11px;',
    'fancy-calm': 'font-weight:normal;background-color: #8BD8C6; color: black;font-size:14px;',
    'fancy-green': 'font-weight:normal;background-color: #3E8914; color: #E8FCCF;padding:2px;font-size:11px;',
    'fancy-coral': 'font-weight:normal;background-color: #ff9999; color: #ffffff;padding:2px;font-size:11px;',
    'fancy-bluegreen': 'font-weight:normal;background-color: #00cccc; color:#E8FCCF;padding:2px;font-size:11px;',
    'fancy-bluegreen-end': 'font-weight:normal;color:#009999;padding:2px;font-weight:bolder;font-size:11px;',
    'fancy-purple': 'font-weight:normal;color: transparent;text-shadow: 0 0 0 #9FAE68;' +
      'background-color:#7768AE;color: #fff;padding:2px;font-size:11px;',
    'fancy-purple-end': 'font-weight:normal;color: transparent;text-shadow: 0 0 0 #9FAE68;' +
      'color:#551A8B;padding:2px;font-weight:bolder;font-size:11px;',
  };

  const Emojis = {
    'fancy-orange': '🐬',
    'fancy-orange-end': '🐬',
    'fancy-green': '🐝',
    'fancy-coral': '🦉',
    'fancy-bluegreen': '🐿',
    'fancy-bluegreen-end': '🐿',
    'fancy-purple': '🐇',
    'fancy-purple-end': '🐇',
    'fancy-start': '✅️',
    'fancy-end': '❌',
    'fancy-calm': '🐐',
    'fancy-yellow': '🐎',
    'fancy-yellow-end': '🐎',
  };

  const CodeFontColors = {
    $string: 'color:#CD0000',
    $number: 'color:#0000FF',
    $boolean: 'color:#CC7832',
    $null: 'color:magenta',
    $key: 'color:#660E7A',
  };

  return { Loggers, Styles, FancyStyles, Emojis, CodeFontColors, FancyStyleByFeature };
});

/* global cordova:false */



define('vbc/private/utils',[
  'vbc/private/constants',
], (Constants) => {
  class Utils {
    /**
     * Generate a string unique Id.
     * @return {string} a unique id
     */
    static generateUniqueId() {
      return Math.random().toString(36).substr(2, 9);
    }

    /**
     * A very simplistic check to determine whether code is running on SW vs. UI thread
     *
     * @returns {boolean} true, if the code is executing on the service worker thread in the absence of a global
     * window object.
     */
    static isWorkerThread() {
      return globalThis.window === undefined;
    }

    /**
     * @param userAgent an optional userAgent string. If not specified, <code>navigator.userAgent</code> is used
     * @returns {boolean} true if browser is non Chromium based Edge
     */
    static isOldEdge(userAgent = navigator.userAgent) {
      return /Edge\//i.test(userAgent);
    }

    /**
     * Determines whether an app is running as a hybrid mobile application on a device.
     * @returns {boolean}
     */
    static isMobile() {
      return typeof cordova !== 'undefined';
    }

    /**
     * Determines whether a mobile app is running on iOS.
     * @returns {boolean}
     */
    static isIos() {
      return Utils.isMobile() && cordova.platformId === 'ios';
    }

    /**
     * Determines whether a mobile app is running on Android.
     * @returns {boolean}
     */
    static isAndroid() {
      return Utils.isMobile() && cordova.platformId === 'android';
    }

    /**
     * Returns true if the value is an object. An array is not counted as an object for this
     * evaluation.
     *
     * @param value The object to test
     * @returns {boolean} True if the object is non-null, defined, and an object
     */
    static isObject(value) {
      return value && value !== null && typeof value === 'object' && !Array.isArray(value);
    }

    /**
     * Return a promise to load a resource.
     * Reject with the error if there was an error or the file doesn't exist
     *
     * @param  {String} resource the path to the resource to load
     * @returns {Promise} a promise resolving to the content of the resource
     */
    static getResource(resource) {
      return new Promise((resolve, reject) => {
        requirejs([resource],
          (loaded) => {
            resolve(loaded);
          },
          (reason) => {
            reject(reason);
          });
      });
    }

    /**
     * Trace options correspond to vbInitConfig.TRACE_CONFIG. If vbInitConfig.TRACE_CONFIG.tracerOptions.applicationId
     * is not specified, vbInitConfig.APP_ID will be used instead.
     * @returns {Object|undefined} trace options extracted from vbInitConfig
     */
    static getTraceOptions(vbInitConfig) {
      if (vbInitConfig && vbInitConfig.TRACE_CONFIG) {
        // eslint-disable-next-line prefer-object-spread
        const tracerOptions = Object.assign({}, vbInitConfig.TRACE_CONFIG.tracerOptions);
        tracerOptions.applicationId = tracerOptions.applicationId || vbInitConfig.APP_ID;
        // eslint-disable-next-line prefer-object-spread
        return Object.assign({}, vbInitConfig.TRACE_CONFIG, { tracerOptions });
      }
      return undefined;
    }

    /**
     * @returns {boolean} a boolean indicating whether the browser is online.
     */
    static isOnline() {
      // if navigator.onLine is false, it is accurate
      if (!navigator.onLine) {
        return false;
      }
      return !(navigator.connection && navigator.connection.type === 'none');
    }

    /**
     * Add a slash to a path if the path is not empty
     * @param {String} path
     * @return {String}
     */
    static addTrailingSlash(path) {
      let newPath = path || '';
      if (newPath && newPath[newPath.length - 1] !== Constants.PATH_SEPARATOR) {
        newPath = `${newPath}/`;
      }

      return newPath;
    }

    /**
     * If present removes a slash at the end of the path
     * @param {String} path
     * @return {String} path without trailing slash
     */
    static removeTrailingSlash(path) {
      if (path && path.endsWith(Constants.PATH_SEPARATOR)) {
        return path.substring(0, path.length - 1);
      }
      return path;
    }
  }
  return Utils;
});



define('vbc/private/performance/performanceCategory',[], () => {
  const EMPTY_ENTRIES_PROMISE = (format) => Promise.resolve(format([]));
  /**
   * A performance category has a name and a promise that resolves to (optionally formatted) entries.
   * If formatCallback is specified, it is applied to each entry individually.
   */
  class PerformanceCategory {
    // Because of a circular dependency between Performance and Log, logger needs to be loaded on demand
    getLogger() {
      if (!this.logger) {
        const Log = requirejs('vbc/private/log');
        this.logger = Log.getLogger('/vbc/private/performance/performanceCategory');
      }
      return this.logger;
    }

    /**
     * @param {string} name category name
     * @param {function} entriesCallback a callback is a promise to a list performance category entries,
     * optionally formatted. If no entries callback is specified, this category will be empty.
     */
    constructor(name, entriesCallback) {
      this.name = name;
      if (typeof entriesCallback === 'function') {
        this.entriesCallback = entriesCallback;
      } else {
        this.getLogger().warn(`A specified entriesCallback: ${entriesCallback} is not a function and won't be used`);
        this.entriesCallback = EMPTY_ENTRIES_PROMISE;
      }
    }

    getName() {
      return this.name;
    }

    /**
     * @param {function} formatCallback formats each category entry individually
     * @returns {Promise} a promise to list of (optionally formatted) entries for this category,
     * or a promise to an empty array, if no entriesCallback has been specified
     */
    getEntries(formatCallback = ((e) => e)) {
      return this.entriesCallback(formatCallback);
    }
  }
  PerformanceCategory.EMPTY_ENTRIES_PROMISE = EMPTY_ENTRIES_PROMISE;
  return PerformanceCategory;
});



define('vbc/private/performance/immediateCategory',['vbc/private/performance/performanceCategory'], (PerformanceCategory) => {
  const EMPTY_ENTRIES = (format) => format([]);
  /**
   * A PerformanceCategory implementation that is capable of delivering entries immediately, without waiting
   * on a promise
   */
  class ImmediateCategory extends PerformanceCategory {
    /**
     * @param {string} name category name
     * @param {function} entriesNowCallback a callback to get a list of performance category entries,
     * optionally formatted.
     */
    constructor(name, entriesNowCallback) {
      super(name, (format) => Promise.resolve(this.getEntriesNow(format)));
      if (typeof entriesNowCallback === 'function') {
        this.entriesNowCallback = entriesNowCallback;
      } else {
        this.entriesNowCallback = EMPTY_ENTRIES;
      }
    }

    /**
     * @param {function} formatCallback formats each category entry individually
     * @returns {Array} a list of (optionally formatted) entries for this category or an empty array,
     * if no entriesNowCallback has been specified
     */
    getEntriesNow(formatCallback = ((e) => e)) {
      return this.entriesNowCallback(formatCallback);
    }
  }
  return ImmediateCategory;
});

/* eslint-disable prefer-object-spread */



define('vbc/private/trace/spanContext',[], () => {
  class SpanContext {
    /**
     * @param startSpanOptions a function that returns start span options object
     * @returns {SpanContext} span context for chaining
     */
    addStartSpan(startSpanOptions) {
      this.startSpan = startSpanOptions;
      return this;
    }

    /**
     * @param endSpanOptions a function that returns end span options object
     * @returns {SpanContext} span context for chaining
     */
    addEndSpan(endSpanOptions) {
      this.endSpan = endSpanOptions;
      return this;
    }

    /**
     * @param operationName an operation name for the start span
     * @returns {SpanContext} span context for chaining
     */
    addOperationName(operationName) {
      this.operationName = operationName;
      return this;
    }

    /**
     * @param error an error for the end span
     * @returns {SpanContext}
     */
    addError(error) {
      this.error = error;
      return this;
    }

    /**
     * Adds a function to execute within a span() call
     * @param {} fn Function to execute
     */
    addSpanFunction(fn) {
      this.fn = fn;
      return this;
    }

    /**
     * @returns {Object | undefined} valid start span options or undefined
     */
    startSpanOptions() {
      let startSpanOptions;
      if (typeof this.startSpan === 'function') {
        startSpanOptions = this.startSpan();
        if (this.operationName) {
          startSpanOptions = Object.assign({}, this.startSpan(), { operationName: this.operationName });
        }
      }
      // start span options must have operationName set
      return (startSpanOptions && startSpanOptions.operationName) ? startSpanOptions : undefined;
    }

    /**
     * Returns function to execute within a span() call
     */
    spanFunction() {
      return this.fn;
    }

    /**
     * @returns {Object | undefined} end span options
     */
    endSpanOptions() {
      let endSpanOptions;
      if (typeof this.endSpan === 'function') {
        endSpanOptions = this.endSpan();
        if (endSpanOptions && this.error) {
          endSpanOptions = Object.assign({}, endSpanOptions, { error: this.error });
        }
      }
      return endSpanOptions;
    }
  }
  return SpanContext;
});

/* eslint-disable class-methods-use-this */



define('vbc/private/trace/tracer',['vbc/private/utils', 'vbc/private/trace/spanContext'], (Utils, SpanContext) => {
  // Maximum number of trace records to buffer
  let tracerPromise;
  let logger;
  // Because of a circular dependency between Trace and Log, logger needs to be loaded on demand
  const getLogger = () => {
    if (!logger) {
      const Log = requirejs('vbc/private/log');
      logger = Log.getLogger('/vbc/private/trace/tracer');
    }
    return logger;
  };

  const noop = () => {};
  const noopTracer = {
    startSpan: noop,
    span: (opt, fn) => fn(),
    finishSpan: noop,
    shutdown: noop,
    inject: (req) => req,
    isBlacklisted: () => false,
    blacklist: noop,
  };

  /**
   * Used for OpenTracing log record and span management
   */
  class Tracer {
    constructor() {
      // a default tracer is a noop
      this.reset();
      this._blacklist = [];
    }

    /**
     * @param options tracer configuration - @see {@link Tracer#checkOptions}
     * @returns {Promise<any>} a promise to an initialized tracer. If tracer options pass a basic sanity check,
     * this will be a client trace Tracer. Otherwise this will be a noop tracer.
     * @see https://confluence.oraclecorp.com/confluence/display/MDO/Trace-Client+API
     */
    init(options) {
      if (!tracerPromise) {
        tracerPromise = Promise.resolve()
          .then(() => {
            if (Tracer.checkOptions(options)) {
              this.options = options;
              // a default tracer is a noop
              if (this.isTelemetryLoaded()) {
                // BUFP-42619: If the telemetry libs were loaded but the tracer
                // isn't initialized yet, it's possible this will return
                // null.  If so, enable tracing anyway and we'll check again
                // the first time a span is created.
                // eslint-disable-next-line
                this.tracer; // Prefetch the globalTracer
                this.isEnabled = true;
              }
            }
            getLogger().info('Tracer', this.isEnabled ? 'enabled' : 'disabled', 'on',
              globalThis.toString());
            return this;
          }).catch((err) => {
            getLogger().error('Failed to load tracer on', globalThis.toString(), err);
            this.reset();
          });
      }
      return tracerPromise;
    }

    /**
     * Ensure the telemetry lib is loaded
     */
    isTelemetryLoaded() {
      return globalThis.GlobalTracer !== undefined;
    }

    /**
     * Resolve the tracer object if it wasn't resolved by init()
     * @see https://jira.oraclecorp.com/jira/browse/BUFP-42619
     */
    get tracer() {
      if (this.isTelemetryLoaded()) {
        if (!this.globalTracer) {
          // Get the global tracer
          const tracer = globalThis.GlobalTracer.get();
          if (tracer) {
            // Cache if tracer was available
            this.globalTracer = tracer;
          } else {
            // Return noopTracer if tracer not loaded
            return noopTracer;
          }
        }
        return this.globalTracer;
      }
      // Return noopTracer if no telemetry
      return noopTracer;
    }

    /**
     * Resets tracer singleton so it can be reinitialized.  Note that this will not affect the state of the
     * underlying tracer (since JET et al. may be using it), just resets and decouples the VB wrapper.
     */
    reset() {
      tracerPromise = null;
      delete this.options;
      this.globalTracer = null;
      delete this.isEnabled;

      this._blacklist = [];
    }

    /**
     * @param options tracer configuration, containing:
     * <li>disabled</li> true, if tracing should be disabled for this application
     * <li>injectEnabled</li> true if the tracer should inject span context in outgoing REST calls
     * @see https://confluence.oraclecorp.com/confluence/display/MDO/FusionApps+Client+Logging+Configuration
     * @returns {boolean} true, if trace options pass a basic sanity check. False otherwise.
     */
    static checkOptions(options) {
      if (options && options.disabled) {
        getLogger().info('Tracer options check: tracing is disabled', options, 'on', globalThis.toString());
        return false;
      }
      return true;
    }

    /**
     * Creates and returns a client trace span.  Typically it is preferable to use span() instead
     * @param {Object} spanContext the SpanContext for the span
     * @returns {Object || undefined} span, if a valid span context was provided. Otherwise returns undefined.
     */
    startSpan(spanContext) {
      let span;
      if (this.isEnabled && spanContext instanceof SpanContext) {
        try {
          const spanOptions = spanContext.startSpanOptions();
          if (spanOptions) {
            span = this.tracer.startSpan(spanOptions);
          }
        } catch (err) {
          getLogger().error('Failed to start trace span', spanContext, 'on', globalThis.toString(), err);
        }
      }
      return span;
    }

    /**
     * Ends specified client trace span. If span is undefined, this is a noop.
     * @param {Object} span the span to close
     * @param {Object} spanContext the SpanContext for the span
     */
    finishSpan(span, spanContext) {
      try {
        if (this.isEnabled && span) {
          let spanOptions;
          if (spanContext instanceof SpanContext) {
            spanOptions = spanContext.endSpanOptions();
          }
          span.finish(spanOptions);
        }
      } catch (err) {
        getLogger().error('Failed to finish trace span', span, 'on', globalThis.toString(), err);
      }
    }

    /**
     * Executes a span with the given options, executing the spanContext.spanFunction within
     * a span's context and returning its return value, if any
     * @param {} spanContext Span context object
     * @returns The return value of the spanContext.spanFunction() property
     */
    span(spanContext) {
      if (spanContext instanceof SpanContext) {
        if (this.isEnabled) {
          try {
            const spanOptions = spanContext.startSpanOptions() || {};
            const fn = spanContext.spanFunction();
            if (spanOptions && fn) {
              return this.tracer.span(spanOptions, fn);
            }
          } catch (err) {
            getLogger().error('Failed to start trace span', spanContext, 'on', globalThis.toString(), err);
          }
        }

        // If disabled or error occurred, let function passthrough
        const fn = spanContext.spanFunction();
        if (fn) {
          return fn();
        }
      }
      return undefined;
    }

    /**
     * Injects span context headers into an outgoing fetch request, if applicable
     * @param {*} span Span whose context to inject
     * @param {*} request Request into which to inject it
     * @return Promise resolving to Request object with injected context
     */
    inject(request) {
      // TODO add explicit whitelisting
      if (this.options && this.options.injectEnabled) {
        if (!this.isBlacklisted(request)) {
          return new Promise((resolve) => {
            const newReq = this.tracer.inject(request.clone());
            resolve(newReq);
          });
        }
      }

      return Promise.resolve(request);
    }

    /**
     * Indicates whether the request has been blacklisted for trace context injection
     * @param {Request} request Request to check for blacklisting
     */
    isBlacklisted(request) {
      return this._blacklist.includes(request.url);
    }

    /**
     * Adds a url to the blacklist so injection won't be performed in the future
     * @param url URL to blacklist
     */
    blacklist(request) {
      this._blacklist.push(request.url);
    }
  }

  // return a singleton tracer
  return new Tracer();
});

/* eslint-disable max-classes-per-file */



define('vbc/private/performance/webVitalsCategory',[
  'vbc/private/utils',
  'vbc/private/performance/performanceCategory',
  'vbc/private/trace/tracer',
  'vbc/private/trace/spanContext',
], (Utils, PerformanceCategory, Tracer, SpanContext) => {
  const WEB_VITALS_CATEGORY_NAME = 'web vitals (ms)';

  class WebVital {
    constructor(reportHandler) {
      reportHandler(this.onReport.bind(this));
    }

    /**
     * @returns {Object} a web vitals metric, or example:
     *  {name: "TTFB",
     *   value: 947.4049999989802,
     *   delta: 947.4049999989802,
     *   entries: Array(1),
     *   id: "v1-1607453629257-9515794308663"}
     * or undefined if no metric has been reported yet
     * @see https://github.com/GoogleChrome/web-vitals#metric
     */
    getMetric() {
      return this.metric;
    }

    onReport(metric) {
      this.metric = metric;
      // https://jira.oraclecorp.com/jira/browse/DTA-4027 addresses better message format
      const spanContext = new SpanContext().addOperationName(`metric/${metric.name}`);
      const metricMsg = { msg: metric };
      spanContext.addStartSpan(() => metricMsg);

      spanContext.addEndSpan(() => metricMsg);
      const span = Tracer.startSpan(spanContext);
      if (span) {
        span.finish();
      }
    }
  }

  /**
   * A performance category representing Web Vitals.
   * @see https://web.dev/vitals/
   * @see https://github.com/GoogleChrome/web-vitals
   *
   * This category works on UI thread only, and returns empty entries on a worker thread
   */
  class WebVitalsCategory extends PerformanceCategory {
    /**
     * @param {Object} webVitals a WebVitals implementation, if available
     * @see https://github.com/GoogleChrome/web-vitals
     */
    constructor(webVitals) {
      super(WEB_VITALS_CATEGORY_NAME, (format) => Promise.resolve(this.getEntriesNow(format)));
      this.vitals = [];

      this.addWebVitalsPromise = Promise.resolve()
        .then(() => {
          if (Utils.isWorkerThread()) {
            return null;
          }
          // a dynamic loading of web-vitals is required to avoid loading web-vitals on the sw thread
          const getWebVitalsPromise = webVitals ? Promise.resolve(webVitals) : Utils.getResource('web-vitals');

          return getWebVitalsPromise
            .then((wv) => {
              this.vitals.push(new WebVital(wv.getCLS));
              this.vitals.push(new WebVital(wv.getFCP));
              this.vitals.push(new WebVital(wv.getFID));
              this.vitals.push(new WebVital(wv.getLCP));
              this.vitals.push(new WebVital(wv.getTTFB));
            });
        });
    }

    /**
     * @param {function} formatCallback formats each category entry individually
     * @returns {Promise} a promise to list of (optionally formatted) web vital entries or a promise to an empty array,
     * if no entriesCallback has been specified or this is executed on a service worker thread
     */
    getEntries(formatCallback = ((e) => e)) {
      return this.addWebVitalsPromise
        .then(() => {
          if (Utils.isWorkerThread()) {
            return PerformanceCategory.EMPTY_ENTRIES_PROMISE(formatCallback);
          }
          const formattedMetrics = [];
          this.vitals.forEach((v) => {
            const m = v.getMetric();
            if (m) {
              // For CLS the value is first multiplied by 1000 for greater precision
              // See https://developers.google.com/codelabs/chrome-web-vitals-js#3
              const value = Math.round(m.name === 'CLS' ? m.delta * 1000 : m.delta);
              const metric = { [m.name]: Math.round(value) };
              formattedMetrics.push(metric);
            }
          });
          return formattedMetrics;
        });
    }
  }
  WebVitalsCategory.WEB_VITALS_CATEGORY_NAME = WEB_VITALS_CATEGORY_NAME;
  return WebVitalsCategory;
});

/* eslint-disable class-methods-use-this */
/* eslint-disable max-classes-per-file */



define('vbc/private/performance/reporter',['vbc/private/constants'], (Constants) => {
  // Because of a circular dependency between Performance and Log, logger needs to be loaded on demand
  let logger;
  const getLogger = () => {
    if (!logger) {
      const Log = requirejs('vbc/private/log');
      logger = Log.getLogger('/vbc/private/performance/reporter');
    }
    return logger;
  };

  let loggingEnabled;
  const isLoggingEnabled = () => {
    if (loggingEnabled === undefined) {
      loggingEnabled = getLogger().isEnabled(Constants.Severity.INFO);
    }
    return loggingEnabled;
  };

  /**
   * A reporter that does nothing but is always enabled
   */
  class Reporter {
    // eslint-disable-next-line no-unused-vars
    report(name, entries) {
    }

    // eslint-disable-next-line
    isEnabled() {
      return true;
    }
  }

  /**
   * A reporter that logs performance category to the console at the info level
   */
  class ConsoleReporter extends Reporter {
    /**
     * @param {boolean} logObject if true, object will be logged directly in console regardless
     * of <code>console.table</code> support
     * @see Log.table
     */
    constructor(logObject = true) {
      super();
      this.logObject = logObject;
    }

    report(name = '', entries = []) {
      getLogger().info(`${name}:`);
      const obj = {};
      entries.forEach((e) => Object.assign(obj, e));
      getLogger().table({
        severity: Constants.Severity.INFO,
        groupTitle: name,
        obj,
        logObject: this.logObject,
      });
    }

    isEnabled() {
      return isLoggingEnabled();
    }
  }

  /**
   * A reporter that logs performance category to the console at the info level, using console.table for each
   * performance entry.
   */
  class TableConsoleReporter extends ConsoleReporter {
    constructor() {
      super(false);
    }
  }

  Reporter.CONSOLE_REPORTER = new ConsoleReporter();
  Reporter.TABLE_CONSOLE_REPORTER = new TableConsoleReporter();

  return Reporter;
});



define('vbc/private/performance/performanceReport',[
  'vbc/private/performance/reporter'], (Reporter) => {
  /**
   * Generates a report for specified performance categories
   */
  class PerformanceReport {
    // Because of a circular dependency between Performance and Log, logger needs to be loaded on demand
    getLogger() {
      if (!this.logger) {
        const Log = requirejs('vbc/private/log');
        this.logger = Log.getLogger('/vbc/private/performance/performanceReport');
      }
      return this.logger;
    }

    // eslint-disable-next-line class-methods-use-this
    processCategory(category, reporter, format) {
      const name = category.getName();
      category.getEntries(format)
        .then((entries) => reporter.report(name, entries));
    }

    /**
     * Applies specified reporter to each performance category
     * @param {Array} categories an array of Performance categories to process
     * @param {Reporter} reporter to report on each performance category
     * @param {function} format a function to apply to each category entry before reporting
     * @returns {Promise} a promise that resolves when all categories have been successfully reported
     */
    forEachCategory(categories, reporter, format) {
      const processCategoryPromises = [];
      if (categories) {
        categories.forEach((category) => {
          processCategoryPromises.push(this.processCategory(category, reporter, format));
        });
      }
      return Promise.all(processCategoryPromises);
    }

    /**
     * Reports each performance category using a specified format to the reporter
     * @param {Array} categories an array of Performance categories to process
     * @param {Reporter} reporter a function to report on a category
     * @param {function} format a function to apply to each category entry before reporting
     * @returns {Promise} a promise that resolves when all categories have been successfully reportred,
     * or an immediatelly resolved promise if reported is not enabled
     */
    reportEachCategory(categories, reporter = Reporter.CONSOLE_REPORTER, format = PerformanceReport.SIMPLE_FORMAT) {
      if (reporter.isEnabled()) {
        return this.forEachCategory(categories, reporter, format);
      }
      return Promise.resolve();
    }
  }

  /**
   * When logging performance entries directly to the console as an Object, formatting makes it easier to copy/paste
   * @param {*} entry a performance entry to format
   */
  PerformanceReport.SIMPLE_FORMAT = (entry) => {
    const formattedEntry = {};
    Object.getOwnPropertyNames(entry).forEach((propertyName) => {
      const formattedName = `\r${propertyName}`;
      formattedEntry[formattedName] = entry[propertyName];
    });
    return formattedEntry;
  };

  return PerformanceReport;
});

/* eslint-disable class-methods-use-this, prefer-destructuring */



//
// performance is a global that is defined on window:
//   https://developer.mozilla.org/en-US/docs/Web/API/Window/performance
// and on WorkerGlobalScope:
//   https://developer.mozilla.org/en-US/docs/Web/API/WorkerGlobalScope
// which is a parent of ServiceWorkerGlobalScope:
//   https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerGlobalScope
// Since this code runs both on UI thread and SW thread, it can't use window.performance or else it would break in SW,
// where window is not defined.
//
define('vbc/private/performance/performance',[
  'vbc/private/performance/performanceCategory',
  'vbc/private/performance/immediateCategory',
  'vbc/private/performance/webVitalsCategory',
  'vbc/private/performance/performanceReport',
  'vbc/private/performance/reporter',
], (PerformanceCategory, ImmediateCategory, WebVitalsCategory, PerformanceReport, Reporter) => {
  const MARK_START = '_vbMarkStart';
  //
  // Entry types for PerformanceMark, PerformanceMeasure, PerformanceNavigationTiming and PerformanceResourceTiming
  //
  const MARK_TYPE = 'mark';
  const MEASURE_TYPE = 'measure';
  const NAVIGATION_TYPE = 'navigation';
  const RESOURCE_TYPE = 'resource';
  //
  // Common property names between (old) performance.timing (PerformanceTiming) and
  // performance.getEntriesByType('navigation')[0](PerformanceNavigationTiming) excluding unloadEventEnd and
  // unloadEventStart that happen before navigationStart
  // See https://developer.mozilla.org/en-US/docs/Web/API/PerformanceTiming
  // See https://developer.mozilla.org/en-US/docs/Web/API/PerformanceNavigationTiming
  //
  const COMMON_PROPS = ['connectEnd', 'connectStart', 'domComplete', 'domContentLoadedEventEnd',
    'domContentLoadedEventStart', 'domInteractive', 'domainLookupEnd', 'domainLookupStart', 'domainLookupEnd',
    'fetchStart', 'loadEventEnd', 'loadEventStart', 'requestStart', 'responseEnd', 'responseStart'];

  // Default size of the resource timing buffer
  // From https://developer.mozilla.org/en-US/docs/Web/API/Performance/setResourceTimingBufferSize:
  // A browser's recommended resource timing buffer size is at least 150
  const DEFAULT_RESOURCE_BUFFER_SIZE = 150;

  // Because of a circular dependency between Performance and Log, logger needs to be loaded on demand
  let logger;
  const getLogger = () => {
    if (!logger) {
      const Log = requirejs('vbc/private/log');
      logger = Log.getLogger('/vbc/private/performance/performance');
    }
    return logger;
  };

  /**
   * Performance class with lazily initialized properties that correspond to the following performance categories:
   * - info: general information about this application
   * - navigation: entries corresponding to
   * [Navigation Timing Level 2]{@link https://developer.mozilla.org/en-US/docs/Web/API/PerformanceNavigationTiming}
   * or
   * [PerformanceTiming]{@link https://developer.mozilla.org/en-US/docs/Web/API/PerformanceTiming} API on browsers
   * that don't support PerformanceNavigationTiming.
   * - custom: custom navigation entries such as time to first byte
   * - timestamps: timestamp of important VB events, such as application's vbEnter
   * - durations - time spent on processing VB actions, action chains and fetch calls
   * - resources - 10 most expensive resources loaded by this application. This is either determined by time spent
   * loading this resource (on all browsers), or, resource size (on browser that support it)
   */
  class Performance {
    /**
     * @param resourceTimingBufferSize the size of the resource buffer for resource timing entries.
     * By default, it is 300.
     * @param maxResEntries the maximum number of resource entries to log. If not specified, it will be the same
     * as resourceTimingBufferSize
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Performance/setResourceTimingBufferSize
     */
    constructor({
      resourceTimingBufferSize = DEFAULT_RESOURCE_BUFFER_SIZE,
      maxResEntries = resourceTimingBufferSize,
    } = {}) {
      if (!performance) {
        getLogger().warn('Browser does not support Web Performance');
        return;
      }

      // performance.addEventListener is not supported on IE
      if (typeof performance.setResourceTimingBufferSize === 'function') {
        performance.setResourceTimingBufferSize(resourceTimingBufferSize);
      }
      // on Firefox ServiceWorker performance.addEventListener('resourcetimingbufferfull') syntax fails.
      performance.onresourcetimingbufferfull = this.onResourceBufferFull.bind(this);

      Performance.INFO = new ImmediateCategory('info', this.getInfo.bind(this));
      Performance.NAVIGATION = new ImmediateCategory('navigation (ms)', this.getNavigation.bind(this));
      Performance.CUSTOM = new PerformanceCategory('custom (ms)', this.getCustom.bind(this));
      Performance.TIMESTAMPS = new ImmediateCategory('timestamps (ms)', this.getTimestamps.bind(this));
      Performance.DURATIONS = new ImmediateCategory('durations (ms)', this.getDurations.bind(this));
      Performance.RESOURCES_BY_DURATION = new ImmediateCategory('resorcesByDuration (ms)',
        this.getResourcesByDuration.bind(this));
      Performance.RESOURCES_BY_SIZE = new ImmediateCategory('resourcesBySize (Kb)',
        this.getResourcesBySize.bind(this));
      Performance.WEB_VITALS = new WebVitalsCategory();

      this.categories = [];
      this.categories.push(Performance.INFO);
      this.categories.push(Performance.NAVIGATION);
      this.categories.push(Performance.CUSTOM);
      this.categories.push(Performance.TIMESTAMPS);
      this.categories.push(Performance.DURATIONS);
      this.categories.push(Performance.RESOURCES_BY_DURATION);
      this.categories.push(Performance.RESOURCES_BY_SIZE);
      this.categories.push(Performance.WEB_VITALS);

      this.maxResEntries = maxResEntries;
      this.resourceTimingBufferSize = resourceTimingBufferSize;
    }

    getCategories() {
      return this.categories;
    }

    /**
     * Event listener for 'resourcetimingbufferfull' browser event. All existing resource timing entries are logged
     * and cleared and resource timing buffer size is set to <i>resourceTimingBufferSize</>.
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Performance/resourcetimingbufferfull_event
     */
    onResourceBufferFull() {
      if (performance) {
        getLogger().warn('Resource timing buffer full');
        this.logResources();
        if (performance.getEntriesByType) {
          getLogger().info('Clearing', performance.getEntriesByType(RESOURCE_TYPE).length, 'resource entries');
        }
        // Remove all of the resource timing entries
        performance.clearResourceTimings();
        // Set the new size at resourceTimingBufferSize resource timing entries (PerformanceEntry objects)
        performance.setResourceTimingBufferSize(this.resourceTimingBufferSize);
      }
    }

    getReport() {
      if (!this.report) {
        this.report = new PerformanceReport();
      }
      return this.report;
    }

    /**
     * Log performance audits directly to the console.
     */
    log() {
      this.getReport().reportEachCategory(this.categories);
    }

    logTable() {
      // when using console.table(), there is no need for any formatting
      this.getReport().reportEachCategory(this.categories, Reporter.TABLE_CONSOLE_REPORTER, undefined);
    }

    logCustom() {
      this.getReport().reportEachCategory([Performance.CUSTOM]);
    }

    logTimestamps() {
      this.getReport().reportEachCategory([Performance.TIMESTAMPS]);
    }

    logDurations() {
      this.getReport().reportEachCategory([Performance.DURATIONS]);
    }

    logResources() {
      this.getReport().reportEachCategory([Performance.RESOURCES_BY_DURATION, Performance.RESOURCES_BY_SIZE]);
    }

    logVitals() {
      this.getReport().reportEachCategory([Performance.WEB_VITALS]);
    }

    logVB() {
      this.logDurations();
      this.logTimestamps();
    }


    /**
     * Determines if performance measuring should be enabled for a given performance config. For example:
     * <pre>
     *    PERFORMANCE_CONFIG: {
     *       resourceTimingBufferSize: 200,
     *       disabled: false,
     *   }
     * </pre>
     * means that performance should be enabled.
     * Performance measuring is disabled by default, but in an existing config it can also be disabled
     * by setting <i>disabled</i> property to false:
     * <pre>
     *    PERFORMANCE_CONFIG: {
     *       disabled: false,
     *   }
     * </pre>
     * @param config PERFORMANCE_CONFIG specified in window.vbInitConfig
     * @returns {boolean} true, if measuring performance should be enabled, false otherwise. For an undefined config, or
     * for a config that does have <i>disabled</i> property set to true, performance is disabled. For all other cases,
     * including an empty PERFORMANCE_CONFIG object, performance measuring is enabled.
     */
    static isEnabled(config) {
      //
      // Cannot use config && ... here, because it gets mimified to:
      // return e && !e.disabled && void 0 !== performance;
      // which, for undefined config, evaluates to undefined and not false, and that breaks unit test in test-release
      //
      return !!(config !== undefined && config !== null
        && (config.disabled ? config.disabled === false : true)
        && performance !== undefined);
    }

    /**
     * If performance is enabled by the specified configuration and browser support for <i>performance</i> API,
     * adds <i>perf</i> property to the context object.
     *
     * @param context the object to add <i>perf</i> property to. This is typically <i>window.vb</i>, or
     * <i>globalThis.vb</i> for the ServiceWorkerGlobalContext
     * @param config the performance configuration
     */
    static init(context, config) {
      if (context && Performance.isEnabled(config)) {
        Performance.enabled = true;
        const perf = new Performance(config);
        Object.defineProperty(context, 'perf', {
          enumerable: true,
          configurable: true,
          value: perf,
        });
        Performance.perf = perf;
      } else {
        Performance.enabled = false;
      }
    }

    /**
     * Creates a named timestamp in the browser's performance entry buffer between the navigation start time and
     * the current time, if performance is enabled.
     *
     * @param name entries corresponding to the name of the timestamp, for example: 'app', 'beforeEnter'
     * @see {@link Performance.isEnabled()}
     */
    static timestamp(...name) {
      if (Performance.enabled && name && Array.isArray(name) && name.length > 0) {
        performance.mark(name.join(':'));
      }
    }

    /**
     * Creates a mark in the browser's performance entry buffer with the given name, if performance is enabled.
     *
     * @param name an array of entries corresponding to the name of the mark, for example, ['fetchHandler.', 'install']
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Performance/mark
     * @see {@link Performance.isEnabled()}
     */
    static markStart(name = []) {
      if (Performance.enabled && name && Array.isArray(name) && name.length > 0) {
        performance.mark(`${name.join(':')}:${MARK_START}`);
      }
    }

    /**
     * Creates a named measure in a browser's performance entry buffer between the start mark with a matching name:
     * 'name' + _vbMarkStart and the current time, if performance is enabled.
     *
     * @param name an array of entries corresponding to the name of the mark, for example, ['fetchHandler.', 'install']
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Performance/measure
     * @see {@link Performance.isEnabled()}
     */
    static markEnd(name = []) {
      if (Performance.enabled && name && Array.isArray(name) && name.length > 0 && performance.getEntriesByName) {
        const markName = name.join(':');
        // create a measure from start mark to now
        const startMarkName = `${markName}:${MARK_START}`;
        // make sure the start mark still exits
        const startMark = performance.getEntriesByName(startMarkName, MARK_TYPE);
        if (startMark && startMark[0]) {
          performance.measure(markName, startMarkName);
          performance.clearMarks(startMarkName);
        }
      }
    }

    /**
     * Removes performance entries of type 'mark' and 'measure', since the last leaf page load
     * @param clearResourceTimings if true, also removes 'resource' type entries
     */
    static clear(clearResourceTimings = false) {
      if (Performance.enabled) {
        performance.clearMeasures();
        performance.clearMarks();
        delete performance.onresourcetimingbufferfull;
        if (clearResourceTimings && Performance.perf) {
          Performance.perf.onResourceBufferFull(this);
        }
      }
    }

    /**
     * Returns a PerformanceNavigationTiming for browsers that support it. Otherwise, on IE and Safari, a
     * deprecated PerformanceTiming object is returned, or undefined, if neither is supported, or this is
     * a Service Worker thread.
     *
     * @returns {PerformanceNavigationTiming|PerformanceTiming} a performance navigation timing entry
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceNavigationTiming
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceTiming
     */
    static getPerformanceTimingEntry() {
      let entry;
      let entries = [];
      if (performance.getEntriesByType) {
        entries = performance.getEntriesByType(NAVIGATION_TYPE);
        if (entries && entries.length > 0) {
          entry = entries[0];
        }
      }
      // fallback for legacy performance API
      if (entries.length === 0 && performance.timing) {
        entry = performance.timing;
      }
      return entry;
    }

    /**
     * Navigation start is the start point of a new page load as far as performance tools are concerned.
     * It is actually the moment just before a new page is requested.
     * For the legacy API, this corresponds to performance.timing.navigationStart. For v2 PerformanceNavigationTiming
     * API, it is PerformanceNavigationTiming.startTime, which is 0.
     *
     * @param entry a performance navigation entry
     * @returns {number} a navigation start time used to calculate custom performance entries
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceTiming/navigationStart
     */
    static getNavigationStart(entry) {
      // In the legacy PerformanceTiming API, all entries are in epoch time.
      let navigationStart = 0;
      if (entry) {
        if (entry.navigationStart !== undefined) {
          navigationStart = entry.navigationStart;
        } else if (entry.startTime) {
          navigationStart = entry.startTime;
        }
      }
      return navigationStart;
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @returns {Array} a list of generic information about this performance audit, such as location and user agent.
     */
    getInfo(f) {
      const info = [];
      // On IE/Edge, performance.getEntriesByType('navigation')[0].name returns 'document', which is not a good name
      // so use window.location.href instead. Except can't use window on SW thread, it has to be globalThis
      info.push(f({ name: globalThis.location.href }));
      info.push(f({ userAgent: navigator.userAgent }));
      info.push(f({ globalObject: globalThis.toString() }));
      return info;
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @returns {Array} a list of navigation timings for this application, such as domInteractive or fetchStart
     *
     * @see {@link Performance.getCommonEntryNames()}
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceNavigationTiming
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceTiming
     */
    getNavigation(f) {
      const navigation = [];
      const timingEntry = Performance.getPerformanceTimingEntry();

      if (timingEntry) {
        const navigationStart = Performance.getNavigationStart(timingEntry) || 0;
        // Add all entries common between (old) performance.timing (PerformanceTiming API) and
        // (new) performance.getEntriesByType('navigation')[0](PerformanceNavigationTiming API),
        // adjusting legacy entries for navigation start.
        COMMON_PROPS.forEach((prop) => {
          // adjust all entries that were represented in epoch time
          const propTime = timingEntry[prop] - navigationStart;
          const o = {};
          o[prop] = Math.round(propTime);
          navigation.push(f(o));
        });
      }
      return navigation;
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @returns {Promise} a promise to a list of calculated performance measures, such as:
     *
     * - connectTime
     * - domLoadTime
     * - domParsingTime
     * - renderTime
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceLongTaskTiming
     */
    getCustom(f) {
      const custom = [];
      return Promise.resolve()
        .then(() => {
          const e = Performance.getPerformanceTimingEntry();
          if (e) {
            custom.push(f({ connectTime: Math.round(e.responseEnd - e.requestStart) }));
            custom.push(f({ domLoadTime: Math.round(e.domContentLoadedEventEnd - e.fetchStart) }));
            custom.push(f({ domParsingTime: Math.round(e.domContentLoadedEventEnd - e.domInteractive) }));
            custom.push(f({ renderTime: Math.round(e.domComplete - e.domContentLoadedEventEnd) }));
          }
          return custom;
        })
        .catch((error) => {
          getLogger().warn(error);
          return custom;
        });
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @return {Array} a list of all custom VB performance measures that were added since the last call
     * to {@link clear()}
     *
     * @see {@link markStart(name)}
     * @see {@link markEnd(name)}
     */
    getDurations(f) {
      const durations = [];
      if (performance.getEntriesByType) {
        const entries = performance.getEntriesByType(MEASURE_TYPE);
        if (entries) {
          entries.forEach((entry) => {
            const o = {};
            o[entry.name] = Math.round(entry.duration);
            durations.push(f(o));
          });
        }
      }
      return durations;
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @returns {Array} a list of all custom VB timestamps that were added since the last call to {@link clear()}
     *
     * @see {@link timestamp(name)}
     */
    getTimestamps(f) {
      const timestamps = [];
      if (performance.getEntriesByType) {
        const entries = performance.getEntriesByType(MARK_TYPE);
        if (entries) {
          entries.forEach((entry) => {
            // marks ending with MARK_START are used to measure duration and should be ignored here
            if (!entry.name.endsWith(MARK_START)) {
              const o = {};
              o[entry.name] = Math.round(entry.startTime);
              timestamps.push(f(o));
            }
          });
        }
      }
      return timestamps;
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @return {Array} For browsers that support PerformanceResourceTiming API's encodedBodySize, a list
     * of properties corresponding to maxResEntries biggest resources since the resource timing buffer has been cleared.
     * For other browsers, an empty array is returned.
     * Resource size is specified in Kb. Resources with size that rounds to zero are not included.
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming/encodedBodySize
     * @see {@link new Performance(maxResEntries)}
     */
    getResourcesBySize(f) {
      const resources = [];
      if (performance.getEntriesByType) {
        const resEntries = performance.getEntriesByType(RESOURCE_TYPE);
        // encodedBodySize is not universally supported
        // https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming/encodedBodySize
        // entries are sorted by size, if available
        const resEntry = resEntries[0];
        if (resEntry && resEntry.encodedBodySize !== undefined) {
          resEntries.sort((a, b) => {
            if (a.encodedBodySize < b.encodedBodySize) {
              return 1;
            }
            return -1;
          });
          resEntries.slice(0, resEntries.length > this.maxResEntries ? this.maxResEntries : resEntries.length)
            .forEach((entry) => {
              const size = Math.round(entry.encodedBodySize / 1024);
              // encodedBodySize for resource fetched on SW thread is showing up as 0, so don't include it
              if (size > 0) {
                const o = {};
                o[entry.name] = Math.round(size);
                resources.push(f(o));
              }
            });
        }
      }
      return resources;
    }

    /**
     * @param {function} f a format callback to apply to each entry
     * @return {Array} a list of properties corresponding to maxResEntries resources that took longest to load
     * for this application, since the resource timing buffer has been cleared.
     * Duration is specified in milliseconds.
     *
     * See {@link https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming}
     */
    getResourcesByDuration(f) {
      const resources = [];
      if (performance.getEntriesByType) {
        const resEntries = performance.getEntriesByType(RESOURCE_TYPE);
        if (resEntries) {
          resEntries.sort((a, b) => {
            if (a.duration < b.duration) {
              return 1;
            }
            return -1;
          });
          resEntries.slice(0, resEntries.length > this.maxResEntries ? this.maxResEntries : resEntries.length)
            .forEach((entry) => {
              // if a resource is fetched multiple times, use the longest duration (for now)
              if (!resources[entry.name] || resources[entry.name] < entry.duration) {
                const o = {};
                o[entry.name] = Math.round(entry.duration);
                resources.push(f(o));
              }
            });
        }
      }
      return resources;
    }
  }
  return Performance;
});

/* eslint-disable prefer-destructuring */



define('vbc/private/monitorOptions',[], () => {
  const STARTING = 'starting';
  const ENDING = 'ending';
  class MonitorOptions {
    /**
     * @param operationName the name of the operation to monitor
     * @param message user readable monitor message
     */
    constructor(operationName, message) {
      this.operationName = operationName;
      this.message = message;
    }

    /**
     * @param message monitor message
     * @returns {MonitorOptions}
     */
    addMessage(message) {
      this.message = message;
      return this;
    }

    /**
     * @param message start monitor message
     * @returns {MonitorOptions} monitor options for chaining
     */
    addStartMessage(message) {
      this.startMessage = message;
      return this;
    }

    /**
     * @param message end monitor message
     * @returns {MonitorOptions} monitor options for chaining
     */
    addEndMessage(message) {
      this.endMessage = message;
      return this;
    }

    /**
     * @param tags a function that returns log monitor tags object
     * @returns {MonitorOptions} monitor options for chaining
     */
    addTags(tags) {
      this.tags = tags;
      return this;
    }

    /**
     * @param startFields a function that returns a fields object
     * @returns {MonitorOptions} monitor options for chaining
     */
    addStartFields(startFields) {
      this.startFields = startFields;
      return this;
    }

    /**
     * @param endFields a function that returns a fields object
     * @returns {MonitorOptions} monitor options for chaining
     */
    addEndFields(endFields) {
      this.endFields = endFields;
      return this;
    }

    /**
     * @returns {*|string} a start message for this monitor. If no start message was specified, start message is
     * constructed from the message.
     */
    getStartMessage() {
      let startMessage = this.startMessage;
      if (!startMessage && this.message) {
        startMessage = `${STARTING} ${this.message}`;
      }
      return startMessage;
    }

    /**
     * @returns {*|string} an end message for this monitor. If no end message was specified, end message is
     * constructed from the message.
     */
    getEndMessage() {
      let endMessage = this.endMessage;
      if (!endMessage && this.message) {
        endMessage = `${ENDING} ${this.message}`;
      }
      return endMessage;
    }

    /**
     * @returns {Object | undefined} log monitor tags object
     */
    getTags() {
      let tags;
      if (typeof this.tags === 'function') {
        tags = this.tags();
      }
      return tags;
    }

    /**
     * @returns {Object | undefined} log monitor fields object
     */
    getStartFields() {
      let fields;
      if (typeof this.startFields === 'function') {
        fields = this.startFields();
      }
      return fields || {};
    }

    /**
     * @returns {Object | undefined} log monitor fields object
     */
    getEndFields() {
      let fields;
      if (typeof this.endFields === 'function') {
        fields = this.endFields();
      }
      return fields || {};
    }
  }
  return MonitorOptions;
});

/* eslint-disable max-classes-per-file */
/* eslint-disable prefer-destructuring, prefer-object-spread */



// This file was originally located in src/vb/private/. For full history: git log src/vb/private/log.js
define('vbc/private/log',[
  'vbc/private/constants',
  'vbc/private/logConfig',
  'vbc/private/utils',
  'vbc/private/performance/performance',
  'vbc/private/trace/tracer',
  'vbc/private/trace/spanContext',
  'vbc/private/monitorOptions',
], (Constants, LogConfig, Utils, Performance, Tracer, SpanContext, MonitorOptions) => {
  // The place where all the loggers are cached
  const cachedLoggers = {};

  /**
   * The global configuration object for all loggers that allows to turn off fancy mode(colors) and emoji's.
   * This is typically specified as a window.vbInitConfig.LOG parameter in index.html:
   * <pre>
   *   {
   *   mode: 'simple',
   *   emoji: 'off',
   *   }
   * </pre>
   * @type {{}}
   */
  let logConfig = {};

  // A no-op used in various place
  const noop = () => {
  };

  const resolveConsoleMappings = () => {
    // check to make sure we can actually log
    const compatLog = (console && console.log) ? console.log : noop;
    const compatInfo = (console && console.info) ? console.info : compatLog;
    const compatErr = (console && console.error) ? console.error : compatLog;
    const compatWarn = (console && console.warn) ? console.warn : compatLog;
    const compatDebug = (console && console.debug) ? console.debug : compatLog;

    /**
     * An object use to map a log severity to a console method name
     * @type {Object}
     */
    const consoleMapper = {
      [Constants.Severity.ERROR]: compatErr,
      [Constants.Severity.WARNING]: compatWarn,
      [Constants.Severity.INFO]: compatInfo,
      [Constants.Severity.FINE]: compatDebug,
      [Constants.Severity.FINER]: compatDebug,
    };

    return consoleMapper;
  };

  let consoleMapper = resolveConsoleMappings();

  // Internet explorer has limited support for console.
  const isIE = !!(console.table === undefined);

  // console.group support check
  const isGroup = !!(console.group && console.groupCollapsed && console.groupEnd);

  // console.table support check
  const isTable = console.table && !Utils.isOldEdge();

  /**
   * Given a path and the information in the logConfig, retrieve which severity
   * method will show on the console.
   * @param  {String} path
   * @return {Object} an object where each property is a severity of type boolean
   */
  const getShowLogMap = (path) => {
    const loggerInfo = {};
    let loggerPath = path;

    // go through each of the path elements
    while (loggerPath.length > 0) {
      const foundLogger = LogConfig.Loggers[loggerPath];
      if (foundLogger) {
        // fill in the log levels that we can for the current path
        Constants.SeverityOrder.forEach((severity) => {
          if (loggerInfo[severity] === undefined && foundLogger[severity] !== undefined) {
            loggerInfo[severity] = foundLogger[severity];
          }
        });
      }

      // if we have all our info, abort
      if (Constants.SeverityOrder.every((severity) => loggerInfo[severity] !== undefined)) {
        break;
      }

      // get the next logger in the path
      const lastSlash = loggerPath.lastIndexOf('/');
      if (lastSlash === -1) {
        loggerPath = '';
      } else if (lastSlash === 0) {
        loggerPath = '/';
      } else {
        loggerPath = loggerPath.substring(0, lastSlash);
      }
    }

    return loggerInfo;
  };

  /**
   * Return true is the log should be in fancy mode
   * @return {Boolean}
   */
  const useFancyMode = (config) => {
    // Fancy mode is not supported by IE
    if (isIE) {
      return false;
    }
    return (config.mode !== 'simple');
  };

  /**
   * Return true is the log should be in fancy mode
   * By default emoji are off. To turn on emoji, set vbInitConfig.LOG.emoji === 'on'
   * @return {Boolean}
   */
  const useEmoji = (config) => (config.emoji === 'on');

  /**
   * Only use template for formatting messages if we are not running in test mode.
   *
   * @param config log configuration
   * @returns {Boolean}
   */
  const useTemplate = (config) => (config.mode !== 'test');

  /**
   * if the LogConfig.Styles[severity] has a truthy 'disabled' property
   * @param severity
   * @returns {*}
   * @private
   */
  const isSeverityDisabled = (severity) => !!(LogConfig.Styles[severity] && LogConfig.Styles[severity].disabled);

  /**
   * A logger that has a name and log levels.
   *
   * @param {String} path The logger path (i.e. /vb)
   * @param {Object[]} customLoggers the definition of custom loggers
   * @param {String} customLoggers.name - the name of the function on the logger
   * @param {String} customLoggers.severity - the severity to use on the custom logger
   * @param {String} customLoggers.style - the style to use on the custom logger
   * @params {Object} options custom logging configuration
   * @params {boolean} options.useEmoji true, if logging messages can use emojis for fancy style
   * @param {boolean} options.useFancyMode true, if fancy node should be used to format log messages
   * @param {Object} options.wrapErrorIfNeeded a function that allows to perform special handling for log errors
   * @see {@link LogConfig#Emojis}
   * @see {@link LogConfig#FancyStyle}
   * @constructor
   * @private
   */
  class Logger {
    constructor(path, customLoggers, options = {}) {
      this._display = path;

      this._showLog = getShowLogMap(path);

      this.customLoggers = customLoggers;

      this.options = options;

      this.options.wrapErrorIfNeeded = this.options.wrapErrorIfNeeded || noop;

      // Dynamically create the methods error, war, info, fine and finer
      // on the Logger class
      Constants.SeverityOrder.forEach((severity) => {
        // Update the showLog map with info about the severity from the LogConfig
        const severityEnabled = !!(!isSeverityDisabled(severity) && this._showLog[severity] === true);
        this._showLog[severity] = severityEnabled;

        // Create a property for each severity (isInfo, isFine, isFiner, etc) so that logging can be
        // made optional using the condition logger.isFine
        let propName = severity.charAt(0).toUpperCase() + severity.slice(1);
        propName = `is${propName}`;
        this[propName] = severityEnabled;

        // Create the logging method
        this[severity] = this.getLoggerMethod(severity);
      });

      this.options.wrapErrorIfNeeded(this);

      // Create additional logging methods using severity and style passed to the constructor
      if (customLoggers) {
        customLoggers.forEach((def) => {
          this[def.name] = this.getLoggerMethod(def.severity, def.style);
        });
      }
    }

    /**
     * Get the method that should be called when logging with a specific severity and style
     * The method is bound to the console object to display the correct log location on the
     * debugger.
     * @param  {String} severity
     * @param  {String} style
     * @return {Function}  the bound logging function
     */
    getLoggerMethod(severity, style) {
      if (this._showLog[severity] === true) {
        const consoleMethod = consoleMapper[severity];

        // Use bind instead of wrapping in order to display the log origin
        return consoleMethod.bind(console, ...this._buildParams(severity, style));
      }

      return noop;
    }

    /**
     * If logger is enabled for this severity, and <code>console.table</code> is enabled, specified object will
     * be displayed in a table within a <code>console.group</code>.
     * Otherwise, if logging level is enabled, but there is no table support, the object will be logged directly
     * in the console.
     * For a logging level that is disabled for this logger, there will be no console output.
     * @param severity logging level. For example, 'fine', 'info', 'error'. If not enabled for this logger,
     * there will be no console output
     * @param obj {Object} the object to display in <code>console.table</code>
     * @param groupTitle an optional title for the <code>console.group</code>, if group option is available
     * @param group a boolean specifying if table should be showed within a (collapsed) group
     * @param logObject if true, object will be logged directly in console regardless of <code>console.table</code>
     * support
     */
    table({
      severity, obj, groupTitle = '', group = true, logObject = false,
    } = {}) {
      if (this.isEnabled(severity) && Utils.isObject(obj)) {
        let endGroup = false;
        if (group && isGroup) {
          console.groupCollapsed(groupTitle);
          endGroup = true;
        }
        // console.table does not work for objects on Window's Edge (not Chromium based edge)
        // property names are shown, but not property values. On Chrome, table does not
        // show up every time console.table() is called. For those reasons, logObject flag is used to skip
        // console.table() call
        if (!logObject && isTable) {
          console.table(obj);
        } else {
          this.getLoggerMethod(severity)(obj);
        }
        if (endGroup) {
          console.groupEnd();
        }
      }
    }

    /**
     * @param severity logging level. For example, 'fine', 'info', 'error'.
     * @returns {boolean} true, if the logging level is enabled for this logger
     */
    isEnabled(severity) {
      return this[severity] !== noop;
    }

    /**
     * Creates a new monitor that can be used to time an operation.
     *
     * @param monitorOptions (Object) log monitor options for this monitor
     * @param fn (Function) a function that takes a timing function as a param to call when timing ends
     * @returns The return value of fn OR the end timing function if fn was not supplied
     */
    // eslint-disable-next-line class-methods-use-this
    monitor(monitorOptions, fn) {
      const startTime = new Date().getTime();
      let markName;
      let spanContext;
      let span;
      const endFunc = (detail) => {
        const duration = new Date().getTime() - startTime;
        if (markName) {
          Performance.markEnd(markName);
        }
        if (spanContext) {
          if (detail instanceof MonitorOptions) {
            spanContext.addEndSpan(() => (Object.assign({
              msg: detail.getEndMessage(),
            }, detail.getEndFields())));
          } else {
            spanContext.addError(detail);
          }

          Tracer.finishSpan(span, spanContext);
        }
        return `(completed in ${duration} ms)`;
      };

      if (monitorOptions instanceof MonitorOptions) {
        markName = [monitorOptions.operationName, monitorOptions.message];
        Performance.markStart(markName);
        spanContext = new SpanContext().addOperationName(monitorOptions.operationName);
        spanContext.addStartSpan(() => (Object.assign({
          msg: monitorOptions.getStartMessage(),
          tags: monitorOptions.getTags(),
        }, monitorOptions.getStartFields())));
        spanContext.addEndSpan(() => (Object.assign({
          msg: monitorOptions.getEndMessage(),
        }, monitorOptions.getEndFields())));

        if (fn) {
          // Use the span() function (preferred)
          spanContext.addSpanFunction((spn) => {
            span = spn;
            return fn(endFunc);
          });
          return Tracer.span(spanContext);
        }

        // Use the startSpan() function
        span = Tracer.startSpan(spanContext);
      }

      return endFunc;
    }

    /**
     * Builds params to format log message.
     * @param {String} severity
     * @param {String} style
     * @returns {Array}
     * @private
     */
    _buildParams(severity, style) {
      const params = [];
      const baseTemplate = '[VB (%s), %s]:';

      // directly format the message header when running in test mode
      if (!this.options.useTemplate) {
        params.push(`[VB (${LogConfig.Styles[severity].display}), ${this._display}]:`);
        return params;
      }

      if (!this.options.useFancyMode) {
        params.push(baseTemplate);
      } else if (style) {
        const fancyStyle = `fancy-${style}`;
        let emoji = '';
        if (this.options.useEmoji) {
          emoji = LogConfig.Emojis[fancyStyle];
          emoji = emoji ? `${emoji} ` : '';
        }
        params.push(`%c${emoji}${baseTemplate}`);
        params.push(LogConfig.FancyStyles[fancyStyle]);
      } else {
        params.push(`%c${baseTemplate}`);
        params.push(LogConfig.Styles[severity].style);
      }

      params.push(LogConfig.Styles[severity].display);
      params.push(this._display);

      return params;
    }
  }

  /**
   * Loggers are path based, to get a particular logger, use:
   *
   * Log.getLogger('/some/path')
   *
   * where the path is arbitrary but should reflect the organization of your resources.
   *
   * The second argument is used to define custom loggers. A custom logger has name, a severity
   * and a style. A new method with that name is created on the logger that will log a message
   * on the console using that severity and style.
   *
   * Logs can be configured by editing /loggers-config.js, please see the comments in there
   * for more details.
   */
  class Log {
    /**
     * Returns a logger for the given path (see Log.Loggers). The path will determine the attributes
     * of the logger, including what levels are shown by default.
     *
     * @param {String} path The logger path (i.e. /vb)
     * @param {Object[]} customLoggers the definition of custom loggers
     * @param {String} customLoggers.name - the name of the function on the logger
     * @param {String} customLoggers.severity - the severity to use on the custom logger
     * @param {String} customLoggers.style - the style to use on the custom logger
     * @param {Object} wrapErrorIfNeeded a function that allows to perform special handling for log errors
     */
    static getLogger(path, customLoggers, wrapErrorIfNeeded = noop) {
      let logger = cachedLoggers[path];

      if (!logger) {
        // create new logger with the logger levels
        const options = {};
        options.useTemplate = useTemplate(logConfig);
        options.useEmoji = useEmoji(logConfig);
        options.useFancyMode = useFancyMode(logConfig);
        options.wrapErrorIfNeeded = wrapErrorIfNeeded;
        logger = new Logger(path, customLoggers, options);
        cachedLoggers[path] = logger;
      }

      return logger;
    }

    /**
     * Allows sub class to access cached loggers.
     * @return an object containing existing loggers keyed by path
     */
    static getCachedLoggers() {
      return cachedLoggers;
    }

    /**
     * When the logger definition has changed, for example after the app-flow.json is loaded,
     * adjust all the exist cached loggers with the possible new definition.
     * @param {Object} config (optional) log config options for setting fancy mode and emoji
     */
    static rebuildLoggers(config) {
      consoleMapper = resolveConsoleMappings();
      Object.keys(cachedLoggers).forEach((path) => {
        const cached = cachedLoggers[path];
        const options = cached.options;
        if (config) {
          options.useEmoji = useEmoji(config);
          options.useFancyMode = useFancyMode(config);
        }
        const newLogger = new Logger(path, cached.customLoggers, options);
        Object.assign(cached, newLogger);
      });
    }

    /**
     * allow setting the minimum level of log message set to the console,
     * to quiet the logs, and (typically) improve performance
     * @param lvl
     * @returns {boolean}
     */
    static setMinimumLevel(lvl) {
      // backward compatibility
      const level = lvl === 'warning' ? 'warn' : lvl;

      const precedence = Constants.SeverityOrder.indexOf(level);
      if (precedence !== -1) {
        // disable all the lower ones
        const levelsToDisable = Constants.SeverityOrder.slice(precedence + 1);
        levelsToDisable.forEach((l) => {
          const style = LogConfig.Styles[l];
          if (style) {
            style.disabled = true;
          }
        });
        // @todo: revisit this; could we call this earlier?
        Log.rebuildLoggers();
        return true;
      }
      return false;
    }

    /**
     * A simple compare for log configuration objects. It does not consider default options, so:
     * <pre>
     *   {
     *   mode: 'simple',
     *   emoji: 'on',
     *   }
     * </pre>
     * and
     * <pre>
     *   {
     *   mode: 'simple',
     *   }
     * </pre>
     * are considered different configurations. Nulls are not supported. Improvements can be made in the future.
     * @param c1 original log config
     * @param c2 new log config
     * @returns {boolean} true, if both objects are the same
     * @private
     */
    static compareConfigs(c1 = {}, c2 = {}) {
      return c1.mode === c2.mode && c1.emoji === c2.emoji;
    }

    /**
     * Sets the global log configuration and rebuilds all existing loggers, if configuration has changed.
     * @param {Object} config the log configuration options, for example:
     * <pre>
     *   {
     *   mode: 'simple',
     *   emoji: 'off',
     *   }
     * </pre>
     */
    static setConfig(config = {}) {
      if (config !== null && !Log.compareConfigs(logConfig, config)) {
        logConfig = config || {};
        Log.rebuildLoggers(logConfig);
      }
    }
  }

  Log.NOOP = noop; // expose for unit tests

  return Log;
});



define('vbc/private/pwa/pwaUtils',['vbc/private/constants', 'vbc/private/utils'], (Constants, Utils) => {
  const requestOptions = {
    method: 'GET',
    cache: 'no-cache',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
    },
  };

  class PwaUtils {
    /**
     * @returns {boolean} a boolean indicating whether the browser is online. We cannot
     * use OPT API here, because it has not been loaded yet and it relies on window object.
     */
    static isOnline() {
      return Utils.isOnline();
    }

    /**
     * Checks if vbInitConfig corresponds to a PWA application. Currently, this means that:
     *
     * For VB mobile applications:
     * - the application is not running in page designer or preview mode (vbInitConfig.IS_DT_MODE is false)
     * - a non empty shellPath parameter is present in vbInitConfig.SERVICE_WORKER_CONFIG.
     * For VB web applications:
     * - vbInitConfig.PWA_CONFIG is defined and not disabled
     *
     * @param config vbInitConfig
     * @returns {*|boolean} true, if vbInitConfig is configured for a PWA, false otherwise
     */
    static isPwaConfig(config) {
      return PwaUtils.isMobilePwaConfig(config) || PwaUtils.isWebPwaConfig(config);
    }

    /**
     * @param {*} config vbInitConfig
     * @returns {*|boolean} true, if vbInitConfig is configured for a PWA for a mobile VB application, false otherwise
     */
    static isMobilePwaConfig(config) {
      return !!(config
        && !config.IS_DT_MODE
        && config.SERVICE_WORKER_CONFIG
        && !config.SERVICE_WORKER_CONFIG.disabled
        && PwaUtils.isPwaShellPath(config.SERVICE_WORKER_CONFIG.shellPath));
    }

    /**
     * @param {*} config vbInitConfig
     * @returns {*|boolean} true, if vbInitConfig is configured for a PWA for a web VB application, false otherwise
     */
    static isWebPwaConfig(config) {
      return !!(config && config.PWA_CONFIG && !config.PWA_CONFIG.disabled);
    }

    /**
     * @param {*} config vbInitConfig
     * @returns true, if a PWA application is configured to deliver vbBeforeAppInstallPrompt event. For PWA's based
     * on mobile VB apps, this is always true. For PWA's based on VB web apps, delivery of this event can be skipped
     * by setting PWA_CONFIG.skipBeforeInstallPrompt vbInitConfig parameter to true
     */
    static shouldAddBeforeInstallPromptListener(config) {
      return PwaUtils.isMobilePwaConfig(config)
      || !!(PwaUtils.isWebPwaConfig(config) && !config.PWA_CONFIG.skipBeforeInstallPrompt);
    }

    static isPwaShellPath(shellPath) {
      return typeof shellPath === 'string' && shellPath.trim().length > 0;
    }

    /**
     * @returns {Promise<any>} a Promise to a Service Worker's scope or undefined, if there is no service worker
     * registered for this application or the browser does not support Service Worker
     */
    static getServiceWorkerScope() {
      return Promise.resolve()
        .then(() => navigator.serviceWorker.getRegistration())
        .then((r) => r.scope)
        .catch(() => {});
    }

    /**
     * Load JSON application shell cache file. The file should be in the following structure:
     * {
     * "appFiles" : [
     * ],
     *  "jetFiles" : [
     * ],
     *  "files" : [
     * ],
     * }
     * @param shellPath a location of appShellCache.json file, for example:
     * <i>./mobileApps/testApp/version_1552430187000/appShellCache.json</i>, if called on SW thread or
     * <i>/mobileApps/testApp/version_1552430187000/appShellCache.json</i>, if called on UI thread
     * @param fetchMethod
     * @param fetchContext
     * @returns {Promise<{}>} a promise to application shell cache file. If application shell file fails to load,
     * promise rejects.
     */
    static loadAppShellFile(shellPath, fetchMethod, fetchContext) {
      return Promise.resolve()
        .then(() => {
          if (!shellPath) {
            throw new Error('loadAppShellFile(): empty application shell path specified');
          }
          const request = new Request(shellPath, requestOptions);
          return fetchMethod.call(fetchContext, request);
        })
        .then((result) => {
          if (result && result.ok) {
            return result.text();
          }
          throw new Error(`loadAppShellFile(${shellPath}): invalid response: ${result ? result.status : result}`);
        })
        .then((text) => {
          if (text) {
            return JSON.parse(text);
          }
          throw new Error(`loadAppShellFile(${shellPath}): result.text is empty`);
        });
    }

    /**
     * Append / at the end of a non empty path.
     * @param path original path
     * @returns {string} path with a / at the end, or an empty string if path was empty/undefined
     */
    static postSlash(path) {
      if (path) {
        return path.trim().endsWith(Constants.PATH_SEPARATOR) ? path : `${path.trim()}${Constants.PATH_SEPARATOR}`;
      }
      return '';
    }
  }
  return PwaUtils;
});



define('vbsw/api/fetchHandlerPlugin',[], () => {
  /**
   * Base class for implementing plugins that can be registered with the fetch handler.
   */
  class FetchHandlerPlugin {
    /**
     * Constructor for a handler plugin.
     *
     * @param context the context for the plugin which currently contains the fetchHandler and stateCache
     * @param params an optional params object
     */
    constructor(context, params = {}) {
      // extract the fetchHandler and stateCache from the context
      if (context) {
        this.fetchHandler = context.fetchHandler;
        this.stateCache = context.stateCache;
      }

      this.params = params;
    }

    /**
     * This method is called when the plugin is (re)installed to give it a chance to clean up previously cached
     * data.
     *
     * @returns {*}
     */
    initCache() {
      if (this.stateCache) {
        return this.stateCache.clear();
      }

      return Promise.resolve();
    }

    /**
     * Called by the fetch handler before calling the browser fetch on the request. The plugins are free to modify
     * the request such as appending new headers.
     *
     * @param request to request to be modified by the plugin
     * @param client the client for the originator of the request
     * @returns {Promise} That optionally contains a new instance of the request
     */
    handleRequestHook(request, client) {
      return Promise.resolve();
    }

    /**
     * Called by the fetch handler after getting a response from the browser fetch. The fetch handler will retry
     * the request if any handleResponseHook call returns true. This method returns a promise that resolves to
     * either true or false.
     *
     * @param response to response to be handled by the plugin
     * @param origRequest the original request
     * @param request the modified request
     * @param client the client id for the originator of the request
     * @returns {Promise.<Boolean>}
     */
    handleResponseHook(response, origRequest, request, client) {
      return Promise.resolve(false);
    }

    /**
     * Called by the fetch handler after getting an error from the browser fetch. The fetch handler will retry
     * the request if any handleErrorHook call returns true. This method returns a promise that resolves to
     * either true or false.
     *
     * @param error the error from the fetch request
     * @param origRequest the original request
     * @param request the modified request
     * @param client the client for the originator of the request
     * @returns {Promise.<Boolean>}
     */
    handleErrorHook(error, origRequest, request, client) {
      return Promise.resolve(false);
    }

    /**
     * Since a request is immutable, we serialize it into a config object which can be used to clone the request.
     *
     * @param request the request from which to serialize the configuration
     * @param fetchHandler fetch handler instance
     * @returns {Promise} resolved with a config object that can be used to construct a new Request. rejected on errors.
     */
    static getRequestConfig(request, fetchHandler) {
      let config;
      return Promise.resolve()
        .then(() => {
          // copy the existing headers
          const headers = {};
          for (const entry of request.headers.entries()) {
            if (entry && entry.length >= 2) {
              headers[entry[0]] = entry[1];
            }
          }

          config = {
            url: request.url,
            method: request.method,
            mode: request.mode,
            credentials: request.credentials,
            cache: request.cache,
            redirect: request.redirect,
            referrer: request.referrer,
            headers,
          };

          // copy the abort signal only if it exists
          if (request.signal) {
            config.signal = request.signal;
          }

          // Get the body if the method is PUT, POST, PATCH or DELETE
          if (request.method === 'PUT' || request.method === 'POST' || request.method === 'PATCH'
            || request.method === 'DELETE') {
            // this is a workaround due to the fact that whatwg-fetch
            // polyfill can't clone request with FormData
            // this can be removed, once the original issue is addressed
            if (request._bodyFormData && fetchHandler.isFetchPolyfill()) {
              config.bodyFormData = request._bodyFormData;
              config.bodyInit = request._bodyInit;
            } else if (request.originalBody) {
              // BUFP-34920: This is a workaround for the issue with safari not supporting extraction of a request body
              // that can be used to create a proxy request. The body is directly attached to the request as
              // originalBody and we extract it here.
              config.body = request.originalBody;
              config.attachOrignalBody = true;

              // need to delete the content-type if body is a FormData
              if (config.body instanceof FormData) {
                delete config.headers['content-type'];
              }
            } else {
              // need to clone the request before calling arrayBuffer so we don't use the body on the original request
              // need to clone the request before calling arrayBuffer so we don't use the body on the original request
              return request.clone().arrayBuffer().then((body) => {
                // RESOLVE: Is there a better way to tell if a request contains a body?
                if (body.byteLength > 0) {
                  config.body = body;
                }
                return config;
              });
            }
          }
          return config;
        })
        .catch((err) => {
          console.warn(`attempt to clone request failed, using original: ${err}`);
          // if config wasn't created for some weird reason, rethrow the error
          throw err;
        });
    }
  }

  return FetchHandlerPlugin;
});



define('vbsw/private/utils',['vbc/private/utils', 'vbc/private/pwa/pwaUtils'], (CommonUtils, PwaUtils) => {
  /**
   * Utils class
   *
   *
   *
   */
  class Utils extends CommonUtils {
    /**
     * Return a promise to load an array of resources.
     * Reject with error if there was an error or the resources don't exist.
     *
     * @param resources an array of paths to the resources to load
     * @returns {Promise} a promise to return an array of loaded resources
     */
    static getResources(resources) {
      return new Promise((resolve, reject) => {
        require(resources,
          (...loaded) => {
            resolve(loaded);
          }, reject);
      });
    }

    /**
     * If client is a string, i.e., a client id, use clients.get to resolve it. Otherwise, return it as is.
     *
     * @param client the client to resolve
     * @returns {*}
     */
    static resolveClient(client) {
      if (typeof client === 'string') {
        return self.clients.get(client);
      }
      return Promise.resolve(client);
    }

    /**
     * Invoke the given method on the fetch handler and post the response back to the client.
     *
     * If the target or method name are invalid, send a standard error response.
     *
     * @param target the target of the method invocation
     * @param methodInfo info containing method name, arguments and options
     * @param client the client associated with the caller
     */
    static invokeMethod(target, methodInfo, client) {
      const method = methodInfo.method;

      const nonce = (target && target.config && target.config.nonce) || '';

      if (!target || !target[method] || typeof target[method] !== 'function') {
        const msg = `unable to invoke method "${method}" on target ${target}`;
        console.error(msg);
        // return an 'error 'response
        Utils.postResponse(client, Promise.reject(new Error(msg)),
          `Service Worker (${nonce}): ${method}`);
        return;
      }

      const args = methodInfo.args || [];
      const options = methodInfo.options || {};

      // make the client available to the callee so it can be used to communicate back to the caller
      if (options.addClientToArgs) {
        args.push(client);
      }


      Utils.postResponse(client, target[method](...args),
        `Service Worker (${nonce}): ${method}`);
    }

    /**
     * Post the given message to the given client.
     *
     * @param client can either be a client instance or a client id that resolves to a client instance
     * @param message the message to post
     * @returns {Promise}
     */
    static postMessage(client, message) {
      // send a message to the service worker to install the plugins
      return new Promise((resolve, reject) => {
        const msgChannel = new MessageChannel();

        msgChannel.port1.onmessage = (event) => {
          console.log('Message received from client', event.data);
          const data = event.data;

          if (data.method) {
            // if the message is a method invocation, invoke it by posting it to the message handler
            // that can handle it and post the response back via message port 0
            Utils.postResponse(event.ports[0], Utils.postMessage(null, data), `${data.method}`);
          } else if (data.success) {
            resolve(data.result);
          } else {
            reject(JSON.parse(data.error));
          }
        };

        msgChannel.port1.onmessageerror = () => {
          reject('Failed to send message to client.');
        };

        Utils.resolveClient(client).then((resolvedClient) => {
          if (resolvedClient) {
            resolvedClient.postMessage(message, [msgChannel.port2]);
          } else {
            // if there's no resolved client, that means we are running in emulation or the message
            // is posted on the main thread, so use window to post the message
            window.postMessage(message, '*', [msgChannel.port2]);
          }
        })
        .catch(reject);
      });
    }

    /**
     * Post the result of the response back to the given client. Note that client in this case will always
     * be a message channel port.
     *
     * @param client the client to post the response to
     * @param response the response to be posted
     * @param logHeader a header for the log message
     */
    static postResponse(client, response, logHeader) {
      Promise.resolve(response).then((result) => {
        console.log(logHeader, 'invoked with result:', result);
        client.postMessage({
          success: true,
          result,
        });
      }).catch((error) => {
        console.log(logHeader, 'invoked with error:', error);
        client.postMessage({
          success: false,
          error: JSON.stringify(error, Utils.replaceErrors),
        });
      });
    }

    /**
     * utility function for JSON.stringify(Error), which normally just returns "{}"
     * @param key
     * @param value
     * @returns {*}
     * @private
     */
    static replaceErrors(key, value) {
      if (value instanceof Error) {
        const error = {};
        Object.getOwnPropertyNames(value).forEach(function (k) {
          error[k] = value[k];
        });
        return error;
      }
      return value;
    }


    /**
     * Extract the payload from the JWT token.
     *
     * @param jwt the JWT token
     * @returns {Object}
     */
    static extractJwtPayload(jwt) {
      try {
        // the JWT has has three parts separated by . and the payload is the second part
        let base64Payload = jwt.split('.')[1];

        // reverse url encoding
        base64Payload = base64Payload.replace(/-/g, '+').replace(/_/g, '/');

        // base64 decode the payload and parse it into a JSON object
        const payload = JSON.parse(atob(base64Payload));

        return payload;
      } catch (err) {
        // not a JWT token so simply return null
        return null;
      }
    }

    /**
     * Return the current Unix time in seconds.
     *
     * @param inMilli if false, return seconds, otherwise return milliseconds
     * @returns {number}
     */
    static getEpochTime(inMilli = false) {
      const time = new Date().getTime();

      return inMilli ? time : Math.round(time / 1000);
    }

    /**
     * Extract the expiration time and calculate the server skew from the token's payload.
     *
     * @param jwt the JWT token
     * @returns {Object}
     */
    static extractJwtExpiration(jwt) {
      const payload = Utils.extractJwtPayload(jwt);

      if (payload && payload.exp && payload.iat) {
        const currentTime = Utils.getEpochTime();

        // calculate the server time skew based on iat and the current time on the client machine
        const skew = currentTime - payload.iat;

        const expiration = {
          time: payload.exp,
          skew,
        };

        return expiration;
      }

      return null;
    }

    /**
     * Return true if a token has expired based on the extracted expiration time and server skew,
     * false otherwise.
     *
     * @param expiration expiration object returned from extractJwtExpiration
     * @param skewTolerance skew tolerance for the expiration
     * @returns {boolean}
     */
    static checkJwtExpiration(expiration, skewTolerance) {
      if (expiration) {
        const currentServerTime = Utils.getEpochTime() - expiration.skew;
        return currentServerTime > expiration.time - skewTolerance;
      }

      return false;
    }

    /**
     * Generates a sufficiently long ID to be virtually unique. This follows the UUID4
     * specification standard and is unique enough for client generated primary keys.
     * @static
     */
    static generateUID() {
      let d = Date.now();
      const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (d + (Math.random() * 16)) % 16 | 0;
        d = Math.floor(d / 16);
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
      });
      return uuid;
    };

    //
    // Here to make the API public; but will be deprecated when cookie-store
    // becomes available
    //

    /**
     * @param client The client that is making the request
     * @param name The name of the cookie fetch
     * @returns {Promise} That returns the value of the cookie or undefined if not set
     */
    static getCookie(client, name) {
      // post a message to the main application to get the cookie
      const msg = {
        method: 'vbGetCookie',
        args: [name],
      };
      return Utils.postMessage(client, msg);
    }

    /**
     * @param client The client that is making the request
     * @param name The name of the cookie to remove
     * @returns {Promise} Returns resolve if cookie is deleted
     */
    static deleteCookie(client, name) {
      // post a message to the main application to get the cookie
      const msg = {
        method: 'vbDeleteCookie',
        args: [name],
      };
      return Utils.postMessage(client, msg);
    }

    /**
     * @param client The client that is making the request
     * @param name the name of the cookie
     * @param cookie Other values other than name/value are rendered as per
     * https://wicg.github.io/cookie-store/#set-cookie-algorithm
     * @returns {Promise} Resolved if the cookie is set
     */
    static setCookie(client, name, cookie) {
      // post a message to the main application to set the cookie
      const msg = {
        method: 'vbSetCookie',
        args: [name, cookie],
      };
      return Utils.postMessage(client, msg);
    }

    /**
     * create a regex object from the scope for url matching, but also optionally match
     * a possible matrix parameter for the profile at the end.
     * assume the last segment is the version - remove it, and match anything for that segment.
     *
     * this scope:
     *    "/ic/builder/some/path/1.0/"
     * will create this RegExp:
     *    "/ic/builder/some/path/[^/]+/"
     *
     * and will match the following:
     *   "/ic/builder/rt/blou38121App2/1.0/"
     *   "/ic/builder/rt/blou38121App2/1.0;profile=x/"
     *
     * example URLs that would match the created RegExp
     * These are not for the same app/scope, deliberately, for illustration of possible URL values:
     *   proxy:        /ic/builder/some/path/1.0;profile=x/services/...
     *   token relay:  /ic/builder/design/appForMB/37983kjdh83hb=dd?/services/auth/tokenrelay/crmRestApiLatestDescribe
     *   bo:           /ic/builder/rt/appForMB/1.0/resources/data/Test?limit=25&offset=0&fields=id
     *
     * @param s fetchHandler.scope
     * @param config fetchHandler config
     * @returns {string}
     */
    static getRegexForAppScope(s, config) {
      const scope = s || '/';
      // check if this is a hosted url
      if (scope.indexOf('ic/builder') >= 0) {
        const parts = scope.split('/');

        // need to remove '1.0/', which count as two parts
        let maxSegmentsToPop = 2;

        // Since new service worker is located at app root:
        // https://masterdev-vboci.integration.test.ocp.oc-test.com/ic/builder/rt/rx/1.0/mobileApps/abc/
        // two more segments need to be popped to get to:
        // https://masterdev-vboci.integration.test.ocp.oc-test.com/ic/builder/rt/rx/
        if (PwaUtils.isWebPwaConfig(config)) {
          maxSegmentsToPop = 4; // /, abc, mobileApps, 1.0
        }
        // this code assumes the last segment is the version string, and the scope ends with a slash.
        // remove the last segment, which should be a blank when it ends with a slash.
        let popped = 1;
        const lastSegment = parts.pop();
        while (!lastSegment && popped < maxSegmentsToPop && popped < parts.length) {
          parts.pop();
          popped += 1;
        }
        const prefix = parts.join('/');
        return `${prefix}/[^/]+/`;
      }
      // not hosted, just return (happens with samples)
      return scope;
    }

    /**
     * Generate the token url from the given baseUrl and serviceName.
     *
     * @param baseUrl the base url
     * @param serviceName the service name
     * @returns {string}
     */
    static getTokenRelayUrl(baseUrl, serviceName) {
      return `${baseUrl}/services/auth/1.1/tokenrelay/${serviceName}`;
    }

    /**
     * Generate the proxy url from the given baseUrl and serviceName.
     *
     * @param baseUrl the base url
     * @param serviceName the service name
     * @returns {string}]
     */
    static getProxyUrl(baseUrl, serviceName) {
      // using new 1.1 proxy, which requires prefixed headers
      return `${baseUrl}/services/auth/1.1/proxy/${serviceName}/uri/`;
    }
  }

  return Utils;
});



define('vbsw/private/stateCache',[], () => {
  // suffix used to ensure the namespace is unique
  const NAMESPACE_SUFFIX = '_namespace';

  /**
   * Cache used to store the state of the service worker, e.g., plugin urls and offline handler, etc. It uses the cache
   * created by the service worker.
   */
  class StateCache {
    constructor(serviceWorkerCache, namespace) {
      this.swCache = serviceWorkerCache;

      // namespace is used to group a set of cached data into a single cached object
      this.namespace = namespace ? `${namespace}${NAMESPACE_SUFFIX}` : null;

      // used in emulation mode when the service worker cache is not available
      this.memoryCache = {};
    }

    /**
     * Create a namespaced cache off of the current cache.
     *
     * @param namespace namespace for the new cache
     * @returns {StateCache}
     */
    createNamespacedCache(namespace) {
      return new StateCache(this.swCache, namespace);
    }

    /**
     * Retrieve the cached data for the given url. If the cache is namespaced, the namespace will first be used
     * to retrieve the cached data and the actual data will be indexed using the given url.
     *
     * @param url the url for the cached data
     * @returns {Promise}
     */
    get(url) {
      // use the namespace to retrieve the data if exists
      const cacheUrl = this.namespace || url;

      return this.getInternal(cacheUrl).then((data) => {
        if (data && this.namespace) {
          return data[url];
        }

        return data;
      });
    }

    /**
     * Retrieve the data for the given url from the underlying cache.
     *
     * @param url the url for the cached data
     * @returns {Promise}
     * @private
     */
    getInternal(url) {
      if (this.swCache) {
        return this.swCache.match(url).then((response) => {
          if (response) {
            return response.json();
          }

          return undefined;
        });
      }

      // else look up from the memory cache
      return Promise.resolve(this.memoryCache[url]);
    }

    /**
     * Cache the data at the given url. If the cache is namespaced, the namespace will first be used
     * to retrieve the cached data and the data will be added to the cached data and written back to the cache.
     *
     * @param url the url for where to cache the data
     * @param data the data to cache
     * @returns {Promise<void>|Promise<R>|Promise.<T>}
     */
    put(url, data) {
      if (this.namespace) {
        // first get the cached data using the namespace
        return this.getInternal(this.namespace).then((cachedData) => {
          const dataToCache = cachedData || {};

          // add the new data to the cached data
          dataToCache[url] = data;

          // write the updated cached data back
          return this.putInternal(this.namespace, dataToCache);
        });
      }

      return this.putInternal(url, data);
    }

    /**
     * A version of put that works with opaque responses by putting them directly in a cache.
     * @param url the url for where to cache the data
     * @param data the data to cache
     * @returns {Promise<void>}
     */
    putOpaque(url, data) {
      if (this.swCache) {
        return this.swCache.put(url, data).catch((err) => {
          console.log('putOpaque', url, 'failed with', err);
        });
      }
      return Promise.resolve();
    }

    /**
     * Put the data at the given url into the underlying cache.
     *
     * @param url the url for where to cache the data
     * @param data the data to cache
     * @returns {Promise}
     * @private
     */
    putInternal(url, data) {
      if (this.swCache) {
        const response = new Response(JSON.stringify(data));
        return this.swCache.put(url, response).catch((err) => {
          console.log('putInternal', url, 'failed with', err);
        });
      }

      // else put it in the memory cache
      this.memoryCache[url] = data;

      return Promise.resolve();
    }

    getResponse(url, options) {
      if (this.swCache) {
        return this.swCache.match(url, options);
      }
      return Promise.resolve();
    }

    add(url) {
      if (this.swCache) {
        return this.swCache.add(url).catch((err) => {
          console.log('add', url, 'failed with', err);
          StateCache.checkQuota();
        });
      }
      return Promise.resolve();
    }

    /**
     * Delete the cached data matching the given url. If the cache is namespaced, the namespace will first be used
     * to retrieve the cached data and the data will be deleted from it and then the cached data will be written
     * back to the cache.
     *
     * @param url the url for the cached data to delete
     * @returns {Promise}
     */
    delete(url) {
      if (this.namespace) {
        // first get the cached data using the namespace
        return this.getInternal(this.namespace).then((cachedData) => {
          const dataToCache = cachedData || {};

          // delete the data using the given url
          delete dataToCache[url];

          // write the updated cached data back
          return this.putInternal(this.namespace, dataToCache);
        });
      }

      return this.deleteInternal(url);
    }

    /**
     * Delete the cached data matching the given url from the underlying cache.
     *
     * @param url the url for the cached data to delete
     * @returns {Promise}
     * @private
     */
    deleteInternal(url) {
      if (this.swCache) {
        return this.swCache.delete(url);
      }

      // else delete it from the memory cache
      delete this.memoryCache[url];

      return Promise.resolve();
    }
    /**
     * Clear the cache. Note that this method is only supported if the cache is namespaced. All the cached data will
     * be deleted using the namespace.
     *
     * @returns {Promise}
     */
    clear() {
      if (this.namespace) {
        return this.deleteInternal(this.namespace);
      }
      // eslint-disable-next-line prefer-promise-reject-errors
      return Promise.reject('StateCache.clear is not supported for a cache without a namespace.');
    }

    /**
     * @returns {Promise<boolean>} a promise to true, if cache is non empty, a promise
     * to false otherwise.
     */
    isEmpty() {
      return Promise.resolve(this.swCache.keys())
        .then((keys) => {
          if (Array.isArray(keys) && keys.length > 0) {
            return false;
          }
          return true;
        });
    }

    static checkQuota() {
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        navigator.storage.estimate().then(({
          usage, quota,
        }) => {
          console.log('checkQuota: Using', usage, 'out of', quota, 'bytes.');
        });
      }
    }
  }
  return StateCache;
});

/* eslint-disable class-methods-use-this, no-unused-vars */



define('vbsw/private/cacheStrategy',[], () => {
  /**
   * Defines hook points for caching and fetching application resources and RT scripts during ServiceWorker and
   * application lifecycle.
   * The default CacheStrategy does not cache any assets.
   */
  class CacheStrategy {
    constructor(config) {
      this.config = config;
    }

    /**
     * Determines whether service worker cache lookup should be performed for a given url
     * @param {*} url
     * @returns a {Promise<boolean>} a promise that resolves to a false value by default
     */
    shouldCheckCache(url) {
      return Promise.resolve(false);
    }

    /**
     * @param url the resource url to lookup in the cache
     * @param mode determines whether any optimizations should be performed during cache lookup
     * @returns {Promise<void>} a promise to a cached resource or undefined, if no resource matching given url
     * was found in the cache.
     */
    checkCache(url, mode) {
      return Promise.resolve();
    }

    /**
     *
     * @returns {Promise<void>} a promise to cache assets during ServiceWorker install event
     */
    cacheOnInstall() {
      return Promise.resolve();
    }

    /**
     * @returns {Promise<void>} a promise to cache assets on every request
     */
    cacheOnRequest() {
      return Promise.resolve();
    }

    /**
     * @param request the request to consider for dynamic caching
     * @returns {Promise<Response>} a promise to a response that was fetched and cached, or undefined, if response
     * was not fetched
     */
    fetchAndCache(request) {
      return Promise.resolve();
    }
  }
  return CacheStrategy;
});



define('vbsw/private/constants',[], () => {
  const Constants = {};

  // constants for all the supported authentication type
  Constants.AuthenticationType = {
    ORACLE_CLOUD: 'oraclecloud', // default
    BASIC: 'basic',
    OAUTH: 'oauth',
    IMPLICIT: 'implicit',
    TOKEN_RELAY: 'tokenRelay',
    DIRECT: 'direct',
    NONE: 'none',
    HTTP_SIGNATURE_OCI: 'http_signature_oci',
  };

  // header for the authentication type
  Constants.AUTHENTICATION_TYPE_HEADER = 'vb-authentication-type';

  // constants related to token relay
  Constants.TOKEN_RELAY_URL_HEADER = 'vb-token-relay-url';
  Constants.TOKEN_RELAY_AUTH_HEADER = 'vb-token-relay-authentication';

  // used when using the new V1.1 proxy; preprocessor may add this; postprocessor will prefix headers if present.
  // stripped before request.
  Constants.PROXY_HEADERNAME_HEADER = 'vb-proxy11-headers';

  // when using the proxy, all headers that are not meant for the proxy should have prefixed names
  // and when we strip headers, we should NOT remove proxy headers
  Constants.HEADER_PROXY_PREFIX = 'vb-proxy-';
  Constants.HEADER_PROXY_HEADER_PREFIX = `${Constants.HEADER_PROXY_PREFIX}header-`;

  // for 'passthrough' support: BUFP-39984
  Constants.HEADER_PASSTHROUGH = 'vb-auth-settings';

  // header for specifying an alternate header name for the authorization header
  Constants.ALT_AUTHORIZATION_HEADER_NAME = 'vb-alt-authorization-header-name';

  // special header for using cached response when offline using the offline toolkit, e.g.,
  // currentuser request uses it to cache its response
  Constants.USE_CACHED_RESPONSE_WHEN_OFFLINE = 'vb-use-cached-response-when-offline';

  Constants.PATH_SEPARATOR = '/';

  /**
  * A mode to force cache lookup for index.html even when online
  */
  Constants.LOOKUP_INDEX_MODE = 'lookupIndex';

  return Constants;
});



define('vbsw/private/pwa/pwaUtils',['vbsw/private/constants', 'vbc/private/pwa/pwaUtils'], (Constants, CommonPwaUtils) => {
  class PwaUtils extends CommonPwaUtils {
    /**
     * For PWA support, service worker needs to pre cache application shell. The application resource url's
     * are relative to service's worker scope, app path and asset version. This function computes the app path portion
     * of a resource url (ignoring asset versions since it does not apply to start url)
     *
     * For example, for the following preview vbInitConfig:
     *
     * window.vbInitConfig = {
     * JET_CDN_PATH: 'https://static.oracle.com/cdn/jet/',
     * JET_CDN_VERSION: '9.0.1',
     * DEBUG: true,
     * CONTEXT_ROOT: '',
     * APP_ID: '0821',
     * APP_VERSION: '1.0',
     * APP_URL_PREFIX: 'design',
     * IS_DT_MODE: true,
     * IS_MOBILE: false,
     * APP_PATH: 'webApps/test',
     * BASE_URL_TOKEN: 'version_123',
     * }
     *
     * the app path would be:
     *
     * "preview/webApps/test/
     *
     * and for the following stage vbInitConfig:
     *
     * window.vbInitConfig = {
     * JET_CDN_PATH: 'https://static.oracle.com/cdn/jet/',
     * JET_CDN_VERSION: 'v5.2.0',
     * DEBUG: false,
     * CONTEXT_ROOT: '',
     * APP_ID: '0821',
     * APP_VERSION: '1.0',
     * APP_URL_PREFIX: 'rt',
     * IS_DT_MODE: false,
     * IS_MOBILE: false,
     * APP_PATH: 'webApps/test',
     * }
     *
     * the app path would be:
     * "webApps/test/"
     *
     * @param config vbInitConfig
     * @return {String} the application path based on vbInitConfig parameters, or undefined
     */
    static computeAppPath(config) {
      if (!config) {
        return undefined;
      }
      let appPath = '';
      if (config.IS_DT_MODE) {
        appPath += 'preview/';
      }
      if (config.APP_PATH) {
        appPath += config.APP_PATH.endsWith(Constants.PATH_SEPARATOR) ? config.APP_PATH :
          `${config.APP_PATH}${Constants.PATH_SEPARATOR}`;
      }
      return (appPath.length > 0) ? appPath : undefined;
    }

    /**
     * @returns {Array<string>} list of locales supported by PWA
     */
    static getLocale() {
      // TODO: Get locale from VB runtime - oj.Config.getLocale(); does not work
      // when called too early before requirejs.config is set up
      // https://jira.oraclecorp.com/jira/browse/BUFP-25113
      return 'en-US';
    }

    /**
     * Creates an array of all locales that should be supported based on a single language tag.
     * @param languageTag language tag, for example, <i>en-US</i>
     * @returns {Array<string>} list of individual locales, for example, <i>['en', 'en-US']</i>
     */
    static parseLocale(languageTag) {
      const locales = [];
      if (typeof languageTag === 'string') {
        const languageTags = languageTag.split('-');
        let previousLocale;
        let newLocale;
        locales.push(...languageTags.map((l) => {
          newLocale = previousLocale ? `${previousLocale}-${l}` : l;
          previousLocale = newLocale;
          return newLocale;
        }));
      }
      return locales;
    }

    /**
     * @param url request url
     * @param config configuration object for the service worker
     * @returns {boolean} true, if request matches JET path specified in the config, for example:
     * 'https://static.oracle.com/cdn/jet/v6.0.0/'
     */
    static isJetRequest(url, config) {
      if (config && config.jetPath) {
        return url.startsWith(config.jetPath);
      }
      return false;
    }

    /**
     * Resource path is constructed as a url relative to service worker scope by combining appPath and
     * baseUrlToken.
     * @param appPath relative to scope, location of application assets. For example: "mobileApps/FixitFast/"
     * @param baseUrlToken used for versioning of application artifacts. For example: "version_1537547325000"
     * @returns {string} application asset path.
     */
    static constructScopeRelativeResourcePath(appPath, baseUrlToken) {
      return `.${PwaUtils.constructRelativeResourcePath(appPath, baseUrlToken)}`;
    }


    static constructRelativeResourcePath(appPath, baseUrlToken) {
      const path = `${PwaUtils.postSlash(appPath)}${PwaUtils.postSlash(baseUrlToken)}`;
      if (path) {
        return path.startsWith(Constants.PATH_SEPARATOR) ? `${path}` : `${Constants.PATH_SEPARATOR}${path}`;
      }
      return Constants.PATH_SEPARATOR;
    }
  }
  return PwaUtils;
});



define('vbsw/private/pwa/appShell',[
  'vbsw/private/pwa/pwaUtils',
  'vbc/private/log',
  'vbc/private/performance/performance',
], (PwaUtils, Log, Performance) => {
  const logger = Log.getLogger('/vbsw/private/pwa/appShell');

  const SKIP_CACHE_LOOKUP_PATTERN_KEY = 'skipCacheLookupPattern';

  const VB = [
    'lib/third-party-libs.js',
    'resources/vb-icon-font.css',
    'resources/vb-icon-font.woff',
  ];

  const WEB_MANIFEST = 'manifest.json';

  /**
   * This class is used by the service worker to cache application shell and required js files.
   * While VB runtime scripts are predefined, the application shell content is specified
   * in appShellCache.json file. This file can also be used to add additional content to the cache, for
   * example, files fetched from locations other than application root.
   */
  class AppShell {
    /**
     * Create an instance of AppShell.
     *
     * @param fetchHandler the FetchHandler created  by the ServiceWorker
     */
    constructor(fetchHandler) {
      // FetchHandler is created by the service worker and passed in here. This approach will allow to test AppShell
      // using a mock FetchHandler
      this.fetchHandler = fetchHandler;
    }

    /**
     * Load JSON application shell cache file. The file should be in the following structure:
     * {
     * "appFiles" : [
     * ],
     *  "files" : [
     * ],
     * }
     * @param shellPath a location of appShellCache.json file, relative to SW scope. For example:
     * <i>./mobileApps/testApp/version_1552430187000/appShellCache.json</i>
     * @returns {Promise<{}>} a promise to application shell cache file. If application shell file fails to load,
     * promise rejects.
     */
    loadAppShellFile(shellPath) {
      return PwaUtils.loadAppShellFile(shellPath, this.fetchHandler.handleRequest, this.fetchHandler);
    }

    /**
     * Creates a list VB runtime files that should be cached in PWA cache. This includes:
     * - visual-runtime.js and visual-runtime.js.map (or debug versions of these)
     * - third-party-libs.js,
     * - resources/vb-icon-font.css,
     * - resources/vb-icon-font.woff,
     *
     * @param modulePath location of VB runtime, for example: <i>https://static.oracle.com/cdn/vb/v19.1.3.4/</i>
     * @param debug a flag that indicates whether debug VB sources should be cached
     * @returns {Promise<void>} a promise to a list of VB files to cache
     */
    static getVBCacheList(modulePath = '', debug) {
      return Promise.resolve().then(() => {
        let files = [];
        files.push(...VB);
        files.push(`visual-runtime${debug ? '-debug' : ''}.js`);
        files.push(`visual-runtime${debug ? '-debug' : ''}.js.map`);
        files = files.map((f) => `${PwaUtils.postSlash(modulePath)}${f}`);
        return files;
      });
    }

    /**
     * Cache VB runtime files. This includes:
     * - visual-runtime.js and visual-runtime.js.map (or debug versions of these)
     * - third-party-libs.js,
     * - resources/vb-icon-font.css,
     * - resources/vb-icon-font.woff,
     *
     * @param modulePath location of VB runtime, for example: <i>https://static.oracle.com/cdn/vb/v19.1.3.4/</i>
     * @param debug a flag that indicates whether debug VB sources should be cached
     * @returns {Promise<void>} a promise to cache VB files
     */
    cacheVB(modulePath = '', debug) {
      const cacheMark = ['appShell.cacheVB'];
      return Promise.resolve()
        .then(() => Performance.markStart(cacheMark))
        .then(() => AppShell.getVBCacheList(modulePath, debug))
        .then((files) => this.cache(files))
        .then((cached) => {
          Performance.markEnd(cacheMark);
          return cached;
        });
    }

    /**
     * Creates a list of application shell files that should be cached in PWA cache.
     * @param appFiles a list of application shell files to cache
     * @param appPath relative to scope, location of application assets. For example: <i>mobileApps/testApp/</i>
     * @param baseUrlToken used for versioning of application artifacts. For example: <i>version_1552430187000</i>
     * @returns {Promise<void>} a promise to a list of application shell files to cache
     */
    static getAppFilesCacheList(appFiles = [], appPath, baseUrlToken) {
      return Promise.resolve().then(() => {
        const files = [];
        // add (versioned) application artifacts
        if (appFiles) {
          const path = PwaUtils.constructScopeRelativeResourcePath(appPath, baseUrlToken);
          files.push(...appFiles.map((file) => `${path}${file}`));
        }
        return files;
      });
    }

    /**
     * Caches application shell.
     * @param appFiles a list of application shell files to cache
     * @param appPath relative to scope, location of application assets. For example: <i>mobileApps/testApp/</i>
     * @param baseUrlToken used for versioning of application artifacts. For example: <i>version_1552430187000</i>
     * @returns {Promise<void>} a promise to cache application shell files
     */
    cacheAppFiles(appFiles = [], appPath, baseUrlToken) {
      const cacheMark = ['appShell.cacheAppShell'];
      return Promise.resolve()
        .then(() => Performance.markStart(cacheMark))
        .then(() => AppShell.getAppFilesCacheList(appFiles, appPath, baseUrlToken))
        .then((files) => this.cacheApplicationAssets(files))
        .then((cached) => {
          Performance.markEnd(cacheMark);
          return cached;
        });
    }

    /**
     * Creates a list of application's unversioned assets.
     * @param appPath relative to scope, location of application assets. For example: <i>mobileApps/testApp/</i>
     * @returns {Promise<void>} a promise to a list of application's unversioned assets
     */
    static getUnversionedAssetsList(appPath) {
      return Promise.resolve().then(() => {
        const files = [];
        const path = PwaUtils.constructScopeRelativeResourcePath(appPath);
        // add request for application start url, for example:
        // eslint-disable-next-line max-len
        // https://kipling-vbdemo.uscom-central-1.oraclecloud.com/ic/builder/design/FixitFastOfflineOOW_IC_AMC/1.0/mobileApps/FixitFast/
        logger.info('PWA: getUnversionedAssetsList (', path, ')');
        files.push(path);
        files.push(`${path}${WEB_MANIFEST}`);
        return files;
      });
    }

    /**
     * Cache start url and other unversioned assets, such as web manifest (manifest.json)
     * @param appPath relative to scope, location of application assets. For example: <i>mobileApps/testApp/</i>
     * @returns {Promise<void>} a promise to cache application's start url and web manifest
     */
    cacheUnversionedAssets(appPath) {
      return AppShell.getUnversionedAssetsList(appPath).then((files) => this.cacheApplicationAssets(files));
    }

    /**
     * @param files a list of urls to cache
     * @returns {Promise<void>} a promise to fetch and cache requests
     * @see https://filipbech.github.io/2017/02/service-worker-and-caching-from-other-origins
     */
    cacheFiles(files = []) {
      return Promise.resolve()
        .then(() => {
          logger.info('PWA: cacheFiles()');
          return files.map((f) => fetch(f).then((response) => this.fetchHandler.stateCache.putOpaque(f,
            response)));
        })
        .then((cachePromises) => Promise.all(cachePromises));
    }

    /**
     * Invoke FetchHandler/Cache API to add files to the service worker state cache.
     *
     * @param files an array of url's to cache
     * @returns {Promise<void>} a promise to cache specified files
     */
    cache(files = []) {
      return Promise.resolve()
        .then(() => {
          const cachePromises = files.map((f) => this.fetchHandler.cacheFile(f)
            .catch((error) => {
              logger.error('PWA: cache', f, error);
            }));
          return Promise.all(cachePromises);
        });
    }

    /**
     * Invoke FetchHandler/Cache API to add files to the service worker application cache.
     *
     * @param files an array of url's to cache
     * @returns {Promise<void>} a promise to cache specified files
     */
    cacheApplicationAssets(files) {
      return Promise.resolve().then(() => {
        if (files && files.length > 0 && this.fetchHandler.appCache !== undefined) {
          const cachePromises = files.map((f) => this.fetchHandler.appCache.add(f)
            .catch((error) => {
              logger.error('PWA: cacheApplicationAssets', f, error);
            }));
          return Promise.all(cachePromises);
        }
        return Promise.resolve('cacheApplicationAssets(): no files cached');
      });
    }

    cacheSkipCacheLookupPattern(appShell) {
      return Promise.resolve()
        .then(() => {
          if (appShell.skipCacheLookupPattern) {
            return this.fetchHandler.stateCache.put(SKIP_CACHE_LOOKUP_PATTERN_KEY, appShell.skipCacheLookupPattern);
          }
          return undefined;
        });
    }

    getSkipCacheLookupPattern() {
      return this.fetchHandler.stateCache.get(SKIP_CACHE_LOOKUP_PATTERN_KEY);
    }

    /**
     * A promise to cache application shell files and VB runtime
     *
     * @param config the service worker configuration
     * @returns {Promise<void>} a promise to cache all required application files for offline access that never rejects.
     * The resolved value is undefined.
     */
    cacheAppShell({
      shellPath, appPath, baseUrlToken, modulePath, debug = false,
    } = {}) {
      return Promise.resolve()
        .then(() => {
          logger.info('PWA: cacheAppShell()');
          return this.cacheVB(modulePath, debug);
        })
        .then(() => this.cacheUnversionedAssets(appPath))
        .then(() => this.loadAppShellFile(shellPath))
        .then((appShell) => {
          if (appShell) {
            const cacheSkipCacheLookupPatternPromise = this.cacheSkipCacheLookupPattern(appShell);
            const cacheAppFilesPromise = this.cacheAppFiles(appShell.appFiles, appPath, baseUrlToken);
            const cacheFilesPromise = this.cacheFiles(appShell.files);
            return Promise.all([cacheAppFilesPromise, cacheFilesPromise, cacheSkipCacheLookupPatternPromise]);
          }
          throw new Error('cacheAppShell(): No app shell');
        })
        .catch((error) => {
          logger.error('PWA: cacheAppShell(', shellPath, ')', error);
          // there is nothing the caller can do when caching fails, so just return undefined
          return undefined;
        });
    }
  }
  return AppShell;
});



define('vbsw/private/pwa/pwaCacheStrategy',[
  'vbsw/private/pwa/appShell',
  'vbsw/private/cacheStrategy',
  'vbsw/private/pwa/pwaUtils',
  'vbc/private/log',
  'vbsw/private/constants',
], (AppShell, CacheStrategy, PwaUtils, Log, Constants) => {
  const logger = Log.getLogger('/vbsw/private/pwa/pwaCacheStrategy');

  const corsMode = { mode: 'cors' };
  class PwaCacheStrategy extends CacheStrategy {
    constructor(handler) {
      super(handler.config);
      this.handler = handler;
      this.appShell = new AppShell(handler);
      // ignoreSearchOptions can be set to undefined when skipIgnoreSearch is true
      this.ignoreSearchOptions = (handler.config && handler.config.skipIgnoreSearch) ? undefined : {
        ignoreSearch: true,
      };
    }

    getIgnoreSearchOptions(url) {
      return (url.indexOf('?') > 0) ? this.ignoreSearchOptions : undefined;
    }

    /**
     * @returns {Promise<void>} a Promise to a regular expression constructed from string skip cache lookup pattern,
     * if one was specified in appShellCache.json (in skipCacheLookupPattern property).
     */
    getSkipCacheLookupRegEx() {
      return Promise.resolve()
        .then(() => {
          if (!this.skipCacheLookupRegExPromise) {
            this.skipCacheLookupRegExPromise = this.appShell.getSkipCacheLookupPattern()
              .then((skipCacheLookupPattern) => {
                if (skipCacheLookupPattern) {
                  try {
                    logger.info(`PWA: skip cache lookup pattern found: '${skipCacheLookupPattern}'`);
                    const skipCacheLookupRegEx = new RegExp(skipCacheLookupPattern);
                    logger.info(`PWA: skip cache lookup RegEx constructed: ${skipCacheLookupRegEx}`);
                    return skipCacheLookupRegEx;
                  } catch (error) {
                    logger
                      .error(`Could not create skip cache lookup regular expression from '${skipCacheLookupPattern}'`,
                        error);
                  }
                }
                return undefined;
              });
          }
          return this.skipCacheLookupRegExPromise;
        });
    }

    /**
     * Determines if service worker cache lookup should be performed for a given url
     * @param {*} request
     * @returns a {Promise<boolean>} a promise that resolves to true for url's for which service worker cache
     * lookup should be performed. Application developers can control which url's fall into this category by
     * adding a skipCacheLookupPattern regular expression pattern in app shell cache. One use case would be to exclude
     * REST calls from service worker cache lookup.
     */
    shouldCheckCache(url) {
      return this.getSkipCacheLookupRegEx()
        .then((skipCacheLookupRegEx) => {
          if (skipCacheLookupRegEx && skipCacheLookupRegEx.test(url)) {
            logger.info(`PWA: skipping cache lookup for ${url}`);
            return Promise.resolve(false);
          }
          return Promise.resolve(true);
        });
    }

    /**
     * @param url the resource url to lookup in the cache
     * @param mode determines whether any optimizations should be performed during cache lookup
     * @returns {Promise<void>} a promise to a cached resource, unless this is a start url and the browser is online.
     * In this case, no cache lookup will be performed so that the latest index.html and consequently vbInitConfig
     * can be picked up.
     */
    checkCache(url, mode) {
      // Due to Chrome bug: https://bugs.chromium.org/p/chromium/issues/detail?id=682677
      // ignoreSearch=true drastically reduces cache lookup performance, so it should only be used when needed -
      // when a resource contains '?' to indicate query string. IgnoreSearch lookup can be skipped altogether by setting
      // vbInitConfig.SERVICE_WORKER_CONFIG.skipIgnoreSearch flag to true
      const options = this.getIgnoreSearchOptions(url);
      // TODO: optimize this so we are not checking state cache for application assets and data requests
      // https://jira.oraclecorp.com/jira/browse/BUFP-25503
      return Promise.resolve()
        .then(() => {
          if (this.handler && this.handler.stateCache) {
            return this.handler.stateCache.getResponse(url, options);
          }
          return undefined;
        })
        .then((response) => {
          if (response) {
            return response;
          }
          return this.getStartUrl()
            .then((startUrl) => {
              // if online, don't return cached version of start url, unless overwritten by LOOKUP_INDEX_MODE mode
              if (startUrl && url.endsWith(startUrl) && (mode !== Constants.LOOKUP_INDEX_MODE)) {
                logger.finer('PWA: checkCache(): skipped cache lookup for', startUrl);
                return undefined;
              }
              if (this.handler.appCache) {
                logger.finer('PWA: checkCache(): cache lookup for', url);
                return this.handler.appCache.getResponse(url, options);
              }
              return undefined;
            });
        })
        .catch((err) => {
          logger.warn('PWA: checkCache(): failed to checkCache for', url, err);
        });
    }

    /**
     *
     * @returns {Promise<String>} a promise to an application's start url, if browser is online, or a promise
     * to undefined if the browser is offline or start url cannot be constructed
     */
    getStartUrl() {
      return Promise.resolve()
        .then(() => {
          if (!PwaUtils.isOnline()) {
            return undefined;
          }
          return PwaUtils.constructRelativeResourcePath(this.config.appPath);
        });
    }

    cacheOnInstall() {
      logger.info('PWA: cacheOnInstall:', this.config);
      return this.appShell.cacheAppShell(this.config)
        .then(() => {
          // reset skipCacheLookupRegExPromise after install
          this.skipCacheLookupRegExPromise = null;
          return undefined;
        });
    }

    /**
     * @returns {Promise<undefined>} a Promise to recreate and update PWA caches in case caches have been cleared that
     * never rejects. The resolved value is undefined.
     */
    cacheOnRequest() {
      return this.detectEmptyCaches()
        .then((empty) => {
          if (empty) {
            logger.warn('PWA: cacheOnRequest:', this.config, ': empty caches detected.');
            return this.handler.openCaches().then(() => this.appShell.cacheAppShell(this.config));
          }
          return undefined;
        })
        .catch((err) => {
          logger.error('PWA: Failed to cacheOnRequest:', err);
        });
    }

    /**
     * @returns {Promise<boolean>} a promise that resolves to true if either state or application cache is empty.
     */
    detectEmptyCaches() {
      return Promise.all([this.handler.appCache.isEmpty(), this.handler.stateCache.isEmpty()])
        .then((results) => results.some((isEmpty) => isEmpty))
        .catch(() => { // eslint-disable-line arrow-body-style
          // ignore, in case of errors, assume caches are empty
          return true;
        });
    }

    /**
     * Dynamic caching is currently only supported for JET content
     * @returns {Promise<Object|undefined>} a promise to a response that was fetched and cached, or undefined, if:
     * - request is not recognized as a JET resource (based on path)
     * - fetch failed
     */
    fetchAndCache(request) {
      return Promise.resolve()
        .then(() => {
          if (PwaUtils.isJetRequest(request.url, this.config)) {
            //
            // JET requests that are result of calling requirejs are issued in no-cors mode, and therefore end up
            // as opaque responses in state cache. Since opaque responses result in cache bloat, as browsers cannot
            // accurately determine response size (see Chrome 7MB limit:
            // https://developers.google.com/web/tools/chrome-devtools/progressive-web-apps#opaque-responses),
            // and JET CDN supports CORS, we need to issue cors mode requests for JET resources.
            //
            let jetRequest = request;
            if (request.mode === 'no-cors') {
              jetRequest = new Request(request.url, corsMode);
            }
            return this._fetchAndCache(jetRequest);
          }
          return undefined;
        })
        .catch((err) => {
          console.log('PWA: Failed to fetchAndCache', request.url, err);
        });
    }

    /**
     * @param request
     * @returns {Promise<Object>} a promise to fetch a request and cache it in the state cache
     * @private
     */
    _fetchAndCache(request) {
      return fetch(request)
        .then((response) => {
          if (response) {
            logger.finer('PWA: fetchAndCache() request url:', request.url);
            // calling statCache.put ends up modifying response, which used to break for opaque responses from JET CDN
            // JET CDN responses no longer seem opaque, btw, but still there is no reason to modify them
            return this.handler.stateCache.putOpaque(request, response.clone());
          }
          return response;
        });
    }
  }
  return PwaCacheStrategy;
});



define('vbsw/private/cacheStrategyFactory',[
  'vbsw/private/cacheStrategy',
  'vbsw/private/pwa/pwaCacheStrategy',
], (CacheStrategy, PwaCacheStrategy) => {
  /**
   * A factory to create a CacheStrategy for caching based on the ServiceWorker configuration.
   */
  class CacheStrategyFactory {
    static createCacheStrategy(fetchHandler) {
      const config = fetchHandler.config;
      if (config && !config.disabled && config.isPwa) {
        return new PwaCacheStrategy(fetchHandler);
      }
      return new CacheStrategy(config);
    }
  }
  return CacheStrategyFactory;
});




define('vbsw/private/pwa/applicationCache',['vbsw/private/stateCache'], (StateCache) => {
  /**
   * Cache used to store static application assets for PWA's.
   * This cache is not namespaced, and it ignores query parameters on the lookup.
   */
  class ApplicationCache extends StateCache {
    /**
     * Retrieves the cached data for the given url.
     *
     * @param url the url for the cached data
     * @returns {Promise}
     */
    get(url) {
      if (this.swCache) {
        return this.swCache.match(url).then((response) => {
          if (response) {
            return response.json();
          }
          return Promise.resolve();
        });
      }
      return Promise.resolve();
    }

    /**
     * Put the data directly in a cache.
     * @param url the url for where to cache the data
     * @param data the data to cache
     * @returns {Promise<void>}
     */
    put(url, data) {
      if (this.swCache) {
        return this.swCache.put(url, data).catch((err) => {
          console.log('put', url, 'failed with', err);
        });
      }
      return Promise.resolve();
    }

    getResponse(url, options) {
      if (this.swCache) {
        return this.swCache.match(url, options);
      }
      return Promise.resolve();
    }
  }
  return ApplicationCache;
});

/* eslint-disable no-underscore-dangle */



/**
 * optCacheStrategies is overriding the default JET's cache strategy for a very specific case only, so
 * that in the native mobile case the current user information can be stored and cached.  Currently,
 * the IDCS API used for retrieving the user information, and Digest API used for extension registry,
 * has the no store / no cache headers and the default JET's cache strategy doesn't cache the needed info as a result.
 */
define('vbsw/private/optCacheStrategies',[
  'vbsw/private/utils',
  'vbc/private/log',
], (Utils, Log) => {
  const logger = Log.getLogger('/vbsw/private/mobileCacheStrategies');

  function _handleExpires(request, response, PersistenceUtils) {
    return Promise.resolve().then(() => {
      // expires header - Contains a UTC Datetime value
      // which can be used to directly populate x-oracle-jscpt-cache-expiration-date
      // if x-oracle-jscpt-cache-expiration-date is already populated then that wins
      const expiresDate = response.headers.get('Expires');
      const cacheExpirationDate = response.headers.get('x-oracle-jscpt-cache-expiration-date');

      if (expiresDate
        && PersistenceUtils.isCachedResponse(response)
        && (!cacheExpirationDate || cacheExpirationDate.length === 0)) {
        response.headers.set('x-oracle-jscpt-cache-expiration-date', expiresDate);
        logger.info('Set x-oracle-jscpt-cache-expiration-date header based on HTTP Expires header');
      }

      return response;
    });
  }

  function _getCacheControlDirective(headers, directive) {
    // Retrieve the Cache-Control headers and parse
    const cacheControl = headers.get('Cache-Control');

    if (cacheControl) {
      const cacheControlValues = cacheControl.split(',');

      let i;
      let cacheControlVal;
      let splitVal;
      for (i = 0; i < cacheControlValues.length; i += 1) {
        cacheControlVal = cacheControlValues[i].trim();
        // we only care about cache-control values which start with the directive
        if (cacheControlVal.indexOf(directive) === 0) {
          splitVal = cacheControlVal.split('=');
          return (splitVal.length > 1) ? splitVal[1].trim() : true;
        }
      }
    }

    return null;
  }

  function _handleMaxAge(request, response, PersistenceUtils) {
    return Promise.resolve().then(() => {
      // max-age cache header - Use it to calculate and populate cacheExpirationDate.
      // Takes precedence over Expires so should be called after processing Expires.
      // Also, unlike  Expires it's relative to the Date of the request
      const cacheControlMaxAge = _getCacheControlDirective(response.headers, 'max-age');

      if (cacheControlMaxAge != null) {
        if (PersistenceUtils.isCachedResponse(response)) {
          let requestDate = request.headers.get('Date');
          if (!requestDate) {
            requestDate = (new Date()).toUTCString();
          }
          const requestTime = (new Date(requestDate)).getTime();
          const expirationTime = requestTime + (1000 * cacheControlMaxAge);
          const expirationDate = new Date(expirationTime);
          response.headers.set('x-oracle-jscpt-cache-expiration-date', expirationDate.toUTCString());
          logger.info('Set x-oracle-jscpt-cache-expiration-date header based on HTTP max-age header');
        }
      }
      return response;
    });
  }

  function _handleRevalidate(request, response, mustRevalidate, PersistenceUtils, PersistenceManager) {
    return Promise.resolve().then(() => {
      // If we are offline, we can't revalidate so just return the cached response
      // unless mustRevalidate is true, in which case reject with error.
      // If we are online then if the response is a cached Response, we need to
      // revalidate. If the revalidation returns 304 then we can just return the cached version
      // handleRevalidate can be called multiple times due to different cache
      // headers, requiring it however a server call, if needed, only be made
      // once because after that we will have a server response and any subsequent
      // handleRevalidate calls will just resolve.
      if (PersistenceUtils.isCachedResponse(response)) {
        if (!PersistenceManager.isOnline()) {
          // If we must revalidate then we MUST return a 504 when offline
          // https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.9.4
          // must-revalidate is the only case under which we CANNOT return a stale
          // response. If must-revalidate is not set then according to spec it's ok
          // to return a stale response.
          if (mustRevalidate) {
            return PersistenceUtils.responseToJSON(response).then((responseData) => {
              // eslint-disable-next-line no-param-reassign
              responseData.status = 504;
              // eslint-disable-next-line no-param-reassign
              responseData.statusText = 'cache-control: must-revalidate failed due to application being offline';
              logger.info('Returning Response status 504 based HTTP revalidation');
              return PersistenceUtils.responseFromJSON(responseData);
            });
          }

          return response;
        }

        return PersistenceManager.browserFetch(request).then((serverResponse) => {
          if (serverResponse.status === 304) {
            return response;
          }

          // revalidation succeeded so we should remove the old entry from the cache
          return PersistenceManager.getCache().delete(request).then(() => {
            logger.info('Removing old entry based on HTTP revalidation');
            return serverResponse;
          });
        });
      }

      // If it's not a cached Response then it's already from the server so just resolve the response
      return response;
    });
  }

  function _handleIfCondMatch(request, response, PersistenceUtils, PersistenceManager) {
    return Promise.resolve().then(() => {
      // If-Match or If-None-Match headers
      const ifMatch = request.headers.get('If-Match');
      const ifNoneMatch = request.headers.get('If-None-Match');

      if (ifMatch || ifNoneMatch) {
        if (!PersistenceManager.isOnline()) {
          const etag = response.headers.get('ETag');

          if (ifMatch && etag.indexOf(ifMatch) < 0) {
            // If we are offline then we MUST return 412 if no match as per spec
            return PersistenceUtils.responseToJSON(response).then((responseData) => {
              // eslint-disable-next-line no-param-reassign
              responseData.status = 412;
              // eslint-disable-next-line no-param-reassign
              responseData.statusText = 'If-Match failed due to no matching ETag while offline';
              logger.info('Returning Response status 412 based on ETag and HTTP If-Match header');
              return PersistenceUtils.responseFromJSON(responseData);
            });
          }
          if (ifNoneMatch && etag.indexOf(ifNoneMatch) >= 0) {
            // If we are offline then we MUST return 412 if match as per spec
            return PersistenceUtils.responseToJSON(response).then((responseData) => {
              // eslint-disable-next-line no-param-reassign
              responseData.status = 412;
              // eslint-disable-next-line no-param-reassign
              responseData.statusText = 'If-None-Match failed due to matching ETag while offline';
              logger.info('Returning Response status 412 based on ETag and HTTP If-None-Match header');
              return PersistenceUtils.responseFromJSON(responseData);
            });
          }
        } else {
          // If we are online then we have to revalidate
          return _handleRevalidate(request, response, false, PersistenceUtils, PersistenceManager);
        }
      }
      return response;
    });
  }

  function _handleMustRevalidate(request, response, PersistenceUtils, PersistenceManager) {
    return Promise.resolve().then(() => {
      // must-revalidate MUST revalidate stale info. If we're offline or
      // server cannot be reached then client MUST return a 504 error:
      // https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html
      const mustRevalidate = _getCacheControlDirective(response.headers, 'must-revalidate');
      if (mustRevalidate) {
        const cacheExpirationDate = response.headers.get('x-oracle-jscpt-cache-expiration-date');
        if (cacheExpirationDate) {
          const cacheExpirationTime = (new Date(cacheExpirationDate)).getTime();
          const currentTime = (new Date()).getTime();

          if (currentTime > cacheExpirationTime) {
            logger.info('Handling revalidation HTTP must-revalidate header');
            return _handleRevalidate(request, response, true, PersistenceUtils, PersistenceManager);
          }
        }
      }
      return response;
    });
  }

  function _cacheResponse(request, response, PersistenceUtils, PersistenceManager) {
    return Promise.resolve().then(() => {
      // persist the Request/Response in our cache
      if (response != null
        && !PersistenceUtils.isCachedResponse(response)
        && (request.method === 'GET' || request.method === 'HEAD')) {
        const responseClone = response.clone();
        return PersistenceManager.getCache().put(request, response).then(() => {
          logger.info('Cached Request/Response');
          return responseClone;
        });
      }
      return response;
    });
  }

  /**
   * Returns the HTTP Cache Header strategy.  The cache strategy is applied to GET/HEAD requests by the
   * defaultResponseProxy right after the fetch strategy is applied and the response is obtained. The cache
   * strategy should be a function which takes the request and response as parameter and returns a Promise
   * which resolves to the response. In the case the fetch strategy returns a server response.  The cache
   * strategy should determine whether the request/response should be cached and if so, persist the
   * request/response by calling persistenceManager.getCache().put(). The cache strategy should also handle
   * cached responses returned by the fetch strategy.
   * @method
   * @name getHttpCacheHeaderStrategy
   * @memberof cacheStrategies
   * @static
   * @return {Function} Returns the HTTP Cache Header strategy, which conforms to the Cache Strategy API.
   */
  function getHttpCacheHeaderStrategy() {
    return (request, response) => Utils.getResources(['persist/persistenceManager', 'persist/persistenceUtils'])
      .then((modules) => {
        const [PersistenceManager, PersistenceUtils] = modules;
        // process the headers in order. Order matters, you want to
        // do things like re-validation before you bother persist to
        // the cache. Also, max-age takes precedence over Expires.
        return _handleExpires(request, response, PersistenceUtils)
          .then((r) => _handleMaxAge(request, r, PersistenceUtils))
          .then((r) => _handleIfCondMatch(request, r, PersistenceUtils, PersistenceManager))
          .then((r) => _handleMustRevalidate(request, r, PersistenceUtils, PersistenceManager))
          .then((r) => _cacheResponse(request, r, PersistenceUtils, PersistenceManager));
      });
  }

  return { getHttpCacheHeaderStrategy };
});



define('vbsw/private/optCacheStrategiesFactory',[
  'vbc/private/utils',
  'vbsw/private/optCacheStrategies',
], (Utils, OptCacheStrategies) => {
  /**
   * A factory to retrieve which http cache header strategy to use.
   */
  class OptCacheStrategiesFactory {
    /**
     *
     * @param {*} config fetchHandler configuration
     * @param {*} request the original request object
     * @returns cache strategy instance
     */
    static getCacheStrategy(config, request) {
      if (Utils.isMobile()
        || (config.isWebPwa && config.registryUrl && request.url.startsWith(config.registryUrl))) {
        // special case for handling the caching of user information for native mobile and extension registry url for
        // web PWA's
        return { cacheStrategy: OptCacheStrategies.getHttpCacheHeaderStrategy() };
      }

      // for everything else return null to use the default cache header strategy provided by OPT
      return { cacheStrategy: null };
    }
  }

  return OptCacheStrategiesFactory;
});

/* eslint-disable max-classes-per-file */



define('vbsw/private/urlMapperClient',[
  'vbc/private/log',
  'vbsw/private/utils',
  'urijs/URI',
], (Log, Utils, URI) => {
  //
  const logger = Log.getLogger('/vbsw/private/plugins/utils/urlMapperClient');

  /**
   * this mapper sends messages to the application, to get potential URL mappings from the services layer.
   */
  class ServiceUrlMapperClient {
    /**
     * @param config the response from vbGetConfiguration 'urlMapping' message.
     * this is vbConfig.SERVICE_WORKER_CONFIG.urlMapping,
     * plus applicationUrl and baseUrl from Configuration.
     */
    constructor(config) {
      let prefixesToIgnore = [];

      // make a regex to skip application resource URLs
      if (config) {
        // if SERVICE_WORKER_CONFIG.urlMapping.includeDefaultPrefixes = false, skip these
        if (config.includeDefaultPrefixes !== false) {
          if (config.applicationUrl) {
            // When using vanity URL, BASE_URL_TOKEN starts with '/'
            const isVanityUrl = config.baseUrlToken ? config.baseUrlToken[0] === '/' : false;

            // Skipping request prefixed by applicationUrl is not really necessary because
            // only the index.html request qualifies. All other requests for internal resources
            // should be fetched relative to the baseUrl. However, if applicationUrl is a vanityUrl
            // and only contains the host name, e.g., https://myCompany.com, then all requests
            // will get skipped. To fix this issue and to be safe, we will only add applicationUrl
            // to prefixesToIgnore if it's not a vanity url.
            if (!isVanityUrl) {
              // use a Request object to remove any default protocol
              prefixesToIgnore.push(new Request(config.applicationUrl).url);
            }
          }
          if (config.baseUrl && config.baseUrl !== config.applicationUrl) {
            prefixesToIgnore.push(new Request(config.baseUrl).url);
          }
          if (config.modulePath) {
            prefixesToIgnore.push(new Request(config.modulePath).url);
          }
          if (config.jetPath) {
            prefixesToIgnore.push(new Request(config.jetPath).url);
          }
          // skip token relay  & proxy requests (ex: ".*/services/auth/1.1/tokenrelay/")
          const tokenRelayFrag = Utils.getTokenRelayUrl('.*', '');
          // replace the trailing slash on tokenRelay, to match either slash or end-of-string
          prefixesToIgnore.push(tokenRelayFrag.replace(/\/$/, '(\\/|$)'));
          // returned as: ".*/services/auth/1.1/proxy/.*/uri/"
          const proxyFrag = Utils.getProxyUrl('.*', '.*');
          prefixesToIgnore.push(proxyFrag);

          // BUFP-36271
          const userInfoUrl = (config.userConfig && config.userConfig.configuration
            && config.userConfig.configuration.url);

          if (userInfoUrl) {
            // use the Request to get the port
            prefixesToIgnore.push(new Request(userInfoUrl).url);
            /**
             * also, for FA deployed app, they may manipulate the URL in the security provider, so match the suffix
             * in case the host attached by Request above is different.
             * for example, in "userConfig", "url" might be:
             *   /fscmRestApi/applcoreApi/v1/fndvbcsuishell/userinfo"
             *  and Request(url) turns it into:
             *   https://slc13qyo.us.oracle.com:8082/fscmRestApi/applcoreApi/v1/fndvbcsuishell/userinfo
             * but FA FndSecurityProvider might actually fetch
             *   https://fuscdrmsmc393-fa-ext.us.oracle.com:443/fscmRestApi/applcoreApi/v1/fndvbcsuishell/userinfo?s=crm
             *
             * do not expect, or rely on, the behavior described above; just workaround the possibility of it (19.4.3).
             * Skipping the userInfo should NOT be necessary post 19.4.3, when they update catalog.json syntax.
             */
            prefixesToIgnore.push(`.*${userInfoUrl}`);
          }
        }

        // SERVICE_WORKER_CONFIG.urlMapping.prefixesToIgnore
        if (config.prefixesToIgnore && Array.isArray(config.prefixesToIgnore)) {
          prefixesToIgnore = prefixesToIgnore.concat(config.prefixesToIgnore);
        }
      }

      if (prefixesToIgnore.length) {
        this.ignoreForMapping = new RegExp(`^(${prefixesToIgnore.join('|')})`, 'i'); // really use 'i'?
      } else {
        // this is 'just in case' we don't get config for some weird reason
        this.ignoreForMapping = (config && config.ignoreRegex)
          ? new RegExp(config.ignoreRegex) : /\/catalog.json$/g;
      }
    }

    /**
     * this is the public method for getting a possible mapping.
     * A mapping is what currently appears in the 'vb-info-extension' header for a 'normal' data fetch.
     *
     * when attempting to do reverse mapping initially, we may cause additional fetches that
     * we need to allow to pass through (instead of reverse-mapping).
     * @param request
     * @param client an abstraction from JET Offline Toolkit for Utils.postMessage
     * @returns {Promise<Object | null>}
     */
    getMapping(request, client) {
      return Promise.resolve()
        .then(() => {
          if (this.ignoreForMapping.test(request.url)) {
            return null;
          }

          logger.fine(`getMapping called with: ${request.url}`);

          let timeout;

          const timeoutPromise = new Promise((resolve, reject) => {
            timeout = setTimeout(() => {
              reject(new Error(`urlMapper postMessage timeout: ${request.url}`));
              // eslint-disable-next-line no-use-before-define
            }, UrlMapperClient.MAPPER_POSTMESSAGE_TIMEOUT);
          });

          const mappingPromise = this.requestMapping(request.url, client);
          // cancel the timer, otherwise debugger may stop on the reject call above
          mappingPromise.then(() => {
            if (timeout) {
              clearTimeout(timeout);
            }
          });

          return Promise.race([mappingPromise, timeoutPromise]);
        })
        .catch((err) => {
          logger.warn('UrlMapperClient is unable to request mapping, continuing', request.url, err);
          return null;
        });
    }


    /**
     * send a message to get the mapping, apply it, and add to our local cache
     * @param url
     * @param client
     * @returns {Object}
     * @private
     */
    requestMapping(url, client) {
      return Promise.resolve()
        .then(() => {
          if (this.disabled) {
            return null;
          }

          // normalize the url - this will remove default ports, possibly
          const uri = URI.parse(url);
          // and also remove query parameters
          uri.query = null;
          const urlWithoutQuery = URI.build(uri).toString();

          const message = {
            method: 'vbGetUrlMapping',
            args: [urlWithoutQuery],
          };

          return Utils.postMessage(client, message);
        });
    }
  }

  /**
   * a mapper that always returns null
   */
  class StubMapperClient {
    constructor() {
      logger.warn('URL Mapping is disabled by configuration'); // @todo: info?
    }

    // eslint-disable-next-line class-methods-use-this
    getMapping() {
      return Promise.resolve(null);
    }
  }


  /**
   * this is the 'client' used by the fetch handler plugins, for requesting a potential mapping
   * for a given URL form the UrlMapper.
   *
   * depending on whether mapping is enabled, it will create one of the classes above, to do the actual getMapping.
   *
   * note: active() must be called after construction, for this client to process requests.
   */
  class UrlMapperClient {
    constructor(config) {
      // the fetchHandler.config.urlMapping, or window.vbInitConfig.SERVICE_WORKER_CONFIG.urlMapping.
      // includes the applicationUrl and baseUrl from the vbInitConfig.SERVICE_WORKER_CONFIG.
      this.config = config ? Object.assign({}, config.urlMapping || {}, {
        applicationUrl: config.applicationUrl,
        baseUrl: config.baseUrl,
        baseUrlToken: config.baseUrlToken,
        modulePath: config.modulePath,
        jetPath: config.jetPath,
        userConfig: config.userConfig,
      }) : {};

      // do not process requests until activated
      this.activated = false;
    }

    /**
     * create the proper implementation; 'real' or 'stubbed'
     * @returns {Promise}
     * @private
     */
    init() {
      if (!this.initPromise) {
        this.initPromise = Promise.resolve()
          .then(() => {
            if (this.config.disabled) {
              this.delegate = new StubMapperClient();
            } else {
              this.delegate = new ServiceUrlMapperClient(this.config);
            }
          })
          .catch((e) => {
            logger.warn('error initializing URL Mapping, disabled');
            logger.error(e);
            this.delegate = new StubMapperClient();
          });
      }
      return this.initPromise;
    }

    /**
     * if activated, delegates to the real implementation. otherwise, returns null
     *
     * @param request
     * @param client
     * @returns {Promise<Object|null>}
     */
    getMapping(request, client) {
      return this.activated ? this.init()
        .then(() => this.delegate.getMapping(request, client))
        : Promise.resolve(null);
    }

    /**
     * wait for VB to be ready to process mapping requests; skip requests until then
     * @returns {boolean}
     */
    activate() {
      logger.info('URL Mapping is activated');
      this.activated = true;
      return this.activated;
    }
  }

  // UrmMapperClient postMessage timeout, in case something goes really wrong
  // picked 1 second arbitrarily; if it times out, we just skip waiting for a mapping, and request completes.
  UrlMapperClient.MAPPER_POSTMESSAGE_TIMEOUT = 1000;


  return UrlMapperClient;
});


// @ts-check
/* eslint-disable prefer-destructuring, no-underscore-dangle */



define('vbsw/private/fetchHandler',[
  'vbsw/private/utils',
  'vbsw/private/stateCache',
  'vbsw/private/cacheStrategy',
  'vbsw/private/cacheStrategyFactory',
  'vbsw/api/fetchHandlerPlugin',
  'vbsw/private/pwa/applicationCache',
  'vbsw/private/optCacheStrategiesFactory',
  'vbsw/private/constants',
  'vbc/private/log',
  'vbc/private/performance/performance',
  'vbc/private/trace/tracer',
  'vbsw/private/urlMapperClient',
  'jsondiff',
], (Utils, StateCache, CacheStrategy, CacheStrategyFactory, FetchHandlerPlugin, ApplicationCache,
  OptCacheStrategiesFactory, Constants, Log, Performance, Tracer, UrlMapperClient, JsonDiff) => {
  const MAX_RETRIES = 2;
  const SERVICE_WORKER_CONFIG = 'vbServiceWorkerConfig';
  const SERVICE_WORKER_PLUGIN_INFOS = 'vbServiceWorkerPluginInfos';
  const FORCE_OFFLINE_FLAG = 'vbForceOfflineFlag';
  let logger;

  // used by installPlugins to determine if a plugin has changed
  const jsonDiff = JsonDiff.create({
    arrays: {
      detectMove: false,
    },
    cloneDiffValues: false,
  });

  /**
   * This class is used by the service worker to handle all the fetch requests. In the case where the service
   * worker is not supported by the browser, the PersistenceManager from the offline toolkit can be used to
   * emulate the service worker and this class can also be used to handle fetch requests.
   */
  class FetchHandler {
    /**
     * Create an instance of FetchHandler.
     *
     * @param scope the scope of the service worker
     * @param config configuration object for the service worker
     * @param persistenceManager the PersistenceManager used to emulate the service worker functionality
     */
    constructor(scope, config, persistenceManager) {
      // set up log configuration for Service Worker thread loggers
      if (config) {
        if (config.logConfig && config.logConfig.level) {
          Log.setMinimumLevel(config.logConfig.level);
        }
        Log.setConfig(config.log);
      }
      logger = Log.getLogger('/vbsw/private/fetchHandler');
      logger.info('FetchHandler scope:', scope, 'config:', config);
      this.scope = scope;
      this.config = config;
      this.persistenceManager = persistenceManager;

      // set up browser fetch
      this.setupBrowserFetch(persistenceManager);

      this.plugins = [];

      // for emulation mode and unit tests, we need to make sure the stateCache and cacheStrategy are
      // created since restore won't be called
      this.stateCache = new StateCache();
      this.cacheStrategy = CacheStrategyFactory.createCacheStrategy(this);

      // mapping between a request and its associated originating client
      this.requestClientMap = {};

      // set up vb.perf object to access performance data for SW
      if (Utils.isWorkerThread()) {
        // eslint-disable-next-line no-restricted-globals
        Performance.init(self.vb, config && config.performanceConfig);
      }

      // used to reverse-map URLs to 'vb-init-extension' information
      this.urlMapperClient = new UrlMapperClient(this.config);
    }

    /**
     * Set up browserFetch to either point to browserFetch from the persistence manager or the actual browser fetch.
     *
     * @param persistenceManager the persistence manager
     */
    setupBrowserFetch(persistenceManager) {
      const pm = persistenceManager;

      if (pm) {
        this.browserFetch = pm.browserFetch.bind(pm);

        // override the pm browserFetch to call handleRequest on the fetch handler
        pm.browserFetch = (request) => {
          // look up the associated client for the request
          const client = this.getRequestClient(request);
          return this.handleRequest(request, client, true);
        };
      } else {
        // service worker won't let you directly point to fetch so use a wrapper function instead
        this.browserFetch = (request) => fetch(request);
      }
    }

    /**
     * Called during the service worker installation phase to set up the caches and import additional script
     * such as loading the offline handler.
     *
     * @returns {Promise<T>}
     */
    install() {
      const installMark = ['fetchHandler.install'];
      return Promise.resolve()
        .then(() => Performance.markStart(installMark))
        .then(() => this.deleteStaleCaches())
        // need to call restore to preload any external scripts since we can't load any more scripts after installation
        .then(() => this.restore(true))
        .then(() => this.initApplicationCache())
        .then(() => Performance.markEnd(installMark));
    }

    /**
     * @returns {Promise<void>} a Promise to open state cache
     */
    openStateCache() {
      const cacheName = this.getStateCacheName();
      logger.info('Opening state cache:', cacheName);
      return caches.open(cacheName)
        .then((cache) => {
          this.stateCache = new StateCache(cache);
          return this.stateCache;
        });
    }

    /**
     * @returns {Promise<void>} a Promise to open Service Worker caches required by the application.
     */
    openCaches(isOnInstall) {
      return this.openStateCache()
        .then((stateCache) => {
          // cache the config object on install
          if (isOnInstall) {
            return stateCache.put(SERVICE_WORKER_CONFIG, this.config);
          }
          // otherwise, restore the config object from cache
          return stateCache.get(SERVICE_WORKER_CONFIG).then((cachedConfig) => {
            if (!cachedConfig) {
              logger.info('Service Worker: Failed to load cached configuration');
              this.config = {};
            } else {
              this.config = cachedConfig || {};
              logger.info('Service Worker Cached Configuration:', this.config);
            }
          });
        })
        .then(() => {
          if (this.config.isPwa) {
            return this.getApplicationCache()
              .then((cache) => {
                if (!cache) {
                  throw new Error('PWA: missing application cache.');
                }
                this.setApplicationCache(cache);
              })
              .catch((err) => {
                // Don't log anything unless this is PWA error
                if (err && err.message && err.message.startsWith('PWA')) {
                  logger.error('PWA: Failed to initApplicationCache:', err);
                }
              });
          }
          return undefined;
        });
    }

    initTracer() {
      if (Utils.isWorkerThread()) {
        return Tracer.init(this.config.traceOptions);
      }
      return Promise.resolve();
    }

    /**
     * Restore state from the cache. This is called during the oninstall event (isOnInstall is true) to preload
     * all scripts. This is also called when a service worker is activated to restore the state of the fetch handler.
     *
     * @param isOnInstall true, if restore is called during oninstall
     * @param skipInstallingPlugins if true, plugins won't be reinstalled
     * @returns {Promise}
     */
    restore(isOnInstall, skipInstallingPlugins = false) {
      return this.initTracer()
        .then(() => this.openCaches(isOnInstall))
        .then(() => {
          // create the cacheStrategy based on the restored config
          this.cacheStrategy = CacheStrategyFactory.createCacheStrategy(this);

          // set up any require config before loading the offline handler and plugins
          this.setRequireConfig();

          const promises = [];

          // install the plugins, if isOnInstall is true, pre install any external plugins since we can't
          // load any more scripts after the installation phase
          if (!skipInstallingPlugins) {
            promises.push(this.installPlugins(isOnInstall ? this.config.plugins : undefined));
          }
          // install the offline handler
          promises.push(this.installOfflineHandler(this.config));

          return Promise.all(promises);
        });
    }

    /**
     * The name of the versioned application cache in the form: scope-VERSION-application.
     * @returns {string} the name of the application cache
     */
    getApplicationCacheName() {
      return this.getCacheName('application');
    }

    /**
     * The name of the versioned state cache in the form: scope-VERSION-state
     * @returns {string} the name of the state cache
     */
    getStateCacheName() {
      return this.getCacheName('state');
    }

    /**
     * Constructs cache name in the form: scope-VERSION-type
     * @param type cache type, for example: 'state' or 'application'
     * @returns {string} the name of the cache
     */
    getCacheName(type) {
      let cacheName = '';
      if (this.scope) {
        cacheName += `${this.scope}-`;
      }
      if (this.config.version) {
        cacheName += `${this.config.version}-`;
      }
      cacheName += type;
      return cacheName;
    }

    /**
     * @returns {Promise<void>} a promise to an application cache for PWA, or a Promise to an undefined.
     */
    getApplicationCache() {
      if (this.config.isPwa) {
        const appCacheName = this.getApplicationCacheName();
        logger.info('PWA: opening application cache:', appCacheName);

        return caches.open(appCacheName)
          .catch((err) => {
            // log and ignore the error
            logger.error('PWA: Failed to getApplicationCache:', err);
          });
      }
      return Promise.resolve();
    }

    /**
     * Delete out-of-date caches during service worker install.
     *
     * @returns {Promise<void>} a promise to delete all stale caches. State cache and application cache is considered
     * stale on every install, since install is triggered by one of:
     * - modulePath change, for example, when custom RT version is used, such as:
     * https://xyz.com/ic/builder/rt/xyz/1.0/mobileApps/abc/version_4473741334620356740/resources/package/
     * - jetPath change, when JET version changes
     * - baseUrlToken or nonce change, when a new version of an application is staged/published
     * - debug flag change
     */
    deleteStaleCaches() {
      // TODO: deleting caches should be happening during activate, not install
      logger.info('Attempting to delete stale caches for version:', this.config.version, 'scope:',
        this.scope);
      return caches.keys().then((cacheNames) => Promise.all(cacheNames.map((cacheName) => {
        logger.info('Checking cache:', cacheName);
        if (this.isStaleStateCache(cacheName) || this.isStaleApplicationCache(cacheName)) {
          logger.info('Deleting cache:', cacheName);
          return caches.delete(cacheName);
        }
        return Promise.resolve();
      })));
    }

    /**
     * For a given application, state cache is considered stale on every install, since install is triggered
     * on every RT version change.
     *
     * scope-VERSION-state
     *
     * @param cacheName cache name to check
     * @returns {Boolean} true, if cacheName corresponds to a stale state cache
     */
    isStaleStateCache(cacheName) {
      return cacheName.startsWith(this.scope) && cacheName.endsWith('state');
    }

    /**
     * Application cache stores versioned application assets. It is considered stale every time Service Worker
     * is installed (when baseUrlToken changes) to guarantee that the cache contains the latest application assets.
     * So application cache for a given application is considered stale on every install.
     *
     * scope-VERSION-application
     *
     * @param cacheName cache name to check
     * @returns {Boolean} true, if cacheName corresponds to a stale application cache
     */
    isStaleApplicationCache(cacheName) {
      return cacheName.startsWith(this.scope) && cacheName.endsWith('application');
    }

    /**
     * @returns {Promise<void>} a promise to cache application assets or undefined, if this is not a PWA
     */
    initApplicationCache() {
      return Promise.resolve()
        .then(() => {
          if (this.config.isPwa) {
            return this.cacheOnInstall();
          }
          return undefined;
        })
        .catch((err) => {
          // Don't log anything unless this is PWA
          if (err && err.message && err.message.startsWith('PWA')) {
            logger.error('PWA: Failed to initApplicationCache:', err);
          }
        });
    }

    /**
     * Sets a cache to use for application static assets,
     * @param serviceWorkerCache the ServiceWorker cache created for application assets
     */
    setApplicationCache(serviceWorkerCache) {
      if (serviceWorkerCache) {
        logger.info('PWA: setApplicationCache()');
        this.appCache = new ApplicationCache(serviceWorkerCache);
      }
    }

    /**
     * Return the configuration object for the service worker.
     *
     * @returns {*|{}}
     */
    getConfig() {
      return this.config;
    }

    /**
     * Set up any externally provided require config.
     */
    setRequireConfig() {
      if (this.config.requireConfig) {
        require.config(this.config.requireConfig);
      }
    }

    /**
     * Retrieve the cached plugin urls.
     *
     * @returns {Promise}
     */
    getCachedPluginInfos() {
      return this.stateCache.get(SERVICE_WORKER_PLUGIN_INFOS);
    }

    /**
     * Cache the array of plugin urls so it can be retrieved the next time the service worker starts.
     *
     * @param pluginInfos an array of plugin infos to cache
     * @returns {Promise.<T>|Promise<R>|Promise<void>}
     */
    cachePluginInfos(pluginInfos) {
      return this.stateCache.put(SERVICE_WORKER_PLUGIN_INFOS, pluginInfos);
    }

    /**
     * Load and install the plugin at the given index.
     *s
     * @param pluginInfo the info of the plugin to install
     * @param index the index where the plugin should be installed
     * @param initCache if initCache is true, call initCache() on the newly created plugin to initialize the cache
     * @returns {Promise}
     */
    installPlugin(pluginInfo, index, initCache) {
      let pluginUrl;
      let params;

      if (typeof pluginInfo === 'object') {
        pluginUrl = pluginInfo.url;
        params = pluginInfo.params;
      } else {
        pluginUrl = pluginInfo;
      }

      return Utils.getResource(pluginUrl).then((PluginClass) => {
        logger.info('Plugin loaded from', pluginUrl);

        // create a context object containing this fetchHandler and a namespaced stateCache
        const context = {
          fetchHandler: this,
          stateCache: this.stateCache.createNamespacedCache(pluginUrl),
        };

        const plugin = new PluginClass(context, params);
        this.plugins[index] = plugin;

        // if initCache is true, call initCache() on the newly created plugin to initialize the cache
        return initCache ? plugin.initCache() : undefined;
      }).catch((err) => {
        logger.error('Failed to load plugin from', pluginUrl, err);
      });
    }

    /**
     * Load and install plugins specified in pluginInfos. A plugin info can be either an url string or
     * and object containing url and params properties. The params property will be passed to the
     * constructor of the plugin. For example:
     *
     * [
     *   'vbsw/plugin1',
     *   {
     *     url: 'vbsw/plugin2',
     *     params:  {
     *       foo: 'bar'
     *     }
     *   }
     * ]
     *
     * Note that this method will replace all the existing installed plugins.
     *
     * @param pluginInfos an array of plugin info.
     * @param reload if true, force reload all the plugins, otherwise, only reload plugins whose metadata has changed
     * @returns {Promise}
     */
    installPlugins(pluginInfos, reload = false) {
      return this.getCachedPluginInfos().then((cachedPluginInfos) => {
        const oldPluginInfos = cachedPluginInfos || pluginInfos;
        const newPluginInfos = pluginInfos || oldPluginInfos || [];
        const oldPlugins = this.plugins;
        const promises = [];
        this.plugins = new Array(newPluginInfos.length);

        for (let i = 0; i < newPluginInfos.length; i += 1) {
          const info = newPluginInfos[i];

          // look up the existing plugin whose info hasn't changed
          const index = oldPluginInfos.findIndex((oldInfo) => !jsonDiff.diff(oldInfo, info));

          // don't reuse the plugin if reload is true
          if (!reload && index !== -1) {
            this.plugins[i] = oldPlugins[index];
          }

          if (!this.plugins[i]) {
            promises.push(this.installPlugin(info, i, reload));
          }
        }

        return Promise.all(promises).then(() => this.cachePluginInfos(newPluginInfos));
      });
    }

    /**
     * Uninstall currently installed plugins. This is used for testing purpose.
     *
     * @returns {Promise}
     */
    uninstallPlugins() {
      this.plugins = [];
      return Promise.resolve();
    }

    /**
     * enable URL Mapping.
     *
     * called either directly by EmulatedServiceWorkerWrapper, or indirectly via postMessage from
     * BrowserServiceWorkerWrapper (see self.addEventListener('message'..) in vbServiceWorker.
     *
     * @returns {*}
     */
    activateUrlMapping() {
      return this.urlMapperClient.activate();
    }

    /**
     * Load and install the offline handler using information in the handlerInfo.
     *
     * @param handlerInfo and object containing information for the offline handler
     * @returns {Promise}
     */
    installOfflineHandler(handlerInfo) {
      return Promise.resolve().then(() => {
        if (!this.offlineHandler) {
          const handlerUrl = handlerInfo.offlineHandler;

          if (handlerUrl) {
            // set up the requirejs config for offline toolkit so the handler can be loaded if we are not running in
            // emulation mode
            if (!this.persistenceManager) {
              requirejs.config({
                map: {
                  '*': {
                    opt: 'persist', // for backwards compatibility with opt prefix
                  },
                },
              });
            }

            return Utils.getResource(handlerUrl).then((Module) => {
              let module;
              if (Module) {
                // Module can be either a constructor or a singleton
                module = typeof Module === 'function' ? new Module() : Module;
              } else {
                module = {};
              }

              if (typeof module.createOfflineHandler === 'function') {
                // make sure we initialize the PersistenceManager first
                return this.initializePersistenceManagerWithStore(module)
                  .then(() => module.createOfflineHandler()
                    .then((handler) => {
                      this.offlineHandler = handler;
                    }));
              }

              return undefined;
            }).catch((err) => {
              logger.info(`Failed to load offline handler from ${handlerUrl}: ${err}`);
              this.offlineHandler = null;
            }).finally(() => {
              // if no offline handler is registered but useCacheResponseWhenOfflineHeaderEnabled
              // config option is set to true, make sure we initialize the persistence manager so
              // we can use it to cache responses with the special header
              if (!this.offlineHandler && this.useCacheResponseWhenOfflineHeaderEnabled) {
                return this.initializePersistenceManagerWithStore();
              }

              return undefined;
            });
          }
        }

        return undefined;
      });
    }

    /**
     * Uninstall the offline handler.
     *
     * @return {Promise}
     */
    uninstallOfflineHandler() {
      this.offlineHandler = null;
      return Promise.resolve();
    }

    /**
     * Return a promise that resolves to true if the PersistenceManager is online and false otherwise.
     *
     * @returns {Promise}
     */
    isOnline() {
      return this.initializePersistenceManager().then((pm) => pm.isOnline());
    }

    /**
     * Get the cached force offline flag.
     *
     * @returns {Promise}
     */
    getCachedForceOfflineFlag() {
      return this.stateCache.get(FORCE_OFFLINE_FLAG);
    }

    /**
     * Cache the force offline flag.
     *
     * @param flag force offline flag
     * @returns {Promise.<Boolean>}
     */
    cacheForceOfflineFlag(flag) {
      return this.stateCache.put(FORCE_OFFLINE_FLAG, flag);
    }

    /**
     * If the flag is true, force the PersistenceManager offline and vice versa.
     *
     * @param flag if true, force the PersistenceManager offline and vice versa.
     * @returns {Promise}
     */
    forceOffline(flag) {
      return this.initializePersistenceManager().then((pm) => pm.forceOffline(flag))
        .then(() => this.cacheForceOfflineFlag(flag));
    }

    /**
     * Dynamically load the PersistenceSyncManager.
     *
     * @returns {*}
     */
    getPersistenceSyncManager() {
      if (!this.persistSyncMgrPromise) {
        this.persistSyncMgrPromise = Utils.getResource('persist/impl/PersistenceSyncManager')
          .then((PersistenceSyncManager) => new PersistenceSyncManager());
      }
      return this.persistSyncMgrPromise;
    }

    /**
     * Dynamically load the PersistenceUtils.
     *
     * @returns {*}
     */
    getPersistenceUtils() {
      if (!this.persistUtilsPromise) {
        this.persistUtilsPromise = Utils.getResource('persist/persistenceUtils');
      }
      return this.persistUtilsPromise;
    }

    /**
     * Deserialize the given request JSON object into a Request instance.
     *
     * @param requestJson request json to deserialize
     * @returns {Promise<Request>}
     */
    deserializeRequest(requestJson) {
      return Promise.resolve().then(() => {
        if (Utils.isWorkerThread()) {
          return this.getPersistenceUtils()
            .then((PersistenceUtils) => PersistenceUtils.requestFromJSON(requestJson));
        }

        return requestJson;
      });
    }

    /**
     * If running on the service worker thread, serialize the given result from a sync manager operation by
     * serializing any Request or Response instance into a JSON object so it can be returned to the main thread
     * via postMessage.
     *
     * @param result
     * @returns {Promise<T>}
     */
    serializeSyncOperationResult(result) {
      return Promise.resolve().then(() => {
        if (result && Utils.isWorkerThread()) {
          return this.getPersistenceUtils().then((PersistenceUtils) => {
            if (Array.isArray(result)) {
              const serializedResult = [];
              const promises = result.map((entry) => this.serializeSyncOperationResult(entry)
                .then((serializedEntry) => {
                  serializedResult.push(serializedEntry);
                }));
              return Promise.all(promises).then(() => serializedResult);
            }

            if (result instanceof Request) {
              return PersistenceUtils.requestToJSON(result);
            }

            if (result instanceof Response) {
              return PersistenceUtils.responseToJSON(result);
            }

            if (Utils.isObject(result)) {
              const serializedResult = {};
              const promises = Object.keys(result)
                .map((key) => this.serializeSyncOperationResult(result[key])
                  .then((serializedProp) => {
                    serializedResult[key] = serializedProp;
                  }));

              return Promise.all(promises).then(() => serializedResult);
            }

            if (typeof result === 'function') {
              return null;
            }

            return result;
          });
        }

        return result;
      });
    }

    /**
     * Invoke PersistenceSyncManager.sync.
     *
     * Note: The client argument is passed in by Utils.invokeMethod.
     *
     * @param options any options to be passed to the persistence sync manager
     * @param client the originating client of this sync call
     */
    syncOfflineData(options, client) {
      if (this.persistenceManagerPromise) {
        return this.persistenceManagerPromise.then((pm) => Utils.getResource('persist/impl/PersistenceSyncManager')
          .then((PersistenceSyncManager) => {
            // create a PersistenceSyncManager that use our FetchHandler to perform browser fetch
            const syncMgr = new PersistenceSyncManager(
              pm.isOnline.bind(pm),
              // call back into our handleRequest and don't skip the offline handler so the request
              // can be handled by the response proxy
              (request) => this.handleRequest(request, client, false),
              pm.getCache.bind(pm),
            );

            if (this.offlineHandler) {
              if (typeof this.offlineHandler.beforeSyncRequestListener === 'function') {
                syncMgr.addEventListener('beforeSyncRequest',
                  this.offlineHandler.beforeSyncRequestListener.bind(this.offlineHandler));
              }

              if (typeof this.offlineHandler.afterSyncRequestListener === 'function') {
                syncMgr.addEventListener('syncRequest',
                  this.offlineHandler.afterSyncRequestListener.bind(this.offlineHandler));
              }
            }

            return syncMgr.sync(options)
              .catch((err) => this.serializeSyncOperationResult(err)
                .then((serializedErr) => {
                  throw serializedErr;
                }));
          }));
      }

      return Promise.reject(new Error('Cannot invoke sync before the PersistenceManager is initialized.'));
    }

    /**
     * Invoke PersistenceSyncManager.getSyncLog.
     *
     * @returns {*}
     */
    getOfflineSyncLog() {
      return this.getPersistenceSyncManager()
        .then((syncMgr) => syncMgr.getSyncLog())
        .then((syncLog) => this.serializeSyncOperationResult(syncLog));
    }

    /**
     * Invoke PersistenceSyncManager.insertRequest.
     *
     * @param requestData
     * @param options
     * @returns {*}
     */
    insertOfflineSyncRequest(requestData, options) {
      return this.deserializeRequest(requestData)
        .then((request) => this.getPersistenceSyncManager()
          .then((syncMgr) => syncMgr.insertRequest(request, options))
          .then((result) => this.serializeSyncOperationResult(result)));
    }

    /**
     * Invoke PersistenceSyncManager.removeRequest.
     *
     * @param requestId
     * @returns {*}
     */
    removeOfflineSyncRequest(requestId) {
      return this.getPersistenceSyncManager()
        .then((syncMgr) => syncMgr.removeRequest(requestId))
        .then((result) => this.serializeSyncOperationResult(result));
    }

    /**
     * Invoke PersistenceSyncManager.updateRequest.
     *
     * @param requestId
     * @param requestData
     * @returns {*}
     */
    updateOfflineSyncRequest(requestId, requestData) {
      return this.deserializeRequest(requestData)
        .then((request) => this.getPersistenceSyncManager()
          .then((syncMgr) => syncMgr.updateRequest(requestId, request))
          .then((result) => this.serializeSyncOperationResult(result)));
    }

    /**
     * Set options on the offline handler.
     *
     * @param options options to be set on the offline handler
     * @returns {Promise}
     */
    setOfflineHandlerOptions(options) {
      return Promise.resolve().then(() => {
        if (this.offlineHandler && typeof this.offlineHandler.setOptions === 'function') {
          return this.offlineHandler.setOptions(options);
        }

        return undefined;
      });
    }

    /**
     * Initialize the PersistenceManager and register a default persistence store.
     *
     * @param offlineModule module containing offline related code
     * @returns {Promise<any>}
     */
    initializePersistenceManagerWithStore(offlineModule) {
      return this.initializePersistenceManager()
        .then((pm) => FetchHandler.registerDefaultPersistenceStoreFactory(offlineModule)
          .then(() => pm));
    }

    /**
     * Initialize the PersistenceManager without registering a default persistence store.
     *
     * @returns {Promise}
     */
    initializePersistenceManager() {
      if (!this.persistenceManagerPromise) {
        if (this.persistenceManager) {
          // don't initialize the PersistenceManager again if we are running in emulation mode
          this.persistenceManagerPromise = Promise.resolve(this.persistenceManager);
        } else {
          this.persistenceManagerPromise = Utils.getResources(['persist/persistenceManager',
            'persist/impl/PersistenceSyncManager', 'persist/defaultResponseProxy',
          ])
            .then((modules) => {
              const [PersistenceManager,
                // PersistenceSyncManager must be loaded during ServiceWorker's install event
                PersistenceSyncManager] = modules; // eslint-disable-line no-unused-vars
              // set up browserFetch since persistence manager overrides it
              this.setupBrowserFetch(PersistenceManager);

              return PersistenceManager.init().then(() => this.getCachedForceOfflineFlag().then((flag) => {
                // if there's a cached force offline flag, apply it here
                if (flag !== undefined) {
                  PersistenceManager.forceOffline(flag);
                }
              })).then(() => PersistenceManager);
            });
        }
      }

      return this.persistenceManagerPromise;
    }

    /**
     * Register the default persistence store factory. This method will first call getDefaultPersistenceFactory method
     * on the module for the offline handler if it exists. Otherwise, it defaults to registering
     * 'persist/pouchDBPersistenceStoreFactory'.
     *
     * @param offlineModule module containing offline related code
     * @returns {*}
     */
    static registerDefaultPersistenceStoreFactory(offlineModule) {
      return Promise.resolve()
        .then(() => {
          if (offlineModule && typeof offlineModule.getDefaultPersistenceStoreFactory === 'function') {
            return offlineModule.getDefaultPersistenceStoreFactory();
          }
          return null;
        })
        .catch((err) => {
          // log the error
          logger.error(err);
          return null;
        })
        .then((storeFactoryOverride) => storeFactoryOverride
          || Utils.getResource('persist/pouchDBPersistenceStoreFactory'))
        .then((storeFactory) => Utils.getResource('persist/persistenceStoreManager')
          .then((PersistenceStoreManager) => {
            PersistenceStoreManager.registerDefaultStoreFactory(storeFactory);
          }));
    }

    /**
     * Retrieves requested URL and adds it to service worker's state cache.
     * @param url
     * @returns {Promise} a promise to cache a file
     */
    cacheFile(url) {
      if (url) {
        return this.stateCache.add(url);
      }
      return Promise.resolve();
    }

    /**
     * Creates a cloned request as a workaround for the whatwg-fetch polyfill issue,
     * where the polyfill can't clone request with FormData.  This workaround can be
     * removed, once the original polyfill issue is addressed.
     * @param url
     * @param config
     * @returns {Request} cloned request
     */
    // eslint-disable-next-line class-methods-use-this
    createRequest(url, config) {
      const clonedRequest = new Request(url, config);
      if (config.bodyFormData) {
        clonedRequest._bodyFormData = config.bodyFormData;
        clonedRequest._bodyInit = config.bodyInit;
      }

      // attach body to the request if attachOriginalBody is true
      if (config.attachOrignalBody) {
        clonedRequest.originalBody = config.body;
      }

      return clonedRequest;
    }

    /**
     * Clone the given request.
     *
     * @param request the request to be cloned
     * @return {Promise}
     */
    cloneRequest(request) {
      return FetchHandlerPlugin.getRequestConfig(request, this)
        .then((config) => this.createRequest(config.url, config))
        .catch((err) => {
          logger.error(err);

          // simply return null if the request cannot be cloned
          return null;
        });
    }

    /**
     * Determines whether the fetch polyfill is being used.
     * @returns {Boolean} true if the fetch polyfill is defined, false otherwise
     */
    isFetchPolyfill() {
      return this.persistenceManager
        && this.persistenceManager._browserFetchFunc
        && this.persistenceManager._browserFetchFunc.polyfill;
    }

    /**
     * Perform the actual fetch.
     *
     * @param request the fetch request
     * @returns {Promise}
     */
    fetch(request) {
      // work around an issue in chrome where the dev tool makes a request with cache set to only-if-cached
      // and the mode not set to same-origin which will always fail
      if (request.cache === 'only-if-cached' && request.mode !== 'same-origin') {
        logger.info('Skip request url:', request.url, 'cache:', request.cache, 'mode:', request.mode);
        return Promise.resolve(new Response(null, { status: 200, statusText: 'OK' }));
      }

      // PWA: dynamically cache CDN files - this needs to happen before custom offline handlers are called
      return Promise.resolve()
        .then(() => this.fetchAndCache(request))
        .then((response) => {
          if (response) {
            return response;
          }

          // else call browser fetch
          return this.browserFetch(request);
        });
    }

    /**
     * Invoke handleRequestHook on all the installed plugins.
     *
     * @param request the request to be handled by the plugins, maybe replaced by some plugins
     * @param client the client for the originator of the request
     * @returns {Promise.<Request>}
     */
    handleRequestHook(request, client) {
      // execute the plugins in order by chaining the promises
      return this.plugins.reduce((promise, plugin) => promise
        .then((r) => (!plugin ? r : plugin.handleRequestHook(r, client)
          .then((r2) => r2 || r)
          .catch((err) => {
            // log the error and prevent the bad plugin from breaking everyone
            logger.error(err);
            return r;
          }))), Promise.resolve(request));
    }

    /**
     * Invoke handleResponseHook on all the installed plugins. This method will return true if any of
     * the plugins returns true which means the request should be retried.
     *
     * @param response the response to be handled by the plugins
     * @param origRequest the original request
     * @param request the modified request
     * @param client the client for the originator of the request
     * @returns {Promise.<Boolean>}
     */
    handleResponseHook(response, origRequest, request, client) {
      // execute the plugins in order by chaining the promises
      return this.plugins.reduce((promise, plugin) => promise
        .then((retry) => (!plugin ? retry : plugin.handleResponseHook(response, origRequest, request, client)
          .catch((err) => {
            // log the error and prevent the bad plugin from breaking everyone
            logger.error(err);
            return false;
          })
          .then((localRetry) => localRetry || retry))), Promise.resolve(false));
    }

    /**
     * Invoke handleErrorHook on all the installed plugins. This method will return true if any of
     * the plugins returns true which means the request should be retried.
     *
     * @param error error to handle
     * @param origRequest original request
     * @param request the modified request
     * @param client the client for the originator of the request
     * @returns {Promise.<Boolean>}
     */
    handleErrorHook(error, origRequest, request, client) {
      // execute the plugins in order by chaining the promises
      return this.plugins.reduce((promise, plugin) => promise
        .then((retry) => (!plugin ? retry : plugin.handleErrorHook(error, origRequest, request, client)
          .catch((err) => {
            // log the error and prevent the bad plugin from breaking everyone
            logger.error(err);
            return false;
          })
          .then((localRetry) => localRetry || retry))), Promise.resolve(false));
    }

    /**
     * Remember the client associated with a request
     *
     * @param request the request
     * @param client the originating client associated with the request
     * @private
     */
    saveRequestClient(request, client) {
      this.requestClientMap[request] = client;
    }

    /**
     * Return the client associated with the given request.
     *
     * @param request the request for looking up the client
     * @returns {*}
     * @private
     */
    getRequestClient(request) {
      return this.requestClientMap[request];
    }

    /**
     * Delete the client associated with the given request.
     *
     * @param request the request for the client to delete
     * @private
     */
    deleteRequestClient(request) {
      delete this.requestClientMap[request];
    }

    /**
     * Returns true if there's a registered offline handler.
     *
     * @returns {*|boolean}
     */
    get hasOfflineHandler() {
      return this.offlineHandler && typeof this.offlineHandler.handleRequest === 'function';
    }

    /**
     * Return true is processUseCacheResponseWhenOfflineHandler is enabled.
     *
     * @returns {*|{}|boolean}
     */
    get useCacheResponseWhenOfflineHeaderEnabled() {
      return this.config && this.config.useCacheResponseWhenOfflineHeaderEnabled;
    }

    /**
     * Handle the request by performing the following:
     * 1. Clone the original request
     * 2. Invoke handleRequestHook on all registered handler plugin
     * 3. Invoke the browser fetch
     * 4. Invoke handleResponseHook on all registered handler plugins. Retry the request if any handleResponseHook call
     *    returns true
     * 5. Invoke handleErrorHook on all registered handler plugins if the fetch request fails. Retry the request if
     *    any handleErrorHook call returns true
     *
     * @param origRequest the original request object
     * @param client the originating client of the request which can be used to post message back to the client
     * @param skipOfflineHandler if true, skip forwarding the request to the offline handler
     * @param retryCount current retry count
     * @returns {Promise}
     */
    handleRequest(origRequest, client, skipOfflineHandler, retryCount = 0) {
      // console.log(`handleRequest() url = ${origRequest.url}`);
      return this.checkCache(origRequest.url).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        // can't modify navigate or OPTIONS request so directly call browser fetch on the request
        if (origRequest.mode === 'navigate' || origRequest.method === 'OPTIONS') {
          return this.fetch(origRequest)
            // check PWA cache again, because this could be request for index.html that failed due to false positive
            // online check
            .catch((err) => this.checkCache(origRequest.url, Constants.LOOKUP_INDEX_MODE)
              .then((res) => {
                if (res !== undefined) {
                  return res;
                }
                throw err;
              }));
        }

        // for PWA or if offline support is enabled, directly process the request containing the
        // vb-use-cached-response-when-offline header, e.g., currentuser request or extension manager registry request,
        // using the default
        // CacheIfOfflineStrategy to cache the response
        if (!skipOfflineHandler
          && (this.useCacheResponseWhenOfflineHeaderEnabled || this.hasOfflineHandler)) {
          const header = origRequest.headers.get(Constants.USE_CACHED_RESPONSE_WHEN_OFFLINE);

          if (header) {
            // use the default CacheIfOfflineStrategy to handle the request
            return Utils.getResource('persist/defaultResponseProxy')
              .then((DefaultResponseProxy) => {
                const options = OptCacheStrategiesFactory.getCacheStrategy(this.config, origRequest);
                return DefaultResponseProxy.getResponseProxy(options).processRequest(origRequest);
              });
          }
        }

        // delegate to the offlineHandler to handle the request
        if (!skipOfflineHandler && this.hasOfflineHandler) {
          // save the client associated with the request so it can be looked up when the offline handler calls
          // back into the fetch handler
          this.saveRequestClient(origRequest, client);

          // hand off to the offline handler
          return this.offlineHandler.handleRequest(origRequest, this.scope, client).finally(() => {
            // delete the client associated with the request
            this.deleteRequestClient(origRequest);
          });
        }

        let origResponse;
        let origError;
        let modifiedRequest;
        return this.cloneRequest(origRequest)
          .then((request) => {
            // if the request is null, that means the clone failed so simply call fetch on the original request
            if (!request) {
              return this.fetch(origRequest);
            }

            return this.handleRequestHook(request, client)
              .then((r2) => {
                modifiedRequest = r2;
                return this.fetch(r2);
              })
              .then((response) => {
                origResponse = response;
                return this.handleResponseHook(response, origRequest, modifiedRequest, client);
              })
              .catch((err) => {
                logger.error(err);
                origError = err;
                return this.handleErrorHook(err, origRequest, modifiedRequest, client);
              })
              .then((retry) => {
                if (retry) {
                  if (retryCount < MAX_RETRIES) {
                    // retry
                    logger.info('Retrying request', retryCount);
                    return this.handleRequest(origRequest, client, skipOfflineHandler, retryCount + 1);
                  }

                  logger.info('Max retry count reached.');
                }

                if (origResponse) {
                  return origResponse;
                }

                throw origError;
              });
          });
      });
    }

    /**
     * @param request the request to consider for dynamic caching
     * @returns {Promise<Response>} a promise to a response that was fetched and cached, or undefined, if response
     * was not fetched
     */
    fetchAndCache(request) {
      return Promise.resolve()
        .then(() => {
          if (this.cacheStrategy) {
            return this.cacheStrategy.fetchAndCache(request);
          }
          return undefined;
        })
        .catch((err) => {
          logger.error('fetchAndCache() failed', err);
        });
    }

    /**
     * @param url
     * @param mode determines whether any optimizations should be performed during cache lookup
     * @returns {Promise<void>} a promise to get a response from a cache, or undefined, if no matching response is found
     * in the cache. Cache lookup could be skipped altogether if cacheStrategy.shouldCheckCache() returns false
     */
    checkCache(url, mode) {
      return Promise.resolve()
        .then(() => {
          if (this.cacheStrategy) {
            return this.cacheStrategy.shouldCheckCache(url)
              .then((shouldCheckCache) => {
                if (shouldCheckCache) {
                  return this.cacheStrategy.checkCache(url, mode);
                }
                return undefined;
              });
          }
          return undefined;
        })
        .catch((err) => {
          logger.error('checkCache() failed', err);
        });
    }

    /**
     * @returns {Promise<void>} a promise to cache assets during ServiceWorker install event
     */
    cacheOnInstall() {
      return Promise.resolve()
        .then(() => {
          if (this.cacheStrategy) {
            return this.cacheStrategy.cacheOnInstall();
          }
          return undefined;
        })
        .catch((err) => {
          logger.error('cacheOnInstall() failed', err);
        });
    }

    /**
     * @returns {Promise<void>} a promise to perform per request caching operations
     */
    cacheOnRequest() {
      return Promise.resolve()
        .then(() => this.cacheStrategy.cacheOnRequest())
        .catch((err) => {
          logger.error('cacheOnRequest() failed', err);
        });
    }
  }
  return FetchHandler;
});

/* eslint-disable no-unused-vars */
/* eslint-disable class-methods-use-this */



define('vbsw/private/serviceWorkerWrapper',['vbsw/private/utils'], (Utils) => {
  /**
   * Base wrapper class for a service worker instance.
   */
  class ServiceWorkerWrapper {
    constructor(scope) {
      this.scope = scope;
      this.messageHandlers = [];
    }

    /**
     * Called by unit tests to unregister a service worker.
     *
     * @returns {Promise<T>}
     */
    unregister() {
      return Promise.resolve().then(() => {
        if (this.registration) {
          return this.registration.unregister();
        }
        return undefined;
      });
    }

    /**
     * Called by unit tests to completely clean up a service worker.
     *
     * @returns {Promise}
     */
    uninstall() {
      return this.uninstallPlugins()
        .then(() => this.uninstallOfflineHandler())
        .then(() => {
          // clean up the message handler
          if (this.messageEventListener) {
            this.removeMessageEventListener(this.messageEventListener);
            this.messageEventListener = null;
            this.messageHandlers = [];
          }
        })
        .then(() => this.unregister());
    }

    /**
     * Load and install the given plugins. The plugins should be an array of urls.
     *
     * @param plugins an array of urls for the plugins to install
     * @param reload if true, force reload all the plugins, otherwise, only reload plugins whose metadata has changed
     * @returns {Promise}
     */
    installPlugins(plugins, reload = true) {
      return Promise.resolve();
    }

    /**
     * Uninstall currently installed plugins. This is used for testing purpose.
     *
     * @returns {*}
     */
    uninstallPlugins() {
      return Promise.resolve();
    }

    /**
     * Install the given message handler with the service worker.
     *
     * @param messageHandler the message handler to install
     */
    installMessageHandler(messageHandler) {
      if (!this.messageEventListener) {
        this.messageEventListener = (event) => {
          const data = event.data;
          if (typeof data === 'object' && data.method) {
            const method = data.method;
            const args = data.args || [];
            const client = event.ports[0];

            // invoke the method on the last handler that can handle the message to simulate overriding behavior
            const invoked = this.messageHandlers.reverse().some((handler) => {
              if (typeof handler[method] === 'function') {
                Utils.postResponse(client, handler[method](...args), `${method}`);
                return true;
              }
              return false;
            });

            // reject the message if no message handler is found
            if (!invoked) {
              // eslint-disable-next-line prefer-promise-reject-errors
              Utils.postResponse(client, Promise.reject('No message handler found.'), `${method}`);
            }
          }
        };
        this.addMessageEventListener(this.messageEventListener);
      }

      this.messageHandlers.push(messageHandler);
    }

    /**
     * Uninstall the given message handler.
     *
     * @param messageHandler message handler to uninstall
     */
    uninstallMessageHandler(messageHandler) {
      const index = this.messageHandlers.indexOf(messageHandler);
      if (index > -1) {
        this.messageHandlers.splice(index, 1);
      }

      // remove the message event listener if there's no more message handlers left
      if (this.messageHandlers.length === 0) {
        this.removeMessageEventListener(this.messageEventListener);
        this.messageEventListener = null;
      }
    }

    /**
     * Register a message event listener.
     *
     * @param listener the listener to register
     */
    addMessageEventListener(listener) {
      // install the message listener on window
      window.addEventListener('message', listener, false);
    }

    /**
     * Unregister the given message event listener.
     *
     * @param listener the listener to unregister
     */
    removeMessageEventListener(listener) {
      window.removeEventListener('message', listener);
    }

    /**
     * Load and install the offline handler. If the application wants to use the offline toolkit to handle requests,
     * it needs to implement a createOfflineHandler method on app-flow.js that returns an object with a handleRequest
     * method. For example:
     *
     * {
     *   handleRequest: function (request) {
     *     var responseProxy = DefaultResponseProxy.getResponseProxy(options);
     *     return responseProxy.processRequest(request);
     *   }
     * }
     *
     * @param handlerUrl the url from which to load the offline handler
     * @returns {Promise}
     */
    installOfflineHandler(handlerUrl) {
      return Promise.resolve();
    }

    /**
     * Uninstall offline handler.
     *
     * @returns {Promise}
     */
    uninstallOfflineHandler() {
      return Promise.resolve();
    }

    /**
     * Inform the service worker to perform a sync of cached offline data.
     *
     * @param options any options to be passed to the persistence sync manager
     * @returns {Promise}
     */
    syncOfflineData(options) {
      return Promise.resolve();
    }

    /**
     * Set options on the offline handler.
     *
     * @param options options to be set on the offline handler
     * @returns {Promise}
     */
    setOfflineHandlerOptions(options) {
      return Promise.resolve();
    }

    /**
     * Register the requests to be skipped by the service worker.
     *
     * @param requests an array of objects containing the url and method, e.g., [{ url: 'xxxx', method: 'GET' }]
     * @returns {Promise}
     */
    addRequestsToSkip(requests) {
      return Promise.resolve();
    }

    /**
     * Deregister the requests to be skipped by the service worker.
     *
     * @param requests an array of objects containing the url and method, e.g., [{ url: 'xxxx', method: 'GET' }]
     * @returns {Promise}
     */
    removeRequestsToSkip(requests) {
      return Promise.resolve();
    }
  }
  return ServiceWorkerWrapper;
});



define('vbsw/private/emulatedServiceWorkerWrapper',['vbsw/private/serviceWorkerWrapper',
  'vbsw/private/fetchHandler'], (ServiceWorkerWrapper, FetchHandler) => {
  /**
   * Wrapper class for a emulated service worker instance.
   */
  class EmulatedServiceWorkerWrapper extends ServiceWorkerWrapper {
    constructor(scope, registration, config, persistenceManager) {
      super(scope);
      this.isEmulated = true;
      this.registration = registration;
      this.fetchHandler = new FetchHandler(scope, config, persistenceManager);

      this.activateUrlMapping(); // called after fetchHandler assigned
    }

    /**
     * Load and install the given plugins. The plugins should be an array of urls.
     *
     * @param plugins an array of urls for the plugins to install
     * @param reload if true, force reload all the plugins, otherwise, only reload plugins whose metadata has changed
     * @returns {Promise}
     */
    installPlugins(plugins, reload = true) {
      return this.fetchHandler.installPlugins(plugins, reload);
    }

    /**
     * Uninstall currently installed plugins. This is used for testing purpose.
     *
     * @returns {*}
     */
    uninstallPlugins() {
      return this.fetchHandler.uninstallPlugins();
    }

    /**
     * Load and install the offline handler.
     *
     * @param handlerUrl the url from which to load the offline handler
     * @returns {Promise}
     */
    installOfflineHandler(handlerUrl) {
      return this.fetchHandler.installOfflineHandler({ offlineHandler: handlerUrl });
    }

    /**
     * Uninstall offline handler.
     *
     * @returns {Promise}
     */
    uninstallOfflineHandler() {
      return this.fetchHandler.uninstallOfflineHandler();
    }

    /**
     * Get the FetchHandler to perform a sync of cached offline data.
     *
     * @param options any options to be passed to the persistence sync manager
     * @returns {Promise}
     */
    syncOfflineData(options) {
      return this.fetchHandler.syncOfflineData(options);
    }

    /**
     * Get the FetchHandler to return the offline sync log.
     *
     * @returns {*}
     */
    getOfflineSyncLog() {
      return this.fetchHandler.getOfflineSyncLog();
    }

    /**
     * Get the FetchHandler to insert a new request into the offline sync log.
     *
     * @param request request to insert
     * @param options
     * @returns {*}
     */
    insertOfflineSyncRequest(request, options) {
      return this.fetchHandler.insertOfflineSyncRequest(request, options);
    }

    /**
     * Get the FetchHandler to delete a request from the offline sync log.
     *
     * @param requestId the id for the request to delete
     * @returns {*}
     */
    removeOfflineSyncRequest(requestId) {
      return this.fetchHandler.removeOfflineSyncRequest(requestId);
    }

    /**
     * Get the FetchHandler to update a request in the offline sync log.
     *
     * @param requestId the id for the request to update
     * @param request updated request
     * @returns {*}
     */
    updateOfflineSyncRequest(requestId, request) {
      return this.fetchHandler.updateOfflineSyncRequest(requestId, request);
    }

    /**
     * If the flag is true, inform the FetchHandler to force the PersistenceManager offline and vice versa.
     *
     * @param flag if true, force the PersistenceManager offline and vice versa
     * @returns {Promise}
     */
    forceOffline(flag) {
      return this.fetchHandler.forceOffline(flag);
    }

    /**
     * Set options on the offline handler.
     *
     * @param options options to be set on the offline handler
     * @returns {Promise}
     */
    setOfflineHandlerOptions(options) {
      return this.fetchHandler.setOfflineHandlerOptions(options);
    }

    /**
     * Ask the FetchHandler for its online status.
     *
     * @returns {Promise.<Boolean>}
     */
    isOnline() {
      return this.fetchHandler.isOnline();
    }

    /**
     * activate URL Mapping
     * @returns {Promise}
     */
    activateUrlMapping() {
      return Promise.resolve(this.fetchHandler.activateUrlMapping());
    }

    /**
     * This method is called by the PersistenceManager to handle intercepted requests.
     *
     * @param request the intercepted request
     * @returns {Promise}
     */
    handleRequest(request) {
      return this.fetchHandler.handleRequest(request);
    }
  }
  return EmulatedServiceWorkerWrapper;
});



define('vbsw/private/browserServiceWorkerWrapper',['vbsw/private/utils',
  'vbsw/private/serviceWorkerWrapper'], (Utils, ServiceWorkerWrapper) => {
  /**
   * Wrapper class for a browser service worker instance.
   */
  class BrowserServiceWorkerWrapper extends ServiceWorkerWrapper {
    constructor(scope, serviceWorker, config, registration) {
      super(scope);
      this.serviceWorker = serviceWorker;
      this.registration = registration;
      if (config.isPwa) {
        this.cacheOnRequest(config);
      }
    }

    /**
     * An opportunity for FetchHandler to perform cache operations on every request
     * @returns {Promise<void>} a Promise to perform resource caching operations
     */
    cacheOnRequest() {
      const msg = {
        method: 'cacheOnRequest',
        args: [],
      };
      return this.postMessage(msg).catch(() => {
        // ignore the error
      });
    }

    /**
     * Load and install the given plugins. The plugins should be an array of urls.
     *
     * @param plugins an array of urls for the plugins to install
     * @param reload if true, force reload all the plugins, otherwise, only reload plugins whose metadata has changed
     * @returns {Promise}
     */
    installPlugins(plugins, reload = true) {
      // post a message to the service worker to install the plugins
      const msg = {
        method: 'installPlugins',
        args: [plugins, reload],
      };

      return this.postMessage(msg).catch(() => {
        // ignore error
      });
    }

    /**
     * Uninstall currently installed plugins. This is used for testing purpose.
     * @returns {*}
     */
    uninstallPlugins() {
      // post a message to the service worker to install the plugins
      const msg = {
        method: 'uninstallPlugins',
        args: [],
      };

      return this.postMessage(msg).catch(() => {
        // ignore error
      });
    }

    /**
     ** @returns {Promise<unknown>}
     * @override
     */
    activateUrlMapping() {
      const msg = {
        method: 'activateUrlMapping',
        args: [],
      };
      return this.postMessage(msg);
    }

    /**
     * Register the given listener with the service worker as a message event listener.
     *
     * @param listener the listener to register
     */
    addMessageEventListener(listener) {
      // listen for messages from the service worker
      navigator.serviceWorker.addEventListener('message', listener);

      // also install the listener on window
      super.addMessageEventListener(listener);
    }

    /**
     * Unregister the given message event listener from the service worker.
     *
     * @param listener the listener to unregister
     */
    removeMessageEventListener(listener) {
      navigator.serviceWorker.removeEventListener('message', listener);

      // also remove the listener from window
      super.removeMessageEventListener(listener);
    }

    /**
     * Uninstall offline handler.
     *
     * @returns {Promise}
     */
    uninstallOfflineHandler() {
      const msg = {
        method: 'uninstallOfflineHandler',
        args: [],
      };

      return this.postMessage(msg);
    }

    /**
     * Dynamically load the PersistenceUtils.
     *
     * @returns {*}
     */
    getPersistenceUtils() {
      if (!this.persistenceUtilsPromise) {
        this.persistenceUtilsPromise = Utils.getResource('persist/persistenceUtils');
      }
      return this.persistenceUtilsPromise;
    }

    /**
     * Serialize the given Request instance into a JSON object.
     *
     * @param request request to serialize
     * @returns {Object}
     */
    serializeRequest(request) {
      return this.getPersistenceUtils()
        .then((PersistenceUtils) => PersistenceUtils.requestToJSON(request));
    }

    /**
     * Deserialize the given request JSON object into a Request instance.
     *
     * @param requestJson request json to deserialize
     * @returns {Request}
     */
    deserializeRequest(requestJson) {
      return this.getPersistenceUtils()
        .then((PersistenceUtils) => PersistenceUtils.requestFromJSON(requestJson));
    }

    /**
     * Deserialize the given response JSON object into a Response instance.
     *
     * @param responseJson response json to deserialize
     * @returns {*}
     */
    deserializeResponse(responseJson) {
      return this.getPersistenceUtils()
        .then((PersistenceUtils) => PersistenceUtils.responseFromJSON(responseJson));
    }

    /**
     * Deserialize the give result by deserializing all request/response JSON objects into
     * Request/Response instances.
     *
     * @param result result to deserialize
     * @returns {Promise<T>}
     */
    deserializeSyncOperationResult(result) {
      return Promise.resolve().then(() => {
        if (result) {
          if (Array.isArray(result)) {
            const deserializedResult = [];
            const promises = result.map((entry) => this.deserializeSyncOperationResult(entry)
              .then((deserializedEntry) => {
                deserializedResult.push(deserializedEntry);
              }));
            return Promise.all(promises).then(() => deserializedResult);
          }

          if (Utils.isObject(result)) {
            const deserializedResult = Object.assign({}, result);
            const promises = [];

            if (result.request) {
              promises.push(this.deserializeRequest(result.request)
                .then((request) => {
                  deserializedResult.request = request;
                }));
            }

            if (result.response) {
              promises.push(this.deserializeResponse(result.response)
                .then((response) => {
                  deserializedResult.response = response;
                }));
            }

            return Promise.all(promises).then(() => deserializedResult);
          }
        }

        return result;
      });
    }

    /**
     * Get the FetchHandler to perform a sync of cached offline data.
     *
     * @param options any options to be passed to the persistence sync manager
     * @returns {Promise}
     */
    syncOfflineData(options) {
      const msg = {
        method: 'syncOfflineData',
        args: [options],
        options: {
          addClientToArgs: true, // make originating client available to the method
        },
      };

      return this.postMessage(msg)
        .catch((err) => this.deserializeSyncOperationResult(err)
          .then((deserializedErr) => {
            throw deserializedErr;
          }));
    }

    /**
     * Get the FetchHandler to return the offline sync log.
     *
     * @returns {*}
     */
    getOfflineSyncLog() {
      const msg = {
        method: 'getOfflineSyncLog',
      };

      return this.postMessage(msg)
        .then((syncLog) => this.deserializeSyncOperationResult(syncLog));
    }

    /**
     * Get the FetchHandler to insert a new request into the offline sync log.
     *
     * @param request request to insert
     * @param options
     * @returns {*}
     */
    insertOfflineSyncRequest(request, options) {
      return this.serializeRequest(request).then((requestJson) => {
        const msg = {
          method: 'insertOfflineSyncRequest',
          args: [requestJson, options],
        };

        return this.postMessage(msg)
          .then((result) => this.deserializeRequest(result));
      });
    }

    /**
     * Get the FetchHandler to delete a request from the offline sync log.
     *
     * @param requestId the id for the request to delete
     * @returns {*}
     */
    removeOfflineSyncRequest(requestId) {
      const msg = {
        method: 'removeOfflineSyncRequest',
        args: [requestId],
      };

      return this.postMessage(msg)
        .then((requestJson) => this.deserializeRequest(requestJson));
    }

    /**
     * Get the FetchHandler to update a request in the offline sync log.
     *
     * @param requestId the id for the request to update
     * @param request updated request
     * @returns {*}
     */
    updateOfflineSyncRequest(requestId, request) {
      return this.serializeRequest(request).then((requestJson) => {
        const msg = {
          method: 'updateOfflineSyncRequest',
          args: [requestId, requestJson],
        };

        return this.postMessage(msg)
          .then((result) => this.deserializeRequest(result));
      });
    }

    /**
     * Set options on the offline handler.
     *
     * @param options options to be set on the offline handler
     * @returns {Promise}
     */
    setOfflineHandlerOptions(options) {
      const msg = {
        method: 'setOfflineHandlerOptions',
        args: [options],
      };

      return this.postMessage(msg);
    }

    /**
     * If the flag is true, inform the service worker to force the PersistenceManager offline and vice versa.
     *
     * @param flag if true, force the PersistenceManager offline and vice versa
     * @returns {Promise}
     */
    forceOffline(flag) {
      const msg = {
        method: 'forceOffline',
        args: [flag],
      };

      return this.postMessage(msg);
    }

    /**
     * Ask the service worker for its online status.
     *
     * @returns {Promise.<Boolean>}
     */
    isOnline() {
      const msg = {
        method: 'isOnline',
        args: [],
      };

      return this.postMessage(msg);
    }

    /**
     * Return the service worker configuration.
     *
     * @returns {Promise}
     */
    getConfig() {
      const msg = {
        method: 'getConfig',
        args: [],
      };

      return this.postMessage(msg);
    }

    /**
     * Register the requests to be skipped by the service worker.
     *
     * @param requests an array of objects containing the url and method, e.g., [{ url: 'xxxx', method: 'GET' }]
     * @returns {Promise}
     */
    addRequestsToSkip(requests) {
      const msg = {
        method: 'addRequestsToSkip',
        args: [requests],
      };

      return this.postMessage(msg);
    }

    /**
     * Deregister the requests to be skipped by the service worker.
     *
     * @param requests an array of objects containing the url and method, e.g., [{ url: 'xxxx', method: 'GET' }]
     * @returns {Promise}
     */
    removeRequestsToSkip(requests) {
      const msg = {
        method: 'removeRequestsToSkip',
        args: [requests],
      };

      return this.postMessage(msg);
    }

    /**
     * Post the given message to the service worker for invoking a method on the fetchHandler. The message
     * has the following format:
     *
     * {
     *   method: 'methodName',  // name of the method to invoke
     *   args: [...],  // arguments to the method
     *   options: {
     *     addClientToArgs: true,  // make the calling client available to the callee for return communication
     *   }
     * }
     *
     * @param message the message to post
     * @returns {Promise}
     */
    postMessage(message) {
      // use navigator.serviceWorker.controller which is more reliable than the service worker instance
      // we get during registration
      // note; fallback to using this.serviceWorker, because controller could be null
      // during unit testing ('grunt test-release', using compiled sources, which uses real service workers).

      // TODO: discuss this change with Peter
      // const sw = navigator.serviceWorker.controller || this.serviceWorker;
      const sw = this.serviceWorker || navigator.serviceWorker.controller;
      return Utils.postMessage(sw, message);
    }
  }

  return BrowserServiceWorkerWrapper;
});

/* eslint-disable class-methods-use-this */



define('vbsw/private/serviceWorkerManagerClass',[
  'vbsw/private/utils',
  'vbsw/private/fetchHandler',
  'vbsw/private/pwa/pwaUtils',
  'vbsw/private/emulatedServiceWorkerWrapper',
  'vbsw/private/browserServiceWorkerWrapper',
], (Utils, FetchHandler, PwaUtils, EmulatedServiceWorkerWrapper, BrowserServiceWorkerWrapper) => {
  /**
   * This class is used to install service workers and provides apis for installing plugins.
   */
  class ServiceWorkerManagerClass {
    constructor() {
      this.serviceWorkerWrappers = {};
    }

    /**
     * Install service workers.
     *
     * @param modulePath the path from which the service worker should its dependent modules
     * @param externalConfig config object containing external require config, plugins, and logConfig
     * @param Configuration applicationUrl and getBaseUrlFromConfig()
     */
    installServiceWorkers(modulePath, externalConfig, Configuration) {
      return this.getServiceWorkerConfig(modulePath, externalConfig, Configuration).then((config) => {
        const promises = [];
        config.scopes.forEach((scope) => {
          promises.push(this.installServiceWorker(scope, config));
        });

        return Promise.all(promises)
          // need to activate the url mapper client after installing the service worker
          .then((results) => this.activateUrlMapping()
            .then(() => results));
      });
    }

    /**
     * Activate the url mapper client running on the service worker.
     *
     * @returns {*}
     */
    activateUrlMapping() {
      return this.serviceWorkerWrapper ? this.serviceWorkerWrapper.activateUrlMapping() : Promise.resolve();
    }

    /**
     * Return an array of service worker scopes currently registered.
     *
     * @returns {Array}
     */
    getServiceWorkerScopes() {
      return Object.keys(this.serviceWorkerWrappers);
    }

    /**
     * Load and install the plugins for the given scope. The plugins should be an array of urls.
     *
     * @param plugins an array of urls for the plugins to install
     * @param reload if true, force reload all the plugins, otherwise, only reload plugins whose metadata has changed
     * @returns {Promise}
     */
    installServiceWorkerPlugins(plugins, reload = true) {
      // update the config.plugins so a newly found installing service worker can install them
      if (this.config) {
        this.config.plugins = plugins;
      }

      // protect against undefined serviceWorkerWrapper which can happen during unit tests
      return this.serviceWorkerWrapper ? this.serviceWorkerWrapper.installPlugins(plugins, reload) : Promise.resolve();
    }

    /**
     * Install the given message handler with the registered service workers. A message handler can implement
     * a set of methods with parameters that can be invoked via messages posted from the service worker. Each method
     * should return a promise that resolves to a response or rejects with an error. Note that multiple message
     * handlers can be installed.
     *
     * A method on the message handler can be invoked from the service worker by calling Utils.postMessage with a
     * message shown below:
     *
     * {
     *   method: 'methodToCall',
     *   args: ['foo']
     * }
     *
     * Note that only the last installed message handler containing the method specified in the message will be
     * invoked. This means a message handler can override the behavior of a handler registered before it. If this
     * is not the intended behavior, make sure there is no naming conflicts.
     *
     * @param messageHandler the message handler to install
     */
    installMessageHandler(messageHandler) {
      if (this.serviceWorkerWrapper) {
        this.serviceWorkerWrapper.installMessageHandler(messageHandler);
      } else {
        // put the message handler on a queue so it can be installed when the service worker is installed
        this.messageHandlerQueue = this.messageHandlerQueue || [];
        this.messageHandlerQueue.push(messageHandler);
      }
    }

    /**
     * Uninstall the given message handler.
     *
     * @param messageHandler message handler to uninstall
     */
    uninstallMessageHandler(messageHandler) {
      if (this.serviceWorkerWrapper) {
        this.serviceWorkerWrapper.uninstallMessageHandler(messageHandler);
      }
    }

    /**
     * Return a FetchHandler with all the plugins installed that can be used locally to process a fetch request.
     *
     * @returns {Promise}
     */
    getLocalFetchHandler() {
      if (!this.localFetchHandlerPromise) {
        this.localFetchHandlerPromise = Promise.resolve().then(() => {
          if (!this.config.isEmulated) {
            const localFetchHandler = new FetchHandler('/');

            // make sure we set up the require config for loading the plugins
            if (this.config.requireConfig) {
              requirejs.config(this.config.requireConfig);
            }

            return localFetchHandler.installPlugins(this.config.plugins, true)
              .then(() => {
                if (this.config.hasOfflineHandler) {
                  const offlineHandler = this.getDefaultOfflineHandlerUrl();
                  const browserFetch = fetch;
                  return localFetchHandler.installOfflineHandler({ offlineHandler })
                    .then(() => {
                      // restore fetch which is overridden to intercept requests by the persistence
                      // manager to the original to prevent double interception since requests are
                      // already being intercepted by the service worker
                      fetch = browserFetch;
                    });
                }
                return undefined;
              })
              .then(() => localFetchHandler);
          }

          // when running in emulation mode, return a pass-through fetch handler to avoid
          // double interceptions
          return {
            handleRequest(request) {
              return fetch(request);
            },
            hasOfflineHandler: this.config.hasOfflineHandler,
          };
        });
      }

      return this.localFetchHandlerPromise;
    }

    /**
     * Return the default url for the offline handler.
     *
     * @returns {string}
     */
    getDefaultOfflineHandlerUrl() {
      // get the base token url from vbInitConfig if any
      const vbConfig = window.vbInitConfig || {};

      if (vbConfig.CONTEXT_OFFLINE_HANDLER_PATH) {
        return vbConfig.CONTEXT_OFFLINE_HANDLER_PATH;
      }

      // requirejs baseUrl is already set in main.js using the BASE_URL and
      // the BASE_URL_TOKEN so we don't need to do any more path manipulation
      // to access app-flow.js. It is important to NOT terminate the file with
      // .js otherwise requirejs does not conform to the "baseUrl + paths"
      // rules for finding it.
      // https://requirejs.org/docs/api.html#jsfiles
      return 'app-flow';
    }

    /**
     * Determine if the application has an offline handler defined.
     *
     * @returns {Promise<boolean>}
     */
    hasOfflineHandler() {
      const handlerUrl = this.getDefaultOfflineHandlerUrl();

      return Utils.getResource(handlerUrl).then((Module) => {
        let module;
        if (Module) {
          // Module can be either a constructor or a singleton
          module = typeof Module === 'function' ? new Module() : Module;
        } else {
          module = {};
        }

        if (typeof module.createOfflineHandler === 'function') {
          return module.createOfflineHandler();
        }

        return false;
      }).catch(() => false);
    }

    /**
     * Load and install the offline handler.
     *
     * @returns {Promise}
     */
    installOfflineHandler() {
      const handlerUrl = this.getDefaultOfflineHandlerUrl();
      return this.serviceWorkerWrapper.installOfflineHandler(handlerUrl);
    }

    /**
     * Uninstall the offline handler.
     *
     * @returns {Promise}
     */
    uninstallOfflineHandler() {
      return this.serviceWorkerWrapper.uninstallOfflineHandler();
    }

    /**
     * Invoke syncOfflineData on the service worker.
     *
     * @param options any options to be passed to the persistence sync manager
     * @returns {Promise}
     */
    syncOfflineData(options) {
      return this.serviceWorkerWrapper.syncOfflineData(options);
    }

    /**
     * Invoke getOfflineSyncLog on the service worker.
     *
     * @returns {*}
     */
    getOfflineSyncLog() {
      return this.serviceWorkerWrapper.getOfflineSyncLog();
    }

    /**
     * Invoke insertOfflineSyncRequest on the service worker.
     *
     * @param request
     * @param options
     * @returns {*}
     */
    insertOfflineSyncRequest(request, options) {
      return this.serviceWorkerWrapper.insertOfflineSyncRequest(request, options);
    }

    /**
     * Invoke removeOfflineSyncRequest on the service worker.
     *
     * @param requestId
     * @returns {*}
     */
    removeOfflineSyncRequest(requestId) {
      return this.serviceWorkerWrapper.removeOfflineSyncRequest(requestId);
    }

    /**
     * Invoke updateOfflineSyncRequest on the service worker.
     *
     * @param requestId
     * @param request
     * @returns {*}
     */
    updateOfflineSyncRequest(requestId, request) {
      return this.serviceWorkerWrapper.updateOfflineSyncRequest(requestId, request);
    }

    /**
     * If the flag is true, force the PersistenceManager offline and vice versa.
     *
     * @param flag if true, force the PersistenceManager offline and vice versa.
     */
    forceOffline(flag) {
      return this.serviceWorkerWrapper.forceOffline(flag);
    }

    /**
     * Set options on the offline handler.
     *
     * @param options options to be set on the offline handler
     * @returns {Promise}
     */
    setOfflineHandlerOptions(options) {
      return this.serviceWorkerWrapper.setOfflineHandlerOptions(options);
    }

    /**
     * Return a promise that resolves to true if the service worker is online, false otherwise.
     *
     * @return {Promise.<Boolean>}
     */
    isOnline() {
      return this.serviceWorkerWrapper.isOnline();
    }

    /**
     * Register the requests to be skipped by the service worker.
     *
     * @param requests an array of objects containing the url and method, e.g., [{ url: 'xxxx', method: 'GET' }]
     * @returns {Promise}
     */
    addRequestsToSkip(requests) {
      return this.serviceWorkerWrapper.addRequestsToSkip(requests);
    }

    /**
     * Deregister the requests to be skipped by the service worker.
     *
     * @param requests an array of objects containing the url and method, e.g., [{ url: 'xxxx', method: 'GET' }]
     * @returns {Promise}
     */
    removeRequestsToSkip(requests) {
      return this.serviceWorkerWrapper.removeRequestsToSkip(requests);
    }

    /**
     * Return the configuration object for the service worker. The configuration object should be specified on
     * the vbInitConfig as follow:
     *
     * SERVICE_WORKER_CONFIG: {
     *   scriptUrl: '/serviceWorker.js',
     *   scopes: ['/'],
     *   disabled: false
     * }
     *
     * The scriptUrl is the location where the service worker script is served. The scopes is an array of urls
     * that need to be relative to the scriptUrl. Otherwise, the service worker will fail to register. Both
     * scriptUrl and scope must be specified in order for them to take effect. Otherwise, a default scriptUrl
     * and scope will be derived from the CONTEXT_ROOT, APP_ID and APP_VERSION specified in vbInitConfig which
     * will be suitable for use in the VBCS environment.
     *
     * Setting the disabled flag to true will disable loading of the service worker and fall back to using
     * emulation.
     *
     * @param modulePath the path from which the service worker loads its dependent modules
     * @param externalConfig config object containing external require config, plugins, and logConfig
     * @param Configuration applicationUrl and getBaseUrlFromConfig()
     * @returns {*}
     * @private
     */
    getServiceWorkerConfig(modulePath, externalConfig, Configuration) {
      return Promise.resolve().then(() => {
        const vbConfig = window.vbInitConfig || {};
        const config = vbConfig.SERVICE_WORKER_CONFIG || {};

        config.applicationUrl = Configuration.applicationUrl;
        config.baseUrl = Configuration.getBaseUrlFromConfig(vbConfig, config.applicationUrl);

        // if scriptUrl or scope is not provided, derive them from context root, app url prefix, app id and app version
        if (!config.scriptUrl || !config.scopes) {
          const appId = vbConfig.APP_ID;
          const appVersion = vbConfig.APP_VERSION;
          const appUrlPrefix = vbConfig.APP_URL_PREFIX;

          let contextRoot = vbConfig.CONTEXT_ROOT || '/';
          if (!contextRoot.startsWith('/')) {
            contextRoot = `/${contextRoot}`;
          }
          if (!contextRoot.endsWith('/')) {
            contextRoot = `${contextRoot}/`;
          }

          let scriptRoot;
          if (appId && appVersion) {
            // derive the script root for the VBCS environment
            scriptRoot = `${contextRoot}${appUrlPrefix}/${appId}/${appVersion}/`;
          } else {
            scriptRoot = contextRoot;
          }

          config.scriptUrl = `${scriptRoot}vbServiceWorker.js`;
          config.scopes = [scriptRoot];
        }

        config.dtMode = vbConfig.IS_DT_MODE;
        config.log = vbConfig.LOG;

        // set up the JET path
        // NOTE: The service worker is dependent on the location of the JET to load requirejs. If this is not available,
        // the service worker will not be able to load any of the plugins.
        if (vbConfig.JET_CDN_PATH) {
          config.jetPath = `${vbConfig.JET_CDN_PATH}${vbConfig.JET_CDN_VERSION}/`;
        }

        config.baseUrlToken = vbConfig.BASE_URL_TOKEN;

        // determine the url for the offline handler
        if (vbConfig.CONTEXT_OFFLINE_HANDLER_PATH) {
          // allow override of the default path processing
          config.offlineHandler = vbConfig.CONTEXT_OFFLINE_HANDLER_PATH;
        } else {
          // strip 'index.html' off window.location.pathname
          let path = window.location.pathname;

          const htmlName = 'index.html';
          const index = path.indexOf(htmlName);
          path = index >= 0 ? path.substring(0, index) : path;

          // make sure the path ends with /
          path = !path.endsWith('/') ? `${path}/` : path;

          // use absolute url for loading the offline handler
          config.offlineHandler = `${path}${config.baseUrlToken ? `${config.baseUrlToken}/` : ''}app-flow.js`;
        }

        config.debug = vbConfig.DEBUG;

        // for DT, generate a nonce to trigger re-installation of the service worker
        if (vbConfig.IS_DT_MODE) {
          config.nonce = Utils.generateUniqueId();
        }

        // add PWA specific config
        if (PwaUtils.isMobilePwaConfig(vbConfig)) {
          config.isPwa = true;
          config.appPath = PwaUtils.computeAppPath(vbConfig);
          config.locale = PwaUtils.getLocale();

          // enable processing of request with vb-use-cached-response-when-offline header
          config.useCacheResponseWhenOfflineHeaderEnabled = true;
        } else if (PwaUtils.isWebPwaConfig(vbConfig)) {
          config.isWebPwa = true;
          config.registryUrl = vbConfig.REGISTRY_URL;
        }

        if (vbConfig.IS_MOBILE || config.isWebPwa) {
          // enable processing of request with vb-use-cached-response-when-offline header for native mobile and
          // extension registry url for web PWA
          config.useCacheResponseWhenOfflineHeaderEnabled = true;
        }

        // BUFP-23800: turn off service worker for Firefox due to CORS issue
        if (navigator.userAgent.toLowerCase()
          .indexOf('firefox') > -1) {
          config.disabled = true;
        }

        config.modulePath = modulePath;

        config.performanceConfig = vbConfig.PERFORMANCE_CONFIG;

        if (externalConfig) {
          config.requireConfig = externalConfig.requireConfig;
          config.plugins = externalConfig.plugins;
          config.logConfig = externalConfig.logConfig;
          config.userConfig = externalConfig.userConfig;
        }

        config.traceOptions = Utils.getTraceOptions(vbConfig);

        // determine if the application has an offline handler defined
        if (config.disabled === undefined) {
          return this.hasOfflineHandler().then((hasOfflineHandler) => {
            config.hasOfflineHandler = hasOfflineHandler;

            // determine if we should disable the service worker for non-PWA apps and
            // if there's no offline handler defined
            config.disabled = !config.isPwa && !config.hasOfflineHandler;

            return config;
          });
        }

        return config;
      });
    }

    /**
     * Post message the rest of the config during installation instead of clogging up the url.
     *
     * @param serviceWorker the service worker instance to which to post the config
     * @param config an option configuration for the service worker. If not specified, an existing configuration will
     * be used
     */
    configureServiceWorker(serviceWorker, config) {
      console.log('ServiceWorkerManager calling configureServiceWorker');
      if (config) {
        this.config = config;
      }

      return Utils.postMessage(serviceWorker, {
        method: 'configureServiceWorker',
        args: [this.config],
      });
    }

    /**
     * Install the default service worker for the given scope. If service worker is not supported, it will be
     * emulated using the PersistenceManager from the offline toolkit running on the main thread.
     *
     * @param {String} scope the scope under which the service worker should be registered
     * @param config the config object for the service worker
     * @returns {Promise}
     * @private
     */
    installServiceWorker(scope, config) {
      // remember the config
      this.config = config;

      // install the service worker if supported by the browser and not disabled
      if ('serviceWorker' in navigator && !config.disabled) {
        return new Promise((resolve, reject) => {
          const nonce = config.nonce ? `&nonce=${config.nonce}` : '';
          const baseUrlToken = config.baseUrlToken ? `&baseUrlToken=${config.baseUrlToken}` : '';
          let url;

          if (!config.disableOnFetch) {
            // make the jetPath, modulePath and baseUrlToken or nonce available on the script url
            // and the rest of the config object will be posted over during installation
            const jetPath = config.jetPath ? `jetPath=${config.jetPath.trim()}` : '';
            const modulePath = config.modulePath ? `&modulePath=${config.modulePath.trim()}` : '';
            const debug = config.debug ? '&debug=true' : '';
            const skipIgnoreSearch = config.skipIgnoreSearch ? `&skipIgnoreSearch=${config.skipIgnoreSearch}` : '';
            url = `${config.scriptUrl}?${jetPath}${modulePath}${baseUrlToken}${nonce}${debug}${skipIgnoreSearch}`;
          } else {
            url = `${config.scriptUrl}?disableOnFetch=true${baseUrlToken}${nonce}`;
          }
          url = encodeURI(url);

          navigator.serviceWorker.register(url, { scope })
            .then((registration) => {
              if (config.disableOnFetch) {
                // If disableOnFetch is true, immediately unregister the service worker and switch over to using
                // emulated service worker. Note that we need to do this so we can turn off existing service
                // workers.
                registration.unregister().then(() => {
                  this.emulateServiceWorker(scope).then(resolve).catch(reject);
                });
              } else {
                console.log('Service worker registration succeeded. Scope is', registration.scope, config.nonce);

                let serviceWorker;
                if (registration.installing) {
                  serviceWorker = registration.installing;

                  // post the config object to the installing service worker only if disableOnFetch is false
                  if (!config.disableOnFetch) {
                    this.configureServiceWorker(serviceWorker);
                  }
                } else if (registration.active) {
                  serviceWorker = registration.active;
                } else if (registration.waiting) {
                  serviceWorker = registration.waiting;
                }

                if (serviceWorker) {
                  // if the registered service worker is not in the installing state, register an onupdatefound
                  // listener to listen for the service worker upgrading to a new version
                  if (serviceWorker.state !== 'installing') {
                    registration.onupdatefound = () => {
                      console.log('Service worker update found.');

                      // discovered a new installing service worker, post the config object to it
                      if (registration.installing) {
                        this.configureServiceWorker(registration.installing);
                      }
                    };
                  }

                  console.log('Service worker state:', serviceWorker.state);

                  if (serviceWorker.state === 'activated') {
                    const serviceWorkerWrapper = this.addServiceWorkerWrapper(scope, serviceWorker, false, config,
                      registration);
                    resolve(serviceWorkerWrapper);
                  } else {
                    serviceWorker.onstatechange = (event) => {
                      const state = event.target.state;
                      console.log('Service worker state changed:', state);

                      let serviceWorkerWrapper;
                      if (state === 'activated') {
                        console.log('Service worker is active.');
                        serviceWorkerWrapper = this.addServiceWorkerWrapper(scope, event.target, false, config,
                          registration);
                        resolve(serviceWorkerWrapper);
                      } else if (state === 'redundant') {
                        // If we get into the redundant state, that means the service worker we got from registration
                        // is no longer valid and no further state change will happen. Simply create a wrapper
                        // around navigator.serviceWorker.controller and resolve the promise and let the browser
                        // auto switch to the new version.
                        serviceWorkerWrapper = this.addServiceWorkerWrapper(scope, navigator.serviceWorker.controller,
                          false, config, registration);
                        resolve(serviceWorkerWrapper);
                      }
                    };
                  }
                } else {
                  console.log('No service worker found in registration.');

                  // fall back to using emulation
                  this.emulateServiceWorker(scope).then(resolve).catch(reject);
                }
              }
            })
            .catch((error) => {
              console.log('Service worker registration failed with', error);

              // fall back to using emulation
              this.emulateServiceWorker(scope).then(resolve).catch(reject);
            });
        });
      }

      // fall back to using emulation
      return this.emulateServiceWorker(scope);
    }

    /**
     * Emulate the service worker functionality by using the PersistenceManager from the offline toolkit
     *
     * @param scope scope for the service worker that vbServiceWorker.js would expect. This is not the same
     * as the actual service worker scope. For example, for a service worker registered at
     * https://masterdev-vboci.integration.test.ocp.oc-test.com/ic/builder/rt/jpCRUD/1.0/webApps/web/sw.js
     * emulated service worker scope would be "/ic/builder/rt/jpCRUD/1.0/"
     * and for an application using vanity url, with service worker registered at https://myvbtest.myvb.org/sw.js
     * emulated service worker scope would be "/ic/builder/rt/jpMob2_1_0/live/"
     * @return {Promise}
     * @private
     */
    emulateServiceWorker(scope) {
      console.log('Emulating service worker using PersistenceManager.');

      // convenient way to find out we are running in emulation mode
      this.config.isEmulated = true;

      // need to set the scope here to '/' so we can intercept all requests
      return this.initializePersistenceManager().then((pm) => pm.register({ scope: '/' })
        .then((registration) => {
          const serviceWorkerWrapper = this.addServiceWorkerWrapper(scope, registration, true, this.config);

          // intercept fetch calls
          registration.addEventListener('fetch', (event) => {
            event.respondWith(serviceWorkerWrapper.handleRequest(event.request));
          });

          return serviceWorkerWrapper;
        }));
    }

    /**
     * Initialize the PersistenceManager from the offline toolkit.
     * @private
     */
    initializePersistenceManager() {
      // make sure we only initialize it once
      if (!this.persistenceManagerPromise) {
        this.persistenceManagerPromise =
          Utils.getResource('persist/persistenceManager')
            .then((PersistenceManager) => {
              this.persistenceManager = PersistenceManager;
              return PersistenceManager.init().then(() => PersistenceManager);
            });
      }

      return this.persistenceManagerPromise;
    }

    /**
     * Return the service worker wrapper for the given scope.
     *
     * @param {String} scope the scope for looking up the service worker wrapper
     * @returns {ServiceWorkerWrapper}
     * @private
     */
    getServiceWorkerWrapper(scope) {
      return this.serviceWorkerWrappers[scope];
    }

    /**
     * Create and add a ServiceWorkerWrapper instance.
     *
     * @param {String} scope the scope for the service worker wrapper
     * @param instance browser service worker instance or undefined if in emulation mode
     * @param config the service worker config
     * @param registration the service worker registration or undefined if in emulation mode
     * @returns {*}
     * @private
     */
    addServiceWorkerWrapper(scope, instance, isEmulated, config, registration) {
      let wrapper;
      if (!isEmulated) {
        wrapper = new BrowserServiceWorkerWrapper(scope, instance, config, registration);
      } else {
        // emulation mode
        wrapper = new EmulatedServiceWorkerWrapper(scope, instance, config, this.persistenceManager);
      }

      this.serviceWorkerWrappers[scope] = wrapper;

      // Since we never ended up supporting multiple service worker scopes, there is always only
      // one service worker wrapper. Therefore, we set it to this.serviceWorkerWrapper for easier
      // access
      this.serviceWorkerWrapper = wrapper;

      // install any message handlers that couldn't be installed before the service worker is available
      if (this.messageHandlerQueue) {
        this.messageHandlerQueue
          .forEach((messageHandler) => this.installMessageHandler(messageHandler));
        this.messageHandlerQueue = null;
      }

      return wrapper;
    }

    // eslint-disable-next-line  no-unused-vars, class-methods-use-this
    addToCache(resources) {
      return Promise.resolve();
    }
  }

  return ServiceWorkerManagerClass;
});



/**
 * Delegates to a specific instance of service worker manager class.
 */
define('vbsw/private/serviceWorkerManager',['vbsw/private/serviceWorkerManagerClass'], (ServiceWorkerManagerClass) => {
  class ServiceWorkerManager {
    setInstance(instance) {
      this.instance = instance;
    }

    getInstance() {
      this.instance = this.instance || new ServiceWorkerManagerClass();
      return this.instance;
    }
  }
  return new ServiceWorkerManager();
});



define('vbsw/helpers/serviceWorkerHelpers',['vbsw/private/serviceWorkerManager', 'vbsw/private/utils'], (ServiceWorkerManager, Utils) => {
  /**
   * This is a helper class that provides apis for interacting with the service worker registered with the
   * application. Note that these methods are designed to be called from the main UI thread. Regardless of whether
   * the application is running the browser service worker or emulated service worker, these methods will
   * be executed in the correct context to communicate with the service worker.
   *
   * For examples of how to use this helper, please refer to the following wiki:
   * {@link https://confluence.oraclecorp.com/confluence/display/ABCS/Offline+Persistence+Toolkit+Integration}
   */
  class ServiceWorkerHelpers {
    /**
     * Return a promise that resolves to true if the service worker is online, false otherwise.
     *
     * @return {Promise.<Boolean>}
     */
    static isOnline() {
      return ServiceWorkerManager.getInstance().isOnline();
    }

    /**
     * If the flag is true, force the PersistenceManager offline and vice versa.
     *
     * @param flag if true, force the PersistenceManager offline and vice versa
     */
    static forceOffline(flag) {
      return ServiceWorkerManager.getInstance().forceOffline(flag);
    }

    /**
     * Set options on the offline handler.
     *
     * This requires the offline handler to implement a setOptions method.
     *
     * @param options options to be set on the offline handler
     * @returns {Promise}
     */
    static setOfflineHandlerOptions(options) {
      return ServiceWorkerManager.getInstance().setOfflineHandlerOptions(options);
    }

    /**
     * Synchronize the log with the server. By default sync will first send an OPTIONS request before
     * each request URL to determine if the server is reachable. This OPTIONS request will be timed out
     * after 60s and the sync will fail with a HTTP response 504 error. If the OPTIONS request does not
     * time out then sync will progress.
     *
     * See @link https://oracle.github.io/offline-persistence-toolkit/PersistenceSyncManager.html#sync
     *
     * @param options refer to the JSDoc for PersistenceSyncManager for more detail
     * @returns {Promise}
     */
    static syncOfflineData(options) {
      return ServiceWorkerManager.getInstance().syncOfflineData(options);
    }

    /**
     * Returns a Promise which resolves to all the Requests in the Sync Log returned as an Array sorted by the
     * created date of the Request.
     *
     * See @link https://oracle.github.io/offline-persistence-toolkit/PersistenceSyncManager.html#getSyncLog
     *
     * @returns {*}
     */
    static getOfflineSyncLog() {
      return ServiceWorkerManager.getInstance().getOfflineSyncLog();
    }

    /**
     * Insert a Request into the Sync Log. The position in the Sync Log the Request will be inserted at is
     * determined by the Request created date.
     *
     * See @link https://oracle.github.io/offline-persistence-toolkit/PersistenceSyncManager.html#insertRequest
     *
     * @param request the request to insert
     * @param options refer to the JSDoc for PersistenceSyncManager for more detail
     * @returns {*}
     */
    static insertOfflineSyncRequest(request, options) {
      return ServiceWorkerManager.getInstance().insertOfflineSyncRequest(request, options);
    }

    /**
     * Delete a Request from the Sync Log.
     *
     * See @link https://oracle.github.io/offline-persistence-toolkit/PersistenceSyncManager.html#removeRequest
     *
     * @param requestId the id for the request to be deleted
     * @returns {*}
     */
    static removeOfflineSyncRequest(requestId) {
      return ServiceWorkerManager.getInstance().removeOfflineSyncRequest(requestId);
    }

    /**
     * Update a Request from the Sync Log. This function effectively replaces the Request in the sync log
     * with the provided Request.
     *
     * See @link https://oracle.github.io/offline-persistence-toolkit/PersistenceSyncManager.html#updateRequest
     *
     * @param requestId the id for the request to be updated
     * @param request updated request
     * @returns {*}
     */
    static updateOfflineSyncRequest(requestId, request) {
      return ServiceWorkerManager.getInstance().updateOfflineSyncRequest(requestId, request);
    }

    /**
     * Install a message handler on the main thread containing methods that can be invoked via
     * postMessage sent from the service worker thread using ServiceWorkerHelpers.invokeMessageHandlerMethod.
     *
     * Note that this method is a noop if called from the service worker thread.
     *
     * @param messageHandler the message handler to install
     */
    static installMainThreadMessageHandler(messageHandler) {
      try {
        // only install the message handler if we are on the main thread where window is defined
        if (window) {
          return ServiceWorkerManager.getInstance().installMessageHandler(messageHandler);
        }
      } catch (err) {
        // ignore
      }

      return undefined;
    }

    /**
     * Uninstall the message handler installed using installMainThreadMessageHandler.
     *
     * @param messageHandler handler to uninstall
     * @returns {undefined|void}
     */
    static uninstallMainThreadMessageHandler(messageHandler) {
      try {
        // only uninstall the message handler if we are on the main thread where window is defined
        if (window) {
          return ServiceWorkerManager.getInstance().uninstallMessageHandler(messageHandler);
        }
      } catch (err) {
        // ignore
      }

      return undefined;
    }

    /**
     * Invoke a method defined on the message handler registered on the main thread using
     * ServiceWorkerHelpers.installMessageHandler. This method should be called from the service worker
     * thread and the caller needs to know the client id of the main thread. One example place where
     * this method can be called is the OfflineHandler.handleRequest method where client is available from the
     * third argument of handleRequest.
     *
     * @param client client id of the main thread
     * @param method method to invoke
     * @param args arguments to the method
     * @returns {Promise}
     */
    static invokeMainThreadMessageHandlerMethod(client, method, ...args) {
      return Utils.postMessage(client, { method, args });
    }
  }

  return ServiceWorkerHelpers;
});

/* eslint-disable max-len */



define('vbsw/private/headerUtils',['vbsw/private/constants'], (Constants) => {
  // this is a list of headers that the VB proxy does not prefixed, because
  // the browser will set these, if these have not already been set.
  // the proxy is respecting only the unprefixed version of these, to prevent malicious overrides, etc.
  // taken from breeze/server/src/main/java/com/oracle/breeze/authorization/proxy/AuthResourceVersion.java
  // ALM: https://alm.oraclecorp.com/mcs/#projects/buf/scm/mcs_buf.git/blob/breeze/server/src/main/java/com/oracle/breeze/authorization/proxy/AuthResourceVersion.java?revision=master
  // (with duplicates from the forbidden list below removed).
  const browserSuppliedHeaders = [
    'Accept',
    'Accept-Language',
    'Content-Type', // wasn't in the java at the time of this list, but should have been
    'Content-Language',
    'Content-Encoding',
    'ETag',
    'If-Match',
    'If-None-Match',
    'Cache-Control',
    'Vary',
    'Last-Modified',
    'If-Modified-Since',
    'If-Unmodified-Since',
    'Expires',
    'Prefer',
    // adding this here, for convenience
    'vb-.*', // exclude all VB headers from processing (they will eventually get deleted before fetch())
  ];

  // https://tools.ietf.org/html/rfc7240
  // forbidden headers that cannot be set programmatically
  const forbiddenHeaders = [
    'Accept-Charset',
    'Accept-Encoding',
    'Access-Control-Request-Headers',
    'Access-Control-Request-Method',
    'Connection',
    'Content-Length',
    'Cookie',
    'Cookie2',
    'Date',
    'DNT',
    'Expect',
    'Host',
    'Keep-Alive',
    'Origin',
    'Proxy-.*',
    'Sec-.*',
    'Referer',
    'TE',
    'Trailer',
    'Transfer-Encoding',
    'Upgrade',
    'Via',
  ];

  // combine the lists above, for the complete list of headers to NOT prefix
  const regexpParts = [...browserSuppliedHeaders, ...forbiddenHeaders];

  const PROXY_HEADER_EXCLUSION_REGEX = new RegExp(`^(${regexpParts.join('|')})$`, 'i');

  // these headers may have been added after the original request by plugins downstream of
  // authPreprocessorHandlerPlugin, but also (may) need to be prefixed.
  const FA_VB_TRANSACTION_HEADERS = /^x-oracle.*/i;

  /**
   *
   */
  class HeaderUtils {
    //
    static needsPrefixForProxy(name, originalNames) {
      return (!PROXY_HEADER_EXCLUSION_REGEX.test(name)
        && (FA_VB_TRANSACTION_HEADERS.test(name) || originalNames.indexOf(name) >= 0));
    }

    /**
     * modifies headers names in the Request.
     * the caller should call needsPrefixForProxy() to call prefixHeaderForProxy conditionally.
     * @param request {Request} headers may be modified.
     * @param name {string} header name
     *
     * @returns {boolean} true if the header name was changed
     */
    static prefixHeaderForProxy(request, name) {
      const newName = `${Constants.HEADER_PROXY_HEADER_PREFIX}${name}`;
      const value = request.headers.get(name);
      request.headers.set(newName, value);
      request.headers.delete(name);
    }
  }

  // for tests
  HeaderUtils.browserSuppliedHeaders = browserSuppliedHeaders;


  return HeaderUtils;
});



define('vbsw/private/plugins/abstractAuthHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'vbc/private/constants'], (FetchHandlerPlugin, CommonConstants) => {
  const VB_PROXY = 'proxyUrl';
  const VB_PROXY_URLS = 'proxyUrls';
  const VB_TOKEN_RELAY_URLS = 'tokenRelayUrls';

  const VB_HTTPS_PREFIX = /^https/;

  /**
   * Abstract Handler plugin interpreting the authentication configuration so it can be shared between the
   * DT and the RT, a sublcass is required for all cases.
   */
  class AbstractAuthHandlerPlugin extends FetchHandlerPlugin {
    /**
     * @param request the request which is being modified
     * @return The string key to look up the correct proxy or tokenRelay URL, which might be either
     *  static of dynamic depending on whether this is invoke from the RT or DT.
     */
    // eslint-disable-next-line no-unused-vars,class-methods-use-this
    deriveUrlKey(request) {
      throw new Error('Should be implemented by specific subclass');
    }

    /**
     * Interpret the authentication configuration
     *
     * @param request the request to which to modify
     * @returns {Promise}
     */
    handleRequestHook(request) {
      return Promise.resolve().then(() => {
        // get the url for the token relay service from the request header,
        // bail if nothing found
        const infoExtension = JSON.parse(request.headers.get(CommonConstants.Headers.VB_INFO_EXTENSION));
        if (!infoExtension) {
          return request;
        }

        const protocol = request.headers.get(CommonConstants.Headers.PROTOCOL_OVERRIDE_HEADER);

        // Process token relay if required
        //
        const tokenRelayUrls = infoExtension[VB_TOKEN_RELAY_URLS];
        let tokenRelayUrl;
        if (tokenRelayUrls) {
          tokenRelayUrl = tokenRelayUrls[this.deriveUrlKey(request)];
        }

        // Process proxy if avaliable
        //
        const proxyUrls = infoExtension[VB_PROXY_URLS];
        let proxyUrl = proxyUrls && proxyUrls[this.deriveUrlKey(request)];
        if (!proxyUrl) {
          // Legacy fallback
          proxyUrl = infoExtension[VB_PROXY];
        }


        const inheritAuthentication = infoExtension[CommonConstants.Headers.INHERIT];
        const authentication = infoExtension[CommonConstants.Headers.VB_DT_AUTHENTICATION];

        // implicit flow is disabled if inherit is set to false in dt-serviceAuthentication
        // the by DT extension in getServiceExtensionOverride
        const inheritDisabled = authentication && authentication.inherit === false;


        if (inheritAuthentication && !inheritDisabled) {
          // To allow BUFP-23476 only do implicit flow if not overridden by service connection
          // authentication and not authentication header has already been set.
          request.headers.set('vb-inherit-authentication', 'not-handled');

          // If a fallback is provided write that down
          if (proxyUrl) {
            request.headers.set('vb-inherit-authentication-fallback', proxyUrl);
          }
        } else if (tokenRelayUrl) {
          request.headers.set('vb-token-relay-url', tokenRelayUrl);
          // Provide override for manual configuration of authentication
          if (authentication) {
            request.headers.set('vb-token-relay-authentication', JSON.stringify(authentication));
          }
        } else if (proxyUrl) {
          const proxyPrefix = proxyUrl.endsWith('/') ?
            proxyUrl.substring(0, proxyUrl.length - 1) :
            proxyUrl;

          let suffix = request.url.replace(':/', '');
          if (protocol) {
            suffix = suffix.replace(VB_HTTPS_PREFIX, protocol);
          }

          console.log('Before fetch handler plugin');

          return FetchHandlerPlugin.getRequestConfig(request, this.fetchHandler).then((config) => {
            const newRequest = this.fetchHandler.createRequest(`${proxyPrefix}/${suffix}`, config);

            // If this is a DT request we might be overriding the headers

            if (authentication && authentication.type !== 'direct') {
              newRequest.headers.set('Breeze-Design-Whitelist', 'true');

              Object.entries(authentication).reduce(
                (headers, [key, value]) => {
                  headers.set(`Breeze-${key}`, value);
                  return headers;
                }, newRequest.headers);
            }

            return newRequest;
          });
        } else {
          // GNDN Direct
        }

        return request;
      });
    }
  }


  return AbstractAuthHandlerPlugin;
});



define(
  'vbsw/private/plugins/anonymousAuthHandlerPlugin',
  [
    'vbsw/private/plugins/abstractAuthHandlerPlugin',
  ], (AbstractAuthHandlerPlugin) => {


  /**
   * Authentication handler for anonymous users
   */
  class AnonymousAuthHandlerPlugin extends AbstractAuthHandlerPlugin {
    deriveUrlKey(request) {
      return 'anonymous';
    }
  }

  return AnonymousAuthHandlerPlugin;
});



define(
  'vbsw/private/plugins/authenticatedAuthHandlerPlugin',
  [
    'vbsw/private/plugins/abstractAuthHandlerPlugin',
  ], (AbstractAuthHandlerPlugin) => {


  /**
   * Authentication handler for logged in users
   */
  class AuthenticatedAuthHandlerPlugin extends AbstractAuthHandlerPlugin {
    deriveUrlKey(request) {
      return 'authenticated';
    }
  }

  return AuthenticatedAuthHandlerPlugin;
});



define('vbsw/private/plugins/authHeaderHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'urijs/URI'],
  (FetchHandlerPlugin, URI) => {
    // version string can match anything except '/', to allow matrix parameters
    const REGEX = /\/ic\/builder\/(design|deployment|rt)\/[^\/]+\/[^\/]*(\/resources\/(data(mgr)?|vbprocess)|(\/resources)?\/services)(\/.+)?/;

    /**
     * Handler plugin for appending Authorizaton:Session|Public header.
     */
    class AuthHeaderHandlerPlugin extends FetchHandlerPlugin {
      constructor(context, params = {}) {
        super(context, params);

        // the Authorization:Session header will never be added for mobile since this plugin is
        // only installed when isAnonymous is true
        this.authType = params.isAnonymous ? 'Public' : 'Session';
        this.regex = params.regex ? new RegExp(params.regex) : REGEX;
      }

      /**
       * Append the Authorization:Session|Public header.
       *
       * @param request the request to which to append the header
       */
      handleRequestHook(request) {
        // only add the header for url matching the following pattern
        let isMatch = request.url.match(this.regex);

        // in IE11, the path comes through with the service double-dots, and flunks the regex
        if (!isMatch && request.url.indexOf('../') >= 0) {
          const altUrl = new URI(request.url).normalize().toString();
          isMatch = altUrl.match(this.regex);
        }

        if (isMatch) {
          request.headers.set('Authorization', this.authType);
        }

        return Promise.resolve();
      }
    }

    return AuthHeaderHandlerPlugin;
  });




define('vbsw/private/plugins/authPostprocessorHandlerPlugin',[
  'vbsw/api/fetchHandlerPlugin',
  'vbsw/private/constants',
  'vbsw/private/headerUtils',
], (FetchHandlerPlugin, Constants, HeaderUtils) => {
  /**
   * Handler plugin for removing headers added by AuthPreprocessorHandlerPlugin.
   */
  class AuthPostprocessorHandlerPlugin extends FetchHandlerPlugin {
    /**
     * Remove intra plugin headers, to prevent CORS issues later.
     *
     * May also prefix headers, when using the newer VB proxy:
     * Here is an example URL, prefixed with the "1.1" proxy:
     */
    // eslint-disable-next-line max-len
    // https://<vb host>/ic/builder/design/MyAppName/1.0;profile=base_configuration/services/auth/1.1/proxy/postmanEchoCom/uri/https/postman-echo.com/post

    handleRequestHook(request) {
      const headersToDelete = [];
      const headersToPrefix = [];

      // if this is present, we need to transform certain header names so the V1.1 VB Proxy will pass them along.
      const nameStr = request.headers.get(Constants.PROXY_HEADERNAME_HEADER);
      let originalHeaderNamesForNewProxy;
      try {
        originalHeaderNamesForNewProxy = nameStr ? JSON.parse(nameStr).map((name) => name.toLowerCase()) : null;
      } catch (e) {
        console.error('Error parsing value for internal header', Constants.PROXY_HEADERNAME_HEADER, e);
      }

      // On Firefox and IE, deleting the headers while iterating messes up the iterator. Work around
      // the issue by using an array, headersToDelete, to keep track of headers to delete.
      for (const header of request.headers.keys()) {
        // if we are using the V1.1+ VB proxy, we may need to change the header name
        if (originalHeaderNamesForNewProxy && HeaderUtils.needsPrefixForProxy(header, originalHeaderNamesForNewProxy)) {
          headersToPrefix.push(header);
        } else if (AuthPostprocessorHandlerPlugin.VB_HEADER_REGEX.test(header)
          && !header.startsWith(Constants.HEADER_PROXY_PREFIX)) {
          // delete all "vb-*", except for "vb-proxy-*"
          headersToDelete.push(header);
        }
      }

      headersToPrefix.forEach((header) => {
        HeaderUtils.prefixHeaderForProxy(request, header);
      });

      headersToDelete.forEach((header) => {
        request.headers.delete(header);
      });

      return Promise.resolve();
    }
  }

  // static member, for unit tests
  AuthPostprocessorHandlerPlugin.VB_HEADER_REGEX = /^vb-.*/;

  return AuthPostprocessorHandlerPlugin;
});



define('vbsw/private/plugins/authPreprocessorHandlerPlugin',[
  'vbsw/api/fetchHandlerPlugin',
  'vbsw/private/constants',
  'vbc/private/constants',
  'vbc/private/log',
  'vbsw/private/utils',
], (FetchHandlerPlugin, Constants, CommonConstants, Log, SWUtils) => {
  // constants for legacy syntax
  const VB_PROXY_URLS = 'proxyUrls';
  const VB_PROXY_URL = 'proxyUrl';
  const VB_TOKEN_RELAY_URLS = 'tokenRelayUrls';

  const VB_HTTPS_PREFIX = /^https/;

  // constants for new syntax
  const VB_PROPAGATE = 'propagate';
  const VB_AS_AUTHENTICATED_USER = 'as_authenticated_user';

  const logger = Log.getLogger('/vbsw/private/plugins/authPreprocessorHandlerPlugin');

  // supported forceProxy values
  const ForceProxy = {
    ALWAYS: 'always',
    CORS: 'cors',
  };

  // authenticated types that support token relay
  const VB_TOKEN_RELAY_TYPES = ['cloud', 'oauth2_client_credentials', 'oauth2_user_assertion', 'oauth2_resource_owner'];

  // list of auth types that will set forceProxy = true;
  const MUST_FORCE_PROXY = [Constants.AuthenticationType.BASIC, Constants.AuthenticationType.HTTP_SIGNATURE_OCI];

  // authenticated types that will always use the proxy if forceProxy is always - used for tests only!!
  const VB_ALWAYS_PROXY_TYPES = VB_TOKEN_RELAY_TYPES.concat(MUST_FORCE_PROXY);

  // default headers automatically added by the browser and used by the url mapper to skip existing
  // header check
  // TODO: only check for accept header for now and may add more in the future
  const DEFAULT_HEADERS = {
    accept: '*/*',
  };

  /**
   * This class is used to pre-process the security configuration and determine the authentication type
   * and add appropriate headers to the request so it can be properly handled by the downstream plugins.
   */
  class AuthPreprocessorHandlerPlugin extends FetchHandlerPlugin {
    constructor(context, params = {}) {
      super(context, params);

      this.defaultAuthentication = params.defaultAuthentication || {};

      // it can either be an explicit parameter, or come from "initParams".
      const userConfig = (context.fetchHandler.config && context.fetchHandler.config.userConfig);
      this.passthroughs = params.passthroughs
        || (userConfig && userConfig.configuration && userConfig.configuration.passthroughs) || [];

      // determine the default authentication type which can be inherited, defaults to oraclecloud
      // Note: The auth type is set to none by DT if nothing is selected so we'll default it to oraclecloud here.
      this.defaultAuthenticationType = this.defaultAuthentication.type;
      if (!this.defaultAuthenticationType || this.defaultAuthenticationType === Constants.AuthenticationType.NONE) {
        this.defaultAuthenticationType = Constants.AuthenticationType.ORACLE_CLOUD;
      }

      // indicate whether we are anonymous or authenticated
      this.isAnonymous = params.isAnonymous;

      // used to reverse-map URLs to 'vb-init-extension' information
      this.urlMapperClient = this.fetchHandler && this.fetchHandler.urlMapperClient;
    }

    // the following static getters are used by unit tests
    static get forceProxy() {
      return ForceProxy;
    }

    static get tokenRelayTypes() {
      return VB_TOKEN_RELAY_TYPES;
    }

    static get alwaysProxyTypes() {
      return VB_ALWAYS_PROXY_TYPES;
    }

    /**
     * Returns the url key based on the isAnonymous flag.
     *
     * NOTE: The request parameter is used by DT to inject additional behaviors in the service endpoint
     * tester. This will be removed in 19.4.1 when we switch to using the service endpoint test utility
     * we plan to implement.
     *
     * @param isAnonymous true if the request is anonymous, false otherwise
     * @param request used by DT to inject additional behaviors
     * @returns {string}
     */
    // eslint-disable-next-line class-methods-use-this,no-unused-vars
    getUrlKey(isAnonymous, request) {
      return isAnonymous ? 'anonymous' : 'authenticated';
    }


    /**
     * Extract the token relay url from the given request.
     *
     * @param request the request to extract the token relay url
     * @returns {string|null}
     */
    static getTokenRelayUrlFromRequest(request) {
      const infoExtensionHeader = request.headers.get(CommonConstants.Headers.VB_INFO_EXTENSION);

      if (infoExtensionHeader) {
        const infoExtension = JSON.parse(infoExtensionHeader);

        if (infoExtension.baseUrl && infoExtension.serviceName) {
          return SWUtils.getTokenRelayUrl(infoExtension.baseUrl, infoExtension.serviceName);
        }
      }

      return null;
    }

    /**
     * Returns true if CORS is enforced, i.e., by the web browser.
     *
     * @returns {boolean}
     */
    // eslint-disable-next-line class-methods-use-this
    enforceCORS() {
      return true;
    }

    /**
     * check if we need to use the proxy for http
     * @param request
     * @param infoExtension
     * @returns {boolean}
     */
    // eslint-disable-next-line class-methods-use-this
    useProxyForProtocol(request, infoExtension) {
      // the 'override' allows the request to reach the service worker, when its used;
      // normally 'http' would be blocked for an 'https' request, and wouldn't get this far.
      return request.headers.get(CommonConstants.Headers.PROTOCOL_OVERRIDE_HEADER)
        && (infoExtension.forceProxy === undefined || infoExtension.forceProxy === null);
    }

    /**
     * Return true if the given type is one of the supported token relay types.
     *
     * @param type type to check for token relay support
     * @returns {boolean}
     */
    // eslint-disable-next-line class-methods-use-this
    supportsTokenRelay(type) {
      return VB_TOKEN_RELAY_TYPES.indexOf(type) >= 0;
    }

    /**
     * Process the given x-vb info extension. It will directly interpret the new authentication block if
     * it exists. Otherwise, it will fall back to interpreting it using the legacy syntax.
     *
     * @param infoExtension the x-vb info extension to process
     * @param request used by DT to inject additional behaviors
     * @returns {*}
     */
    processInfoExtension(infoExtension, request) {
      const hasLegacyUrls =
        infoExtension[VB_PROXY_URL] || infoExtension[VB_PROXY_URLS] || infoExtension[VB_TOKEN_RELAY_URLS];

      const needsProxyForProtocol = this.useProxyForProtocol(request, infoExtension); // force http: through proxy

      // new info extension contains an authentication block
      if (!hasLegacyUrls
        && (infoExtension.forceProxy || infoExtension.authentication || needsProxyForProtocol)) {
        const inheritDisabled = this.isInheritDisabledForDT(infoExtension);

        let authenticationType = Constants.AuthenticationType.DIRECT;
        let proxyUrl;
        let tokenRelayUrl;

        const urlKey = this.getUrlKey(this.isAnonymous, request);
        if (urlKey === 'anonymous' && infoExtension.anonymousAccess !== true) {
          // no authentication, proxy or tokenRelay allowed for anonymous user
          return { authenticationType };
        }

        let authentication;
        if (infoExtension.authentication) {
          authentication = infoExtension.authentication[urlKey];

          // once we have the proper authentication block, check if this auth type is one of the ones we should
          // skip, to allow non-VB plugins to process, unmodified
          if (this.isPassthrough(authentication)) {
            return {
              passthroughProperties: Object.assign({}, authentication),
            };
          }

          // if authentication is as_authenticated_user, use authenticated block instead
          if (authentication && authentication.type === VB_AS_AUTHENTICATED_USER) {
            authentication = infoExtension.authentication.authenticated;
          }

          // for 'basic' OR 'http_signature_oci' auth type, forceProxy should be always
          if (authentication && MUST_FORCE_PROXY.indexOf(authentication.type) >= 0) {
            infoExtension.forceProxy = ForceProxy.ALWAYS;
          }

          if (authentication && authentication.type === VB_PROPAGATE) {
            authenticationType = this.defaultAuthenticationType;

            // the following inherited authentication types don't require proxy regardless of
            // the value of forceProxy, so we simply return the authentication type
            if ((authenticationType === Constants.AuthenticationType.BASIC
              || (authenticationType === Constants.AuthenticationType.IMPLICIT && !inheritDisabled)
              || authenticationType === Constants.AuthenticationType.OAUTH) && !this.isAnonymous) {
              return { authenticationType };
            }
          }
        }

        // for BUFP-41808; when we are using 'implicit', and the in-page DT preview says to disable it, use proxy

        if (authenticationType === Constants.AuthenticationType.ORACLE_CLOUD
          || infoExtension.forceProxy === ForceProxy.ALWAYS
          || (inheritDisabled && authenticationType === Constants.AuthenticationType.IMPLICIT) // see BUFP-41808 above
          || (infoExtension.forceProxy === ForceProxy.CORS && this.enforceCORS())
          || needsProxyForProtocol) {
          authenticationType = Constants.AuthenticationType.ORACLE_CLOUD;
          proxyUrl = SWUtils.getProxyUrl(infoExtension.baseUrl, infoExtension.serviceName);
        } else if ((infoExtension.forceProxy === ForceProxy.CORS || !infoExtension.forceProxy)
          && (authentication && this.supportsTokenRelay(authentication.type))) {
          authenticationType = Constants.AuthenticationType.TOKEN_RELAY;
          tokenRelayUrl = SWUtils.getTokenRelayUrl(infoExtension.baseUrl, infoExtension.serviceName);
        } else {
          authenticationType = Constants.AuthenticationType.DIRECT;
        }

        return {
          authenticationType,
          proxyUrl,
          tokenRelayUrl,
          authentication,
          isLegacy: false,
          passthroughProperties: null,
        };
      }

      // fall back to processing legacy info extension
      return this.processLegacyInfoExtension(infoExtension, request);
    }

    /**
     * Process the given x-vb info extension using the legacy syntax.
     *
     * @param infoExtension the x-vb info extension to process
     * @param request used by DT to inject additional behaviors
     * @returns {{authenticationType: (string|*), proxyUrl: *, tokenRelayUrl: *, authentication: *}}
     */
    processLegacyInfoExtension(infoExtension, request) {
      // inherit can be disabled by setting inherit in dt-serviceAuthentication via DT extension
      // in getServiceExtensionOverride
      const authentication = infoExtension[CommonConstants.Headers.VB_DT_AUTHENTICATION];
      const inheritDisabled = this.isInheritDisabledForDT(infoExtension);

      // determine if we are inheriting the default authentication
      const inheritAuthentication = infoExtension[CommonConstants.Headers.INHERIT] && !inheritDisabled;

      // determine the authentication type and whether anonymous access is allowed
      // Note: authenticationType is hard-coded to oraclecloud for BOs without inherit and proxy and
      // we simply pick it up here
      let authenticationType = infoExtension.authenticationType;

      if (inheritAuthentication) {
        authenticationType = this.defaultAuthenticationType;
      }

      // process proxy and token relay urls
      const proxyUrls = infoExtension[VB_PROXY_URLS] || {};
      const tokenRelayUrls = infoExtension[VB_TOKEN_RELAY_URLS] || {};
      let proxyUrl;
      let tokenRelayUrl;
      let urlKey;

      if (inheritAuthentication && this.isAnonymous) {
        // if we are anonymous, check to see if an anonymous token relay url or proxy url is provided to override
        // the default authentication type
        urlKey = this.getUrlKey(true, request);
        proxyUrl = proxyUrls[urlKey];
        tokenRelayUrl = tokenRelayUrls[urlKey];

        if (tokenRelayUrl) {
          // use the token relay url to handle anonymous access
          authenticationType = Constants.AuthenticationType.TOKEN_RELAY;
        } else if (proxyUrl) {
          // use the proxy to handle anonymous access
          authenticationType = Constants.AuthenticationType.ORACLE_CLOUD;
        } else {
          // don't know how to handle anonymous access, set auth type to direct and let the request fail
          // if no explicit auth header is provided
          authenticationType = Constants.AuthenticationType.DIRECT;
        }
      } else {
        urlKey = this.getUrlKey(this.isAnonymous, request);
        proxyUrl = proxyUrls[urlKey];
        tokenRelayUrl = tokenRelayUrls[urlKey];
      }

      // support for legacy syntax
      if (!proxyUrl) {
        proxyUrl = infoExtension[VB_PROXY_URL];
      }

      // if we are not inheriting from the default authentication, determine the type based on the
      // tokenRelayUrl, proxyUrl, etc
      if (!authenticationType) {
        if (tokenRelayUrl) {
          authenticationType = Constants.AuthenticationType.TOKEN_RELAY;
        } else if (proxyUrl) {
          authenticationType = Constants.AuthenticationType.ORACLE_CLOUD;
        } else {
          authenticationType = Constants.AuthenticationType.DIRECT;
        }
      }

      return {
        authenticationType,
        proxyUrl,
        tokenRelayUrl,
        authentication,
        isLegacy: true,
      };
    }

    /**
     * 'implicit flow' should be disabled if inherit is set to false in dt-serviceAuthentication
     * the by DT extension in getServiceExtensionOverride
     *
     * inherit can be disabled by setting inherit in dt-serviceAuthentication via DT extension
     * in getServiceExtensionOverride.
     *
     * Also see abstractAuthHandlerPlugin.
     *
     * @param infoExtension
     */
    // eslint-disable-next-line class-methods-use-this
    isInheritDisabledForDT(infoExtension) {
      const dtAuthentication = infoExtension[CommonConstants.Headers.VB_DT_AUTHENTICATION];
      return dtAuthentication && dtAuthentication.inherit === false;
    }

    /**
     * is the 'type' one of the ones configured for passthrough?
     *
     * an application might typically configure this in index.html:
     * <script>
     *  window.vbInitParams = window.vbInitParams || {};
     *  window.vbInitParams[‘services.security.handlers.passthroughs’] = [‘propagate’];
     * </script>
     *
     * OR in app-flow.json
     *
     * "configuration": {
     *   "initParams": {
     *     "services.security.handlers.passthroughs": ["propagate"]
     *   }
     * }
     *
     * @param authentication
     * @returns {*|boolean}
     */
    isPassthrough(authentication) {
      return authentication && this.passthroughs.indexOf(authentication.type) >= 0;
    }

    /**
     * Interpret the authentication configuration
     *
     * @param request the request to which to modify
     * @param client
     * @returns {Promise}
     */
    handleRequestHook(request, client) {
      return Promise.resolve()
        .then(() => {
          // first check if the request came from VB; all data requests have this header when sent from main thread.
          const infoExtensionHeader = request.headers.get(CommonConstants.Headers.VB_INFO_EXTENSION);
          // if the header is not set (should return null, but check for undefined just in case)
          if (infoExtensionHeader === null || infoExtensionHeader === undefined) {
            return this.getExtensionFromMapping(request, client);
          }
          return JSON.parse(infoExtensionHeader);
        })
        .then((infoExtension) => {
          // bail if nothing found
          if (!infoExtension) {
            return request;
          }

          const {
            authenticationType,
            proxyUrl,
            tokenRelayUrl,
            authentication,
            isLegacy,
            passthroughProperties,
          } = this.processInfoExtension(infoExtension, request);

          // if passthrough, copy auth values to simple headers, and exit; don't interpret
          if (passthroughProperties) {
            return this.setPassthroughHeaders(request, passthroughProperties);
          }

          // get the list of header names before we start adding headers
          const headersBeforeProcessing = [];
          if (!isLegacy && authenticationType === Constants.AuthenticationType.ORACLE_CLOUD && proxyUrl) {
            for (const name of request.headers.keys()) {
              headersBeforeProcessing.push(name);
            }
          }

          // set the authentication type header on the request so it can be processed by the corresponding plugin
          request.headers.set(Constants.AUTHENTICATION_TYPE_HEADER, authenticationType);

          if (authenticationType === Constants.AuthenticationType.TOKEN_RELAY) {
            request.headers.set(Constants.TOKEN_RELAY_URL_HEADER, tokenRelayUrl);

            // Provide override for manual configuration of authentication
            if (authentication) {
              request.headers.set(Constants.TOKEN_RELAY_AUTH_HEADER, JSON.stringify(authentication));
            }
          } else if (authenticationType === Constants.AuthenticationType.ORACLE_CLOUD && proxyUrl) {
            // create a new proxied version of the request
            const proxyPrefix = proxyUrl.endsWith('/') ?
              proxyUrl.substring(0, proxyUrl.length - 1) :
              proxyUrl;

            let suffix = request.url.replace(':/', '');
            const protocol = request.headers.get(CommonConstants.Headers.PROTOCOL_OVERRIDE_HEADER);
            if (protocol) {
              suffix = suffix.replace(VB_HTTPS_PREFIX, protocol);
            }

            return FetchHandlerPlugin.getRequestConfig(request, this.fetchHandler).then((config) => {
              // prefix headers that the proxy should pass along
              if (!isLegacy) {
                // only do this for the new proxy
                AuthPreprocessorHandlerPlugin.addPostProcessingHeader(config, headersBeforeProcessing);
              }

              return this.fetchHandler.createRequest(`${proxyPrefix}/${suffix}`, config);
            });
          }

          return request;
        });
    }

    /**
     * set a header with JSON string with the current "authentication" block properties
     * @param request
     * @param properties
     * @returns {*}
     */
    // eslint-disable-next-line class-methods-use-this
    setPassthroughHeaders(request, properties) {
      if (properties) {
        request.headers.set(Constants.HEADER_PASSTHROUGH, JSON.stringify(properties));
      }
      return request;
    }


    /**
     * delegate to the UrlMapperClient to look up addition URL config.
     * this also adds the 'vb-info-extension' to the request
     * @param request
     * @param client
     * @returns {Promise(<string>)} the value of the vb-info-extensions header form the mapping, if any
     */
    getExtensionFromMapping(request, client) {
      return this.urlMapperClient ? this.urlMapperClient.getMapping(request, client)
        .then((mapping) => {
          if (mapping) {
            this.applyMapping(request, mapping);
          }
          return mapping;
        }) : Promise.resolve(null);
    }

    /**
     * add headers from the mapping to the request, but do not overwrite existing headers.
     *
     * the mapping object is
     * {
     *   headers: <Object>,orkwe
     *   serviceName: <string>,
     *   baseUrl: <string>
     * }
     *
     * this will add all the headers, and a special 'vb-info-extension ' header,
     * which is a string-ified version of this structure
     *
     * @param request the headers will be modified if there is a mapping
     * @param mapping if null, simply returns the request
     * @returns {Request}
     * @private
     */
    // eslint-disable-next-line class-methods-use-this
    applyMapping(request, mapping) {
      if (mapping) {
        const mappingStr = JSON.stringify(mapping);

        logger.info('UrlMapper found mapping for: ', request.url, mappingStr);

        // only add headers that don't already exist except for default headers added by
        // the browser when running on the service worker
        Object.keys(mapping.headers).forEach((header) => {
          const existing = request.headers.get(header);
          // should return null for headers that aren't set, but check for undefined just in case
          if (existing === null || existing === undefined
            || (DEFAULT_HEADERS[header.toLowerCase()] === existing && SWUtils.isWorkerThread())) {
            request.headers.set(header, mapping.headers[header]);
          }
        });

        // and add the vb-info-header extension
        request.headers.set(CommonConstants.Headers.VB_INFO_EXTENSION, mappingStr);
      }
      // return the (original, possibly modified) Request
      return request;
    }


    /**
     * this is used by the authPostProcessorHandlerPLugin
     *
     * the PRESENCE of the header means we are using the new 1.1 proxy, and need to prefix certain headers.
     * the VALUE of the header is a list of original header names, before we add other plugins-specific headers.
     * (note, other plugins may add other headers later)
     *
     * @param config
     * @param headersBeforeProcessing
     */
    static addPostProcessingHeader(c, headersBeforeProcessing) {
      const config = c; // avoiding lint error
      config.headers[Constants.PROXY_HEADERNAME_HEADER] = JSON.stringify(headersBeforeProcessing || []);
    }
  }

  return AuthPreprocessorHandlerPlugin;
});



define('vbsw/private/plugins/authPublicHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'urijs/URI'], (FetchHandlerPlugin, URI) => {
  // regular expressions for DT and RT
  const DT_REGEX = /\/ic\/builder\/(design|deployment)\/[\w\d]+\/(((\d+\.)+\d+)|(\d+))\/resources\/(data(mgr)?|vbprocess)(\/.+)?/; // eslint-disable-line max-len
  const RT_REGEX =
    /\/ic\/builder\/rt\/[\w\d]+\/(((\d+\.)+\d+)|(\d+)|(live))(\/resources\/(data|vbprocess)|(\/resources)?\/services)(\/.+)?/; // eslint-disable-line max-len

  /**
   * Handler plugin for appending Authorizaton:Public header.
   */
  class AuthPublicHandlerPlugin extends FetchHandlerPlugin {
    /**
     * Append the Authorization:Public header.
     *
     * @param request the request to which to append the header
     */
    handleRequestHook(request) {
      // only add the header for url matching the following patterns
      let isMatch = request.url.match(RT_REGEX) || request.url.match(DT_REGEX);

      // in IE11, the path comes through with the service double-dots, and flunks the regex
      if (!isMatch && request.url.indexOf('../') >= 0) {
        const altUrl = new URI(request.url).normalize().toString();
        isMatch = altUrl.match(RT_REGEX) || altUrl.match(DT_REGEX);
      }

      if (isMatch) {
        request.headers.set('Authorization', 'Public');
      }

      return Promise.resolve();
    }
  }

  return AuthPublicHandlerPlugin;
});




define('vbsw/private/plugins/authSessionHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'urijs/URI'], (FetchHandlerPlugin, URI) => {
  // regular expressions for DT and RT
  const DT_REGEX = /\/ic\/builder\/(design|deployment)\/[\w\d]+\/(((\d+\.)+\d+)|(\d+))\/resources\/(data(mgr)?|vbprocess)(\/.+)?/; // eslint-disable-line max-len
  const RT_REGEX =
    /\/ic\/builder\/rt\/[\w\d]+\/(((\d+\.)+\d+)|(\d+)|(live))(\/resources\/(data|vbprocess)|(\/resources)?\/services)(\/.+)?/; // eslint-disable-line max-len

  /**
   * Handler plugin for appending Authorizaton:Session header.
   */
  class AuthSessionHandlerPlugin extends FetchHandlerPlugin {
    /**
     * Append the Authorization:Session header.
     *
     * @param request the request to which to append the header
     */
    handleRequestHook(request) {
      // only add the header for url matching the following patterns
      let isMatch = request.url.match(RT_REGEX) || request.url.match(DT_REGEX);

      // in IE11, the path comes through with the service double-dots, and flunks the regex
      if (!isMatch && request.url.indexOf('../') >= 0) {
        const altUrl = new URI(request.url).normalize().toString();
        isMatch = altUrl.match(RT_REGEX) || altUrl.match(DT_REGEX);
      }

      if (isMatch) {
        request.headers.set('Authorization', 'Session');
      }

      return Promise.resolve();
    }
  }

  return AuthSessionHandlerPlugin;
});




define('vbsw/private/plugins/csrfTokenHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'vbsw/private/utils'], (FetchHandlerPlugin, Utils) => {
  const CSRF_TOKEN_HEADER_NAME = 'X-appbuilder-client-id';
  const INVALID_CSRF_TOKEN_HEADER_NAME = 'X-invalid-appbuilder-client-id';


  /**
   * Handler plugin for handling CSRF tokens.
   */
  class CsrfTokenHandlerPlugin extends FetchHandlerPlugin {
    constructor(context, params = {}) {
      super(context);
      this.vbCsrfToken = params.csrfToken;

      // eslint-disable-next-line max-len
      const reg = (params && params.regex) ? params.regex : Utils.getRegexForAppScope(this.fetchHandler.scope, this.fetchHandler.config);

      this.scopeRegEx = new RegExp(reg);

      // used to skip requests containing base url token since their responses can be cached by the browser
      // and we don't want to be using the CSRF tokens from these cached responses since they can be stale
      this.versionIdRegEx = params.versionId ? new RegExp(params.versionId) : null;
    }

    // used by unit tests
    static get csrfTokenHeader() { return CSRF_TOKEN_HEADER_NAME; }
    static get invalidCsrfTokenHeader() { return INVALID_CSRF_TOKEN_HEADER_NAME; }

    /**
     * Get the CSRF token.
     *
     * @returns {Promise<String>}
     */
    getCsrfToken() {
      // first try loading the token from the cache
      if (!this.vbCsrfToken) {
        return this.stateCache.get(CSRF_TOKEN_HEADER_NAME).then((token) => {
          this.vbCsrfToken = token;
          return token;
        });
      }

      return Promise.resolve(this.vbCsrfToken);
    }

    /**
     * Refresh the CSRF token from a response.
     *
     * @param response the response from which to get the latest CSRF token
     * @returns {Promise}
     */
    refreshCsrfToken(response) {
      const headers = response.headers;
      const token = headers.get(CSRF_TOKEN_HEADER_NAME);

      if (token && token !== this.vbCsrfToken) {
        this.vbCsrfToken = token;

        // cache the token
        return this.stateCache.put(CSRF_TOKEN_HEADER_NAME, token);
      }

      return Promise.resolve();
    }

    /**
     * Append the CSRF token to the header.
     *
     * @param request the request to which to append the CSRF token
     * @returns {Promise}
     */
    handleRequestHook(request) {
      // only append the CSRF token if the request url matches the scope
      if (request.url.match(this.scopeRegEx)
        && (this.versionIdRegEx ? !request.url.match(this.versionIdRegEx) : true)) {
        return this.getCsrfToken()
          .then((token) => {
            request.headers.set(CSRF_TOKEN_HEADER_NAME, token);
          });
      }

      return Promise.resolve();
    }

    /**
     * Check the response if we need to refresh the CSRF token and retry the request if we have an invalid token.
     *
     * @param response the response to check for invalid CSRF token and get new token
     * @returns {Promise.<Boolean>}
     */
    handleResponseHook(response, origRequest, request) {
      // only check for 403 if the original request url matches the scope
      if (request.url.match(this.scopeRegEx)
        && (this.versionIdRegEx ? !request.url.match(this.versionIdRegEx) : true)) {
        if (response.status === 403 && response.headers.get(INVALID_CSRF_TOKEN_HEADER_NAME)) {
          // get the new CSRF token from the response and retry
          return this.refreshCsrfToken(response).then(() => true);
        }

        if (response.ok) {
          // refresh to keep the CSRF token up-to-date
          return this.refreshCsrfToken(response).then(() => false);
        }
      }

      return Promise.resolve(false);
    }
  }

  return CsrfTokenHandlerPlugin;
});



define(
  'vbsw/private/plugins/fallbackInheritedAuthHandlerPlugin',[
    'vbsw/private/plugins/abstractAuthHandlerPlugin',
    'vbc/private/constants',
  ], (AbstractAuthHandlerPlugin, CommonConstants) => {
    /**
     * Fall back if no other authentication method is avaliable
     */
    class fallbackInheritedAuthHandlerPlugin extends AbstractAuthHandlerPlugin {
      constructor(fetchHandler) {
        super(fetchHandler);
      }

      deriveUrlKey(request) {
        return 'authenticated';
      }

      handleRequestHook(request) {
        const inherit = request.headers.get('vb-inherit-authentication');
        if (inherit && inherit === 'not-handled') {

          const fallbackProxy =  request.headers.get('vb-inherit-authentication-fallback');
          if (fallbackProxy) {
            // Overwrite vb-info-extension header
            // in future where I have more time properly refactor this code.
            request.headers.set(CommonConstants.Headers.VB_INFO_EXTENSION, JSON.stringify({
              proxyUrls: {
                authenticated: fallbackProxy
              },
            }));
            // Prevent cross posting
            request.headers.delete(CommonConstants.Headers.PROTOCOL_OVERRIDE_HEADER);

            return super.handleRequestHook(request);
          }
        }

        return Promise.resolve();
      }
    }

    return fallbackInheritedAuthHandlerPlugin;
  });



define('vbsw/private/plugins/generalHeadersHandlerPlugin',['vbsw/api/fetchHandlerPlugin'], (FetchHandlerPlugin) => {
  /**
   * Handler plugin for adding general headers such as Accept-Language, etc.
   */
  class GeneralHeadersHandlerPlugin extends FetchHandlerPlugin {
    /**
     * Constructor
     *
     * @param context the context for the plugin
     * @param headers an object containing all the headers to be appended to the request
     */
    constructor(context, headers) {
      super(context);
      this.headers = headers || {};
    }

    handleRequestHook(request) {
      Object.keys(this.headers).forEach((key) => {
        // BUFP-31175: don't replace headers that exist in the request
        if (!request.headers.get(key)) {
          request.headers.set(key, this.headers[key]);
        }
      });

      return Promise.resolve();
    }
  }

  return GeneralHeadersHandlerPlugin;
});



define('vbsw/private/plugins/headerTidyHandlerPlugin',['vbsw/api/fetchHandlerPlugin'], (FetchHandlerPlugin) => {

    const HEADERS = /^vb-.*/;

    /**
     * Handler plugin for tidying up headers.
     */
    class HeaderTidyHandlerPlugin extends FetchHandlerPlugin {


      /**
       * Remove intra plugin headers, to prevent COORS issues later
       */
      handleRequestHook(request) {
        const headersToDelete = [];

        // On Firefox and IE, deleting the headers while iterating messes up the iterator. Work around
        // the issue by using an array, headersToDelete, to keep track of headers to delete.
        for (const header of request.headers.keys()) {
          // delete all "vb-*", except for "vb-proxy-*"
          if (HEADERS.test(header) && !header.startsWith(Constants.HEADER_PROXY_PREFIX)) {
            headersToDelete.push(header);
          }
        }

        headersToDelete.forEach((header) => {
          request.headers.delete(header);
        });

        return Promise.resolve();
      }
    }

    return HeaderTidyHandlerPlugin;
  });



define('vbsw/private/plugins/implicitFlowHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'vbsw/private/utils', 'vbsw/private/constants'],
  (FetchHandlerPlugin, Utils, Constants) => {
    const IMPLICIT_FLOW_CACHED_TOKEN = 'vbImplicitFlowCachedToken';

    // skew tolerance for the token expiration time
    const SKEW_TOLERANCE = 100;

    /**
     * Handler plugin for handling implicit grant flow.
     */
    class ImplicitFlowHandlerPlugin extends FetchHandlerPlugin {
      /**
       * Constructor
       *
       * @param context the context for the plugin
       * @param params an object containing the access token and scope
       */
      constructor(context, params) {
        super(context);

        const allowedScopes = params.allowedScopes || [];

        this.allowedScopes = allowedScopes.map((allowedScope) => {
          // in a hybrid saas environment, the actual scope is appended after 'fqs://'
          const parts = allowedScope.split('fqs://');
          const host = parts[0];

          // if nothing comes after fqs://, simply use the host as the scope
          const scope = (parts.length > 1 && parts[1]) ? parts[1] : host;

          // make :443 port optional in matching
          const hostWithOptionalPort = host.replace(':443', '(:443)?');

          return {
            scope,
            regEx: new RegExp(hostWithOptionalPort, 'i'), // case-insensitive match
          };
        });

        // used to cached in-memory version of the token for each scope
        this.cachedTokenPromises = {};

        // used to keep track of which token is currently invalid
        this.invalidateTokenPromises = {};
      }

      // the following static getters are used by unit tests
      static get skewTolerance() {
        return SKEW_TOLERANCE;
      }

      /**
       * Get the authorization token header either from cache or from the client hosting the main application.
       *
       * @param client the client associated with the main application
       * @returns {Promise}
       */
      getAuthHeader(client, scope) {
        // cache the promise for getting the token so we don't make multiple calls to get the access token
        let cachedTokenPromise = this.cachedTokenPromises[scope];

        if (!cachedTokenPromise) {
          const cachedTokenUrl = ImplicitFlowHandlerPlugin.getCachedTokenUrl(scope);

          // first try retrieving the cached token from the state cache
          cachedTokenPromise = this.stateCache.get(cachedTokenUrl).then((cachedToken) => {
            if (cachedToken) {
              return cachedToken;
            }

            // post a message to the main application to get the access token
            const msg = {
              method: 'vbRefreshImplicitFlowAccessToken',
              args: [scope],
            };
            return Utils.postMessage(client, msg)
              .then(token => this.cacheAuthToken(cachedTokenUrl, token));
          }).catch((err) => {
            // log the error for debugging purpose
            console.log(err);

            // delete the promise if there's any error so we don't cache the failure state
            delete this.cachedTokenPromises[scope];
          });

          this.cachedTokenPromises[scope] = cachedTokenPromise;
        }

        return cachedTokenPromise.then((cachedToken) => {
          if (cachedToken) {
            if (Utils.checkJwtExpiration(cachedToken.expiration, SKEW_TOLERANCE)) {
              // the token has expired, refresh it
              return this.refreshAuthHeader(client, scope);
            }

            // return the actual token
            return cachedToken.token;
          }

          return null;
        });
      }

      /**
       * Invalidate and refresh the cached auth header.
       *
       * @param client the client associated with the main application
       * @returns {Promise.<Boolean>}
       */
      refreshAuthHeader(client, scope) {
        let invalidateTokenPromise = this.invalidateTokenPromises[scope];

        if (!invalidateTokenPromise) {
          const cachedTokenUrl = ImplicitFlowHandlerPlugin.getCachedTokenUrl(scope);

          invalidateTokenPromise = this.stateCache.delete(cachedTokenUrl).then(() => {
            delete this.cachedTokenPromises[scope];

            return this.getAuthHeader(client, scope).then((authHeader) => {
              delete this.invalidateTokenPromises[scope];

              return authHeader;
            });
          });

          this.invalidateTokenPromises[scope] = invalidateTokenPromise;
        }

        return invalidateTokenPromise;
      }

      /**
       * Match the given url to an allowed scope and return the matched scope.
       *
       * @param url the url to match
       * @returns {string}
       */
      matchScope(url) {
        const result = this.allowedScopes.find(scope => url.match(scope.regEx));
        return result ? result.scope : null;
      }

      /**
       * Return an URL for the given scope that can be used for caching the authorization header
       *
       * @param scope the scope for the authorization header
       * @returns {string}
       */
      static getCachedTokenUrl(scope) {
        return `${scope}${IMPLICIT_FLOW_CACHED_TOKEN}`;
      }

      /**
       * The cached token is a wrapped version of the JWT token containing the extracted expiration
       * time and calculated server skew. This method will return a promise that resolves to the
       * wrapped token.
       *
       * @param cacheTokenUrl the url used to cache the token
       * @param token the JWT token
       * @returns {Promise}
       */
      cacheAuthToken(cachedTokenUrl, token) {
        const expiration = Utils.extractJwtExpiration(token);
        const cachedToken = {
          token,
          expiration,
        };

        return this.stateCache.put(cachedTokenUrl, cachedToken).then(() => cachedToken);
      }

      handleRequestHook(request, client) {
        const authenticationType = request.headers.get(Constants.AUTHENTICATION_TYPE_HEADER);

        if (authenticationType === Constants.AuthenticationType.IMPLICIT) {
          const headers = request.headers;

          // look up the scope this request falls under
          const matchedScope = this.matchScope(request.url);

          if (matchedScope) {
            return this.getAuthHeader(client, matchedScope).then((authHeader) => {
              // BUFP-26511: use an alternate name for the authorization header if provided
              const altAuthHeaderName = headers.get(Constants.ALT_AUTHORIZATION_HEADER_NAME);
              const authHeaderName = altAuthHeaderName || 'Authorization';

              headers.set(authHeaderName, authHeader);
            });
          }
          // else do nothing and let it fail
        }

        return Promise.resolve();
      }
    }

    return ImplicitFlowHandlerPlugin;
  });



define('vbsw/private/plugins/mobileAuthPreprocessorHandlerPlugin',['vbsw/private/plugins/authPreprocessorHandlerPlugin'],
  (AuthPreprocessorHandlerPlugin) => {
    class MobileAuthProprocessHandlerPlugin extends AuthPreprocessorHandlerPlugin {
      constructor(context, params = {}) {
        super(context, params);
      }

      enforceCORS() {
        return false;
      }

      /**
       * check if we need to use the proxy for http
       * @param request
       * @param infoExtension
       * @returns {boolean|*}
       * @override
       */
      useProxyForProtocol(request, infoExtension) {
        // normally for web, we have to switch 'http' to 'https' so it can make it through to a service worker,
        // and we indicate the switch with a special header.
        //
        // for mobile, the override isn't necessary, so check for a normal 'http:' request.
        return request.url.startsWith('http:') || super.useProxyForProtocol(request, infoExtension);
      }

    }

    return MobileAuthProprocessHandlerPlugin;
  });



define('vbsw/private/plugins/multiTenantCsrfTokenHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'vbsw/private/constants'],
  (FetchHandlerPlugin, Constants) => {
    /**
     * Name of the request/response header that contains the CSRF token value.
     * @type {string}
     */
    const CSRF_TOKEN_HEADER_NAME = 'X-CSRF-TOKEN';

    /**
     * Handler plugin for handling CSRF tokens in multi-tenant environment, e.g. Visual Studio.
     */
    class MultiTenantCsrfTokenHandlerPlugin extends FetchHandlerPlugin {
      constructor(fetchHandler, params = {}) {
        super(fetchHandler);

        const { orgId, vbServer } = params;
        if (orgId && vbServer) {
          this.profileUrl = `${vbServer}/${orgId}/api2/profile`;
          this.vbServerRegEx = new RegExp(vbServer);
        } else {
          // organization id is not available - CSRF is turned off
          this.profileUrl = null;
          this.vbServerRegEx = null;
        }

        // if set to null, it means CSRF token is not available
        this.vbCsrfToken = undefined;
      }

      // used by unit tests
      static get csrfTokenHeader() { return CSRF_TOKEN_HEADER_NAME; }

      /**
       * Get the CSRF token.
       *
       * @returns {Promise}
       */
      getCsrfToken() {
        return Promise.resolve().then(() => {
          // only refersh the token if vbCsrfToken is undefined
          if (this.vbCsrfToken === undefined) {
            return this.refreshCsrfToken().then(() => this.vbCsrfToken);
          }

          return this.vbCsrfToken;
        });
      }

      /**
       * Refresh the CSRF token.
       *
       * @returns {Promise}
       */
      refreshCsrfToken() {
        return Promise.resolve().then(() => {
          if (this.profileUrl) {
            const options = {
              method: 'GET',
              credentials: 'same-origin',
              cache: 'no-cache',
              // add oracle cloud auth type header in case mobile plugin needs to handle this in the future
              headers: {
                [Constants.AUTHENTICATION_TYPE_HEADER]: Constants.AuthenticationType.ORACLE_CLOUD,
              },
            };
            const request = new Request(this.profileUrl, options);

            return this.fetchHandler.handleRequest(request).then((response) => {
              this.vbCsrfToken = response.headers.get(CSRF_TOKEN_HEADER_NAME);

              return this.vbCsrfToken;
            });
          }

          // CSRF token is not available
          return null;
        });
      }

      /**
       * Append the CSRF token to the header.
       *
       * @param request the request to which to append the CSRF token
       * @returns {Promise}
       */
      handleRequestHook(request) {
        return Promise.resolve().then(() => {
          // only append the CSRF token if the request url matches the scope
          if (request.method.toUpperCase() !== 'GET'
            && this.vbServerRegEx && request.url.match(this.vbServerRegEx)) {
            return this.getCsrfToken().then((token) => {
              if (token) {
                request.headers.set(CSRF_TOKEN_HEADER_NAME, token);
              }
            });
          }

          return undefined;
        });
      }

      /**
       * Check the response if we need to refresh the CSRF token and retry the request if we have an invalid token.
       *
       * @param response the response to check for invalid CSRF token and get new token
       * @param request
       * @returns {Promise}
       */
      handleResponseHook(response, request) {
        return Promise.resolve().then(() => {
          // only check for 403 if the original request url matches the vb server url
          if (response.status === 403 && request.method.toUpperCase() !== 'GET'
            && this.vbServerRegEx && request.url.match(this.vbServerRegEx)) {
            // refresh the CSRF token and retry
            return this.refreshCsrfToken().then(() => true);
          }

          return false;
        });
      }
    }

    return MultiTenantCsrfTokenHandlerPlugin;
  });



define('vbsw/private/plugins/resourceChangedPlugin',[
  'vbsw/api/fetchHandlerPlugin',
  'vbsw/private/utils',
  'vbc/private/log',
],
(FetchHandlerPlugin, Utils, Log) => {
  /**
   * Notes:
   *
   * this plugin is responsible for handling the requests and responses to the VB server,
   * making sure it has the required request header to identify the current client app version,
   * and checking if the server responds with a 400 and a header indicating that the app resources have changed.
   *
   * When this happens, a message is sent, with the url, error from the server, and the header value.
   */
  const logger = Log.getLogger('/vb/private/plugins/resourceChangedPlugin');

  // this is added to all requests to the VB server (if BASE_URL_TOKEN exists).
  const VB_VERSION_ID_HEADER = 'x-vb-application-version'; // can't use "vb-", tidy/authPostProcessorPlugin remove those

  // this will be in the response, if the app has been re-staged (boolean)
  const VB_CHANGED_HEADER = 'x-vb-changed-header';

  // BUFP-33076; when reloading a PWA that has been restaged, app-flow.json and app.css are requested by the
  // old service worker, and thus those have the old header value, and the app gets stuck, and the service worker never
  // gets updated. Skipping those files allows PWA to get the newer service worker and resources.
  const DEFAULT_SKIP_REGEX = /(app-flow.json|\.css)$/;

  class ResourceChangedPlugin extends FetchHandlerPlugin {
    constructor(context, params = {}) {
      super(context);
      this.contextRoot = params.contextRoot || '/';
      // if versionId is not truthy, this plugin will not do anything
      this.versionId = params.versionId;

      // allow for an override, but should never happen (and don't document)
      this.skipRegex = params.skipRegex || DEFAULT_SKIP_REGEX;

      // similar to csrfTokenHandlerPlugin, we need to make sure we only check resources in the app
      // bufp-38121: need to skip BO's in other apps:
      // for example, we would want to skip this URL (assuming 'notThisApp' is, well, not this app:
      // https://masterdev-vboci.integration.test.ocp.oc-test.com/ic/builder/rt/notThisApp/live/resources/data/AnonRef
      const reg = Utils.getRegexForAppScope(this.fetchHandler.scope, this.fetchHandler.config);
      this.scopeRegEx = new RegExp(reg);
    }


    /**
     * sets a special header on all requests to the VB server, which contains a app version identifier
     * @param request
     * @returns {Promise.<T>}
     */
    handleRequestHook(request) {
      return Promise.resolve().then(() => {
        if (this.shouldProcess(request)) {
          request.headers.set(VB_VERSION_ID_HEADER, this.versionId);
        }
        return null;
      });
    }


    /**
     * looks for responses from the VB server, for a special header indicating the app has been restaged/republished
     * @param response
     * @param origRequest
     * @param request
     * @param client
     * @returns {*}
     */
    handleResponseHook(response, origRequest, request, client) {
      return Promise.resolve().then(() => {
        if (this.shouldProcess(request)) {
          return ResourceChangedPlugin.checkIfResourceChanged(request.url, response, client);
        }
        return false;
      });
    }

    /**
     * should we handle this request or response?
     * @param request
     * @returns {*|boolean}
     * @private
     */
    shouldProcess(request) {
      return this.versionId && request.url.match(this.scopeRegEx) && !this.skipRegex.test(request.url);
    }

    /**
     *
     * @param url
     * @param response
     * @param client
     */
    static checkIfResourceChanged(url, response, client) {
      return Promise.resolve().then(() => {
        const hasChangedValue = response.headers.get(VB_CHANGED_HEADER);
        if (response.status === 400 && hasChangedValue && hasChangedValue !== 'false') {
          return ResourceChangedPlugin.fireResourceChangeEvent(url, response, client);
        }
        return null;
      });
    }

    /**
     * fire an event that the Application listens for
     * @param originalUrl
     * @param response
     * @param client
     * @returns {Promise.<TResult>}
     * @private
     */
    static fireResourceChangeEvent(originalUrl, response, client) {
      const clone = response.clone();

      return clone.text()
        .then((body) => ({
          method: 'vbResourceChanged',
          args: [originalUrl, body, response.headers.get(VB_CHANGED_HEADER)],
        }))
        .then((msg) => Utils.postMessage(client, msg))
        .then((result) => {
          logger.fine('fireResourceChangeEvent message complete');
          return result;
        })
        .catch((error) => {
          logger.error('fireResourceChangeEvent message error', error);
          return false;
        });
    }
  }

  return ResourceChangedPlugin;
});



define('vbsw/private/plugins/sessionExpirePlugin',['vbsw/api/fetchHandlerPlugin', 'vbsw/private/utils'],
  (FetchHandlerPlugin, Utils) => {
    /**
     * Notes:
     * SSO login e.g. https://login.dc1.c9dev1.oraclecorp.com/oam/server/obrareq.cgi
     * does not allow CORS requests (missing Access-Control-Allow-Origin: * header)
     *
     * So if a request is redirected to SSO login by cloud gate the request end up trigger
     * #handleErrorHook. In its context it is not possibly to detect why the error happened
     * (i.e. it is a consequence of a resource being redirected to non-cors page)
     * so we need to use some more tricks to figure out the cause of the error.
     */
    class SessionExpirePlugin extends FetchHandlerPlugin {
      constructor(context, params = {}) {
        super(context);
        this.contextRoot = params.contextRoot || '/';
        this.idcsHost = params.idcsHost;

        // used by unit tests
        this.backendRootUrl = params.backendRootUrl;

        // strip off the port number, 443, if any so we can match requests without the port number
        if (this.idcsHost) {
          const match = this.idcsHost.match(/^(.+):\d+/);
          if (match && match.length >= 2) {
            this.idcsHost = match[1];
          }
        }

        this.isExternalCompute = !!this.idcsHost;
      }

      handleResponseHook(response, origRequest, request, client) {
        // If the actual status from the proxied request is 401 then the request to the backend has succeeded so
        // the session is fine. Retrying won't help here as it is up to the token relay plugin to refresh the token
        // in this case.
        const actualStatus = response.headers.get('vb-proxy-status-actual');
        if (actualStatus && actualStatus.startsWith(401)) {
          return Promise.resolve(false);
        }

        const vbcsBackendUrl = this._getBackendRootURL();
        // X-AppBuilder-Unauthorized is for internal compute only
        if (response.status === 401
          && request.url.startsWith(vbcsBackendUrl)
          && (this.isExternalCompute || response.headers.get('X-AppBuilder-Unauthorized'))) {
          // got a 401 from a request to the VBCS backend which is likely due to session expiration
          return this._fireSessionExpiredEvent(request.url, client);
        }

        if (this.isExternalCompute) {
          if (response.type === 'opaque'
            && response.ok === false
            && response.status === 0
            && request.url.startsWith(vbcsBackendUrl)
            && request.mode === 'no-cors') {
            // redirected response to IDCS refresh session resource in no-cors mode
            return this._fireSessionExpiredEvent(request.url, client);
          }

          if (response.type === 'cors'
            && response.redirected === true
            && response.status === 200
            && response.ok === true
            && response.url.startsWith(this.idcsHost)
            && request.url.startsWith(vbcsBackendUrl)
            && request.mode === 'cors') {
            // redirected response to IDCS refresh session resource in cors mode
            return this._fireSessionExpiredEvent(origRequest.url, client);
          }
        }

        return Promise.resolve(false);
      }

      _getBackendRootURL() {
        return this.backendRootUrl ? this.backendRootUrl : `${self.location.origin}${this.contextRoot}`;
      }

      handleErrorHook(error, origRequest, modifiedRequest, client) {
        if (this.isExternalCompute) {
          return Promise.resolve(false);
        }

        // for internal compute only
        //
        // an error has occurred - there's no detail whatsoever so we need to figure out
        // if this could be caused by the expired session. In this case cloud gate responses
        // with 302 and redirects to SSO login or Session refresh resource.
        // At least in the first case the server does not return CORS headers so browser
        // does not allow the request to go through. To check if this is the case lets initiate
        // fetch with redirect = manual so we can then detect if the error was caused by redirect that has failed

        // for now we're only interested in detecting session expire on requests to our own (VBCS) resources
        const rootResource = this._getBackendRootURL();
        if (!modifiedRequest.url.startsWith(rootResource)) {
          return Promise.resolve(false);
        }

        // XXX for testing only !!!! this should cause the code to think the root resource has redirected as well and
        // hence initiate the refresh flow const
        // rootResource = 'http://localhost:8080/resources/application/redirectmedifferentdomain';

        // request the root resource of the domain to test if it returns something or is redirected again
        return fetch(rootResource, {
          redirect: 'manual', // manual mode so we don't get through the redirects
        }).then((response) => {
          if (response.status === 200 && !response.redirected) {
            // main page responded properly so the error has likely a different cause than session expiry
            // let the erroneous response fall through
          } else if (response.type === 'opaqueredirect') {
            // well we got opaque redirect response for request with manual redirect ->
            // that means the root resource has been redirected. We can't really figure out where
            // but it's likely this is session expiry so lets initiate the refresh flow.
            return this._fireSessionExpiredEvent(origRequest.url, client);
          } else {
            // some other state we don't understand or expect so just
            // let the erroneous response fall through
          }
          return false;
        }).catch((err) => {
          // the test request to root domain resource has failed, this is suspicious
          // let the erroneous response fall through
          console.error('A testing request to domain root resource', rootResource,
            'has failed even if redirect mode had been set to manual', err);
          // let the erroneous response fall through
          return false;
        });
      }

      /**
       * Fires a "session expired" event to the main thread and waits for its response.
       *
       * The semantic of the expected response obtained from #postMessage is following:
       * true - the session has been refreshed - the request should be retried
       * false - the session couldn't be refreshed - just give up
       *
       * @param originalUrl
       * @param client
       * @private
       */
      _fireSessionExpiredEvent(originalUrl, client) {
        console.log('session expire detected for', originalUrl);
        const msg = {
          method: SessionExpirePlugin.vbSessionExpired,
          args: [originalUrl],
        };
        return Utils.postMessage(client, msg)
          .then((result) => {
            if (result) {
              console.log('SSO session has been successfully refreshed');
            } else {
              console.warn('Couldn\'t refresh SSO session');
            }
            return result;
          })
          .catch((error) => {
            console.error('An attempt to refresh SSO session has failed:', error);

            // got an error so there's no point retrying
            return false;
          });
      }

    }

    /**
     * Name of the event that's being fired by this plugin to the main thread.
     * @type {string}
     */
    SessionExpirePlugin.vbSessionExpired = 'vbSessionExpired';

    return SessionExpirePlugin;
  });




define('vbsw/private/plugins/sessionTrackingHandlerPlugin',['vbsw/api/fetchHandlerPlugin', 'vbsw/private/utils'], (FetchHandlerPlugin, Utils) => {
  /*
   * the request header for enabling session tracking, and must be set to 'enabled' on the service.
   * When 'enabled, the VB_SESSION_TRACKING_HEADER and VB_SESSION_TRACKING_HEADER are added to the requests.
   * example:
   *   "x-oracle-abcs-userid": "franky.fallout@abxyz.com",
   *   "x-oracle-abcs-sessionid": "1e26ce77-38b7-462a-969b-b9f3a029c0ca",
   *
   * VB_REQUEST_TRACKING_HEADER is never sent, it is always stripped from the request
   * see BUFP-23166 / BugDB: 28298568
  */
  const VB_REQUEST_TRACKING_HEADER = 'vb-day-session-tracking';

  // the name of the cookie for storing information about the tracked session
  const VB_SESSION_TRACKING_COOKIE = 'VBCS_SESSION_TRACKING';

  // the name of the header used to send session tracking information
  const VB_SESSION_TRACKING_HEADER = 'X-Oracle-ABCS-SessionId';

  // the name of the header used to send session tracking user id
  const VB_SESSION_TRACKING_USER_HEADER = 'X-Oracle-ABCS-UserId';

  // delimiter used to separate session guid and user id
  const VB_SESSION_TRACKING_HEADER_DELIMITER = '@@@';

  // default cookie duration in hours
  const DEFAULT_COOKIE_DURATION = 24;

  /**
   * Handler plugin for handling session tracking cookie.
   */
  class SessionTrackingHandlerPlugin extends FetchHandlerPlugin {
    constructor(context, params) {
      super(context, params);

      this.userId = params.userId;

      // computed cookie duration in milliseconds
      this.cookieDuration = (params.cookieDuration || DEFAULT_COOKIE_DURATION) * 60 * 60 * 1000;

      this.cachedSessionCookiePromise = null;
      this.refreshSessionCookiePromise = null;
    }

    // used by unit tests
    static get requestTrackingHeader() { return VB_REQUEST_TRACKING_HEADER; }
    static get sessionTrackingHeader() { return VB_SESSION_TRACKING_HEADER; }
    static get sessionTrackingUserHeader() { return VB_SESSION_TRACKING_USER_HEADER; }
    static get sessionTrackingHeaderDelimiter() { return VB_SESSION_TRACKING_HEADER_DELIMITER; }

    /**
     * Get the session tracking header.
     *
     * @param client the client associated with the main application
     * @returns {Promise} returning the cookie header value
     */
    getSessionTrackingHeader(client) {
      if (!this.cachedSessionCookiePromise) {
        this.cachedSessionCookiePromise = Utils.getCookie(client, VB_SESSION_TRACKING_COOKIE)
          .then((sessionCookie) => {
            if (!sessionCookie) {
              return this.createSessionTrackingCookie(client);
            }

            return sessionCookie;
          });
      }

      return this.cachedSessionCookiePromise.then((sessionCookie) => {
        // if a different user is logged in or the cookie has expired, refresh the session tracking cookie
        if (sessionCookie.userId !== this.userId ||
            sessionCookie.expires < Utils.getEpochTime(true)) {
          // use refreshSessionCookiePromise to prevent refreshing the session cookie multiple times
          if (!this.refreshSessionCookiePromise) {
            // recreate the session cookie
            this.refreshSessionCookiePromise = this.createSessionTrackingCookie(client).then(() => {
              // clear the cacheSessionCookiePromise so we can refetch it
              this.cachedSessionCookiePromise = null;

              // refetch the session cookie
              return this.getSessionTrackingHeader(client).then((sessionTrackingHeader) => {
                // clear refreshSessionCookiePromise for the next refresh
                this.refreshSessionCookiePromise = null;

                return sessionTrackingHeader;
              });
            });
          }

          return this.refreshSessionCookiePromise;
        }

        return sessionCookie.header;
      });
    }

    /**
     * Create a new session tracking cookie.
     *
     * @param client the client associated with the main application
     * @returns {Promise<{name: string, session, userId: *, header: string, expires: *}>}
     */
    createSessionTrackingCookie(client) {
      const newSessionCookie = {
        userId: this.userId,
        header: `${Utils.generateUID()}${VB_SESSION_TRACKING_HEADER_DELIMITER}${this.userId}`,
        expires: Utils.getEpochTime(true) + this.cookieDuration,
      };

      return Utils.setCookie(client, VB_SESSION_TRACKING_COOKIE, newSessionCookie)
        .then(() => newSessionCookie);
    }

    handleRequestHook(request, client) {
      const requested = request.headers.get(VB_REQUEST_TRACKING_HEADER);
      if (requested === 'enabled') {
        const headers = request.headers;

        return this.getSessionTrackingHeader(client).then((sessionTrackingHeader) => {
          if (sessionTrackingHeader) {
            // set the session track header
            // headers.set(VB_SESSION_TRACKING_HEADER, sessionTrackingHeader);

            // for now, we need to split the header into two separate headers, one for the
            // session id and the other for the user id until the new version of the engagement
            // cloud can support the single header
            const splitHeaders = sessionTrackingHeader.split(VB_SESSION_TRACKING_HEADER_DELIMITER);
            if (splitHeaders.length === 2) {
              headers.set(VB_SESSION_TRACKING_HEADER, splitHeaders[0]);
              headers.set(VB_SESSION_TRACKING_USER_HEADER, splitHeaders[1]);
            }
          }
        });
      }

      return Promise.resolve();
    }
  }

  return SessionTrackingHandlerPlugin;
});



define('vbsw/private/plugins/tokenRelayHandlerPlugin',[
  'vbsw/api/fetchHandlerPlugin', 'vbsw/private/utils', 'vbsw/private/constants',
  'vbsw/private/plugins/authPreprocessorHandlerPlugin', 'vbc/private/log',
], (FetchHandlerPlugin, Utils, Constants, AuthPreprocessorHandlerPlugin, Log) => {
  const VB_TOKEN_RELAY_URL_HEADER = 'vb-token-relay-url';
  const VB_TOKEN_RELAY_AUTHENTICATION_HEADER = 'vb-token-relay-authentication';

  // skew tokerance for the token expiration time
  const SKEW_TOLERANCE = 100;

  const logger = Log.getLogger('/vbsw/private/plugins/tokenRelayHandlerPlugin');

  /**
   * Handler plugin for handling token relay.
   */
  class TokenRelayHandlerPlugin extends FetchHandlerPlugin {
    constructor(context) {
      super(context);

      // used to cached in-memory version of the token for each token relay url
      this.cachedTokenPromises = {};

      // used to keep track of which token is currently invalid
      this.invalidateTokenPromises = {};
    }

    // the following static getters are used by unit tests
    static get skewTolerance() {
      return SKEW_TOLERANCE;
    }

    static get tokenRelayUrlHeader() {
      return VB_TOKEN_RELAY_URL_HEADER;
    }

    static get tokenRelayAuthenticationHeader() {
      return VB_TOKEN_RELAY_AUTHENTICATION_HEADER;
    }

    /**
     * This method is meant to be subclassed to add additional headers specified in tokenRelayAuthentication to
     * the token relay request.
     *
     * @param tokenRelayRequest the token relay request to add the headers
     * @param tokeRelayAuthentication contains additional headers to add to request
     * @param requestUrl the url for the original request
     */
    processTokenRelayAuthentication(request, tokeRelayAuthentication, requestUrl) {}

    /**
     * Get the authorization token header either from cache or from the token relay service.
     *
     * @param tokenRelayUrl the url for the token relay service
     * @param tokenRelayAuthentication additional authentication metadata for token relay
     * @param requestUrl the url for the original request
     * @returns {Promise}
     */
    getAuthHeader(tokenRelayUrl, tokeRelayAuthentication, requestUrl) {
      // cache the promise for getting the token so we don't make multiple calls to the token relay service
      let cachedTokenPromise = this.cachedTokenPromises[tokenRelayUrl];

      if (!cachedTokenPromise) {
        // first try retrieving the token from the state cache
        cachedTokenPromise = this.stateCache.get(tokenRelayUrl).then((cachedToken) => {
          if (cachedToken) {
            return cachedToken;
          }

          const options = {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-cache',  // instruct token relay to fetch a fresh token
            // need to add oracle cloud auth type header so mobile plugin knows to handle this
            headers: {
              [Constants.AUTHENTICATION_TYPE_HEADER]: Constants.AuthenticationType.ORACLE_CLOUD,
            },
          };
          const tokenRelayRequest = new Request(tokenRelayUrl, options);

          // process additional metadata specified in tokeyRelayAuthentication
          this.processTokenRelayAuthentication(tokenRelayRequest, tokeRelayAuthentication, requestUrl);

          // use the fetchHandler to fetch the token so the request can be modified by the plugins such as
          // csrfTokenHandlerPlugin
          return this.fetchHandler.handleRequest(tokenRelayRequest).then((response) => {
            if (response.ok) {
              return response.json().then(token => this.cacheAuthToken(tokenRelayUrl, token));
            }

            throw new Error(response.statusText);
          });
        }).catch((err) => {
          // log the error for debugging purpose
          console.error(err);

          // delete the promise if there's any error so we don't cache the failure state
          delete this.cachedTokenPromises[tokenRelayUrl];
        });

        this.cachedTokenPromises[tokenRelayUrl] = cachedTokenPromise;
      }

      return cachedTokenPromise.then((cachedToken) => {
        if (cachedToken) {
          if (Utils.checkJwtExpiration(cachedToken.expiration, SKEW_TOLERANCE)) {
            // the token has expired, invalidate it and fetch a new one
            return this.invalidateCachedToken(tokenRelayUrl).then(() => {
              logger.info('Token for', tokenRelayUrl, 'has expired. Fetching a new token.');
              return this.getAuthHeader(tokenRelayUrl, tokeRelayAuthentication, requestUrl);
            });
          }

          // return the actual auth header
          return cachedToken.token.authenticationHeader;
        }

        return null;
      });
    }

    /**
     * Invalidate the cached token for the given tokenRelayUrl. This method will return a promise that will
     * resolve to true if a request should be retried and false otherwise.
     *
     * @param tokenRelayUrl the url for the cached token to invalidate
     * @returns {Promise.<Boolean>}
     */
    invalidateCachedToken(tokenRelayUrl, wwwAuthHeader) {
      let invalidateTokenPromise = this.invalidateTokenPromises[tokenRelayUrl];

      if (!invalidateTokenPromise) {
        // first, delete the token from the cache
        invalidateTokenPromise = this.stateCache.delete(tokenRelayUrl).then(() => {
          // BUFP-21346: The invalidate request currently does not work so we are bypassing it and relying on always
          // fetching a fresh token using the no-cache header.
          if (wwwAuthHeader) {
            const body = {
              headers: {
                'WWW-Authenticate': wwwAuthHeader,
              },
            };

            const options = {
              method: 'POST',
              credentials: 'same-origin',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(body),
            };
            const request = new Request(`${tokenRelayUrl}/invalidate`, options);

            // make the invalidate request to the token relay service
            return this.fetchHandler.handleRequest(request)
            // only retry if we get a status 307
              .then(response => response.status === 307)
              .catch((err) => {
                // log the error and don't retry
                console.error(err);
                return false;
              });
          }

          logger.info('Authorization token for', tokenRelayUrl, 'is invalidated');

          return Promise.resolve(true);
        });

        this.invalidateTokenPromises[tokenRelayUrl] = invalidateTokenPromise;
      }

      return invalidateTokenPromise.then((retry) => {
        // delete the invalidateTokenPromise
        delete this.invalidateTokenPromises[tokenRelayUrl];

        // delete the cachedTokenPromise so the token can be refreshed
        delete this.cachedTokenPromises[tokenRelayUrl];

        return retry;
      });
    }

    /**
     * The cached token is a wrapped version of the JWT token containing the extracted expiration
     * time and calculated server skew. This method will return a promise that resolves to the
     * wrapped token.
     *
     * @param tokenRelayUrl the url used to fetch the token
     * @param token the JWT token
     * @returns {Promise}
     */
    cacheAuthToken(tokenRelayUrl, token) {
      const expiration = Utils.extractJwtExpiration(token.authenticationHeader);
      const cachedToken = {
        token,
        expiration,
      };

      return this.stateCache.put(tokenRelayUrl, cachedToken).then(() => cachedToken);
    }

    /**
     * Append the token from the token relay service
     *
     * @param request the request to which to append the CSRF token
     * @returns {Promise}
     */
    handleRequestHook(request) {
      // get the url for the token relay service from the request header
      const tokenRelayUrl = request.headers.get(Constants.TOKEN_RELAY_URL_HEADER);
      const tokenRelayAuthHeader = request.headers.get(Constants.TOKEN_RELAY_AUTH_HEADER);
      const tokenRelayAuthentication = tokenRelayAuthHeader ? JSON.parse(tokenRelayAuthHeader) : undefined;

      if (tokenRelayUrl) {
        return this.getAuthHeader(tokenRelayUrl, tokenRelayAuthentication, request.url).then((authHeader) => {
          if (authHeader) {
            // console.log(`authToke: ${token.authenticationHeader}`);
            const headers = request.headers;

            headers.set('Authorization', authHeader);
          }

          // failed to get the token and just let the original request fail
          return Promise.resolve();
        });
      }

      return Promise.resolve();
    }

    /**
     * Handles 401 response as result of a non-JWT token expiring. The returned promise will resolve
     * to true if the request needs to be retried and false otherwise.
     *
     * @param response
     * @param origRequest
     * @param request
     * @param client
     * @returns {Promise<Boolean>}
     */
    handleResponseHook(response, origRequest, request, client) {
      return Promise.resolve().then(() => {
        if (response.status === 401) {
          const authHeader = request.headers.get('Authorization');

          logger.info('401 response detected for', origRequest.url, 'with authorization header', authHeader);

          if (authHeader) {
            // extract the token relay url from the request
            const tokenRelayUrl = AuthPreprocessorHandlerPlugin.getTokenRelayUrlFromRequest(origRequest);

            logger.info('Look up token relay url', tokenRelayUrl);

            if (tokenRelayUrl) {
              const cachedTokenPromise = this.cachedTokenPromises[tokenRelayUrl] || Promise.resolve();

              return cachedTokenPromise.then((cachedToken) => {
                // if the auth header and the cached header match, that means the token has expired
                // so invalidate the token and retry the request
                if (cachedToken
                  && cachedToken.token.authenticationHeader === authHeader) {
                  logger.info('Invalidating cached authorization token');

                  return this.invalidateCachedToken(tokenRelayUrl).then(() => true);
                }

                return false;
              });
            }
          }
        }

        return false;
      });
    }
  }

  return TokenRelayHandlerPlugin;
});


require(["main"]);
}());
//# sourceMappingURL=vb-service-worker-modules.js.map